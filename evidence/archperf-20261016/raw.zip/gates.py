from pathlib import Path
import sys,subprocess,os,json
ROOT=Path('D:/Projets/BorgInvestor');OUT=Path(__file__).parent
sys.path.insert(0,str(ROOT))
from scripts.verify_state_alert_refresh_integration import run_gate,digest
name,*targets=sys.argv[1:]
args=[*targets,'--no-cov','-q','-o','filterwarnings=error','-o','asyncio_default_fixture_loop_scope=function','-p','no:cacheprovider','--basetemp',str(OUT/(name+'-tmp')),'--junitxml',str(OUT/(name+'-junit.xml'))]
code='import pytest,os,json\ntry:\n rc=pytest.main('+repr(args)+')\nfinally:\n print("EXACT_GUARD="+json.dumps({"pid":os.getpid(),"path":os.environ.get("BORG_TEST_GUARD_RECEIPT")}))\nraise SystemExit(rc)'
env=os.environ.copy();env.update(PYTHON_DOTENV_DISABLED='1',NUMBA_CACHE_DIR=str(OUT/'numba'))
log,gate=run_gate([sys.executable,'-W','error','-c',code],ROOT,env)
(OUT/(name+'.log')).write_text(log,encoding='utf8')
for line in log.splitlines():
 if line.startswith('EXACT_GUARD='):
  exact=json.loads(line.split('=',1)[1]);p=Path(exact['path']);rows=p.read_text() if p.exists() else '';(OUT/(name+'-guard.jsonl')).write_text(rows);gate['guard_attempts']=len(rows.splitlines());gate['exact']=exact
(OUT/(name+'-receipt.json')).write_text(json.dumps(gate,indent=2));print(log);raise SystemExit(gate['returncode'])
