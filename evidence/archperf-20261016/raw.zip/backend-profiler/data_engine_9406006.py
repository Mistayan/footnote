import yfinance as yf
import numpy as np
import polars as pl
import os
import time
import json
import duckdb
import asyncio
import logging
from datetime import datetime, timedelta
from simulator.pathing import data_dir, state_dir
from simulator.observability import observed, span
from simulator.Relay.provider_phases import download as profiled_download
from simulator.cache_coordination import CacheLockTimeout, atomic_destination, cache_lock
from simulator.TradingPlatform.UNIMATRIX.numba_utils import (
    calculate_atr_jit,
)
from simulator.provider_resilience import (
    batch_pause_seconds,
    data_fetch_concurrency,
    yf_threads_enabled,
)

logger = logging.getLogger("simulator.Database.data_engine")

# Standard S&P 500 Sector Representative Tickers for Breadth
SECTOR_TICKERS = {
    "Technology": ["AAPL", "MSFT", "NVDA", "AVGO", "ORCL", "ADBE", "CRM", "AMD", "CSCO", "ACN"],
    "Financials": ["JPM", "BAC", "MA", "V", "GS", "MS", "BLK", "WFC", "AXP", "SPGI"],
    "Healthcare": ["UNH", "JNJ", "LLY", "ABBV", "MRK", "TMO", "PFE", "ABT", "DHR", "ISRG"],
    "Consumer Discretionary": ["AMZN", "TSLA", "HD", "MCD", "NKE", "LOW", "BKNG", "SBUX", "TJX", "ORLY"],
    "Communication Services": ["META", "GOOGL", "NFLX", "TMUS", "VZ", "DIS", "CMCSA", "T", "CHTR", "EA"],
    "Industrials": ["GE", "CAT", "UPS", "HON", "BA", "UNP", "LMT", "RTX", "DE", "ADP"],
    "Energy": ["XOM", "CVX", "COP", "SLB", "EOG", "MPC", "PSX", "VLO", "MPC", "WMB"],
    "Materials": ["LIN", "APD", "SHW", "ECL", "FCX", "NEM", "CTVA", "DOW", "MLM", "VMC"],
    "Utilities": ["NEE", "SO", "DUK", "CEG", "SRE", "AEP", "D", "EXC", "PCG", "PEG"],
    "Real Estate": ["PLD", "AMT", "EQIX", "WELL", "PSA", "DLR", "CCI", "VICI", "O", "SBAC"],
    "Consumer Staples": ["PG", "COST", "PEP", "KO", "WMT", "PM", "EL", "MDLZ", "CL", "TGT"],
    "Fintech": ["MELI", "NU", "PYPL", "SQ", "HOOD", "SOFI", "AFRM", "COIN"],
    "Quantum": ["RGTI", "IONQ", "QUBT", "QUAN", "QBTS"],
}

# Derived breadth tickers for market health indexing
BREADTH_TICKERS = list(set([t for st in SECTOR_TICKERS.values() for t in st]))


class DataEngine:
    CACHE_FILE = str(state_dir() / "market_cache.parquet")
    CACHE_V2_FILE = str(state_dir() / ".market_data_cache_v2.parquet")
    CACHE_ARCHIVE_FILE = str(state_dir() / "market_cache_archive.parquet")
    CACHE_DUCKDB_FILE = str(state_dir() / "market_cache_recent.duckdb")
    CACHE_DUCKDB_TABLE = "market_bars"
    CACHE_LOCK_TIMEOUT = 5.0
    CACHE_RECENT_WINDOW_DAYS = 45
    CACHE_TTL_SEC_RECENT = 3600 * 4  # 4 hours for symbols traded recently
    CACHE_TTL_SEC_HISTORICAL = 3600 * 24  # 24 hours for historical data

    def __init__(self, tickers: list[str], start_date: str, end_date: str = None, ai_mode: bool = False):
        self.ai_mode = ai_mode
        if "^GSPC" not in tickers:
            tickers.append("^GSPC")
        self.tickers = tickers
        # Warmup: Fetch 1 year before the actual start to prime SMA 200
        start_dt = datetime.strptime(start_date, "%Y-%m-%d")
        self.start_date = start_date
        self.fetch_start = (start_dt - timedelta(days=365)).strftime("%Y-%m-%d")
        self.end_date = end_date or datetime.now().strftime("%Y-%m-%d")
        self.combined_df = None
        self._fetched_fresh = False  # Performance optimization (Fix #5)
        self._indicator_state = {}  # Phase 4: State for incremental updates
        # Incremental bar buffer (BorgInvestor-9zz): accumulate injected rows and
        # concat in batches instead of an O(N) vstack per tick.
        self._bar_buffer: list[dict] = []
        self._bar_buffer_flush_size = 50

        # Performance optimization: Cache metadata maps (Fix #3)
        self._sector_map = {}
        self._country_map = {}
        self._load_metadata_maps()

    def _load_metadata_maps(self):
        """Loads metadata JSON maps into memory once (Performance Fix #3)."""
        s_path = str(data_dir() / "sector_map.json")
        c_path = str(data_dir() / "country_map.json")

        if os.path.exists(s_path):
            try:
                with open(s_path, "r") as f:
                    self._sector_map = json.load(f)
            except Exception as e:
                self.log(f" Error loading sector map: {e}")

        if os.path.exists(c_path):
            try:
                with open(c_path, "r") as f:
                    self._country_map = json.load(f)
            except Exception as e:
                self.log(f" Error loading country map: {e}")

    def log(self, msg: str):
        # Always output to stderr to avoid breaking stdout JSON parsing if possible,
        # but institutional_benchmark now handles dirty stdout too.
        # Minimal progress logging helps detect stalls.
        if not self.ai_mode:
            logger.info(msg)

    def use_alpaca_recent_data(self) -> bool:
        return os.getenv("BORG_ENABLE_ALPACA_RECENT_DATA", "false").lower() in {
            "1",
            "true",
            "yes",
        }

    def _recent_window_start(self) -> str:
        end_date = datetime.strptime(self.end_date, "%Y-%m-%d").date()
        return (end_date - timedelta(days=self.CACHE_RECENT_WINDOW_DAYS)).strftime("%Y-%m-%d")

    def _read_parquet_slice(self, path: str, ticker_set: set[str], start: str, end: str) -> pl.DataFrame:
        with span("parquet_read") as operation:
            if not ticker_set or not os.path.exists(path):
                operation.coverage(len(ticker_set), 0)
                operation.count(rows=0)
                return pl.DataFrame()
            frame = (
                pl.scan_parquet(path)
                .filter(
                    pl.col("Ticker").is_in(ticker_set) & (pl.col("trade_date") >= start) & (pl.col("trade_date") <= end)
                )
                .collect()
            )
            operation.coverage(len(ticker_set), frame["Ticker"].n_unique())
            operation.count(rows=frame.height)
            return frame

    def _read_duckdb_slice(self, ticker_set: set[str], start: str, end: str) -> pl.DataFrame:
        # Preserve the best-effort empty fallback, but expose a swallowed DB failure.
        try:
            with span("duckdb_read") as operation:
                if not ticker_set or not os.path.exists(self.CACHE_DUCKDB_FILE):
                    operation.coverage(len(ticker_set), 0)
                    operation.count(rows=0)
                    return pl.DataFrame()
                placeholders = ",".join(["?"] * len(ticker_set))
                query = (
                    f"SELECT * FROM {self.CACHE_DUCKDB_TABLE} "
                    f"WHERE Ticker IN ({placeholders}) AND trade_date >= ? AND trade_date <= ?"
                )
                params = list(ticker_set) + [start, end]
                with cache_lock(self.CACHE_DUCKDB_FILE, timeout=self.CACHE_LOCK_TIMEOUT), duckdb.connect(self.CACHE_DUCKDB_FILE, read_only=True) as conn:
                    frame = conn.execute(query, params).pl()
                operation.coverage(len(ticker_set), frame["Ticker"].n_unique())
                operation.count(rows=frame.height)
                return frame
        except CacheLockTimeout:
            # Contention is not a missing cache: never silently substitute stale tiers.
            raise
        except Exception as exc:
            self.log(f" DuckDB recent cache read failed: {type(exc).__name__}")
            return pl.DataFrame()

    def _load_tiered_cache_slice(self, ticker_set: set[str]) -> pl.DataFrame:
        with cache_lock(self.CACHE_DUCKDB_FILE, timeout=self.CACHE_LOCK_TIMEOUT):
            return self._load_tiered_cache_slice_locked(ticker_set)

    def _load_tiered_cache_slice_locked(self, ticker_set: set[str]) -> pl.DataFrame:
        window_start = self._recent_window_start()
        frames: list[pl.DataFrame] = []
        if self.fetch_start < window_start:
            archive = self._read_parquet_slice(self.CACHE_ARCHIVE_FILE, ticker_set, self.fetch_start, self.end_date)
            if archive.is_empty():
                archive = self._read_parquet_slice(self.CACHE_V2_FILE, ticker_set, self.fetch_start, self.end_date)
            if archive.is_empty():
                archive = self._read_parquet_slice(self.CACHE_FILE, ticker_set, self.fetch_start, self.end_date)
            if not archive.is_empty():
                frames.append(archive.filter(pl.col("trade_date") < window_start))
        recent = self._read_duckdb_slice(ticker_set, max(self.fetch_start, window_start), self.end_date)
        if recent.is_empty():
            recent = self._read_parquet_slice(
                self.CACHE_V2_FILE, ticker_set, max(self.fetch_start, window_start), self.end_date
            )
        if not recent.is_empty():
            frames.append(recent)
        if not frames:
            return pl.DataFrame()
        return (
            pl.concat(frames, how="diagonal")
            .unique(subset=["Ticker", "trade_date"], keep="last")
            .sort(["trade_date", "Ticker"])
        )

    def _write_cache_tiers(self, df: pl.DataFrame) -> None:
        recent = df.filter(pl.col("trade_date") >= self._recent_window_start())
        with span("cache_update"), cache_lock(self.CACHE_DUCKDB_FILE, timeout=self.CACHE_LOCK_TIMEOUT):
            with duckdb.connect(self.CACHE_DUCKDB_FILE) as conn:
                conn.register("recent", recent)
                conn.execute(f"CREATE OR REPLACE TABLE {self.CACHE_DUCKDB_TABLE} AS SELECT * FROM recent")
            with atomic_destination(self.CACHE_ARCHIVE_FILE) as temporary:
                df.write_parquet(temporary)

    @observed("data_fetch")
    def fetch_data(self, batch_size: int = 50):
        cache_only = os.environ.get("CACHE_ONLY") == "1"

        def validate_cache_window() -> None:
            if self.combined_df is None or self.combined_df.is_empty():
                return
            min_date = self.combined_df.select(pl.col("trade_date").min()).item()
            max_date = self.combined_df.select(pl.col("trade_date").max()).item()
            start_req = datetime.strptime(self.start_date, "%Y-%m-%d").date()
            end_req = datetime.strptime(self.end_date, "%Y-%m-%d").date()
            min_d = datetime.strptime(str(min_date), "%Y-%m-%d").date()
            max_d = datetime.strptime(str(max_date), "%Y-%m-%d").date()
            if min_d > start_req + timedelta(days=7) or max_d < end_req - timedelta(days=3):
                raise RuntimeError(
                    "CACHE_ONLY coverage insufficient: "
                    f"requested {self.start_date}..{self.end_date}, cache slice {min_date}..{max_date}. "
                    "Refresh market cache before benchmarking."
                )

        def load_cached_slice(allow_broad_fallback: bool = False, require_window: bool = False) -> bool:
            ticker_set = set(self.tickers) | {"^GSPC", "^VIX", "EURUSD=X"}
            cached_df = self._load_tiered_cache_slice(ticker_set)
            if cached_df.is_empty():
                # Check both legacy and v2 names if necessary, but v2 is preferred now
                cache_path = self.CACHE_V2_FILE if os.path.exists(self.CACHE_V2_FILE) else self.CACHE_FILE
                if not os.path.exists(cache_path):
                    return False
                cached_df = self._read_parquet_slice(cache_path, ticker_set, self.fetch_start, self.end_date)
            if cached_df.is_empty():
                return False

            if cached_df.is_empty() and allow_broad_fallback:
                self.log(
                    " [CACHE_ONLY] Requested tickers missing from filtered cache slice. Falling back to date-matched cache."
                )
                cached_df = (
                    pl.scan_parquet(self.CACHE_FILE)
                    .filter((pl.col("trade_date") >= self.fetch_start) & (pl.col("trade_date") <= self.end_date))
                    .collect()
                )

            if cached_df.is_empty():
                return False

            self.combined_df = self._apply_metadata_mapping(cached_df)
            if require_window:
                validate_cache_window()
            return True

        # Phase 4 Optimization: Check memory cache first (Singleton-like behavior)
        if self.combined_df is not None:
            max_date = self.combined_df.select(pl.col("trade_date").max()).item()
            today_str = datetime.now().strftime("%Y-%m-%d")

            # If our memory-cached data is from today or yesterday (and it's a weekend), we're good
            is_memory_fresh = max_date == today_str or (
                datetime.now().weekday() >= 5 and max_date >= (datetime.now() - timedelta(days=3)).strftime("%Y-%m-%d")
            )

            if is_memory_fresh:
                self.log(f" Memory cache is fresh (up to {max_date}). Skipping fetch.")
                return

        if cache_only:
            self.log(" [CACHE_ONLY] Enforcing local parity. Skipping network sync.")
            if load_cached_slice(allow_broad_fallback=True, require_window=True):
                return
            self.log(" [CACHE_ONLY] Cache file missing or filtered slice empty.")
            self.combined_df = None
            return

        # 1. Try Cache First with TTL (v2)
        cache_path = self.CACHE_V2_FILE if os.path.exists(self.CACHE_V2_FILE) else self.CACHE_FILE
        if os.path.exists(cache_path):
            mtime = os.path.getmtime(cache_path)

            # Calculate dynamic TTL based on end_date
            days_since_end = (datetime.now() - datetime.strptime(self.end_date, "%Y-%m-%d")).days
            ttl = self.CACHE_TTL_SEC_RECENT if days_since_end < 30 else self.CACHE_TTL_SEC_HISTORICAL

            # Optimization: For historical backtests, ignore file age if cache covers range
            is_historical = days_since_end > 30
            is_fresh = (time.time() - mtime) < ttl or is_historical

            # Institutional Fix: CACHE_ONLY mode (v2.0.5)
            # Force cache load even if expired or incomplete
            if cache_only:
                is_fresh = True
                is_historical = True

            if is_fresh or is_historical:
                self.log(" Checking cached market data via DuckDB...")
                try:
                    # Efficiently check metadata without loading full dataset
                    duckdb.execute("PRAGMA memory_limit='2GB'")
                    rel = duckdb.from_parquet(cache_path)
                    cache_stats = rel.aggregate("min(trade_date), max(trade_date)").fetchone()

                    if not cache_stats or not cache_stats[0]:
                        self.log(" Cache contains no dates, refetching...")
                        missing_data = True
                    else:
                        cache_start = cache_stats[0]
                        cache_end = cache_stats[1]

                        # Distinct tickers check (still fast in DuckDB)
                        cached_tickers = set(row[0] for row in rel.project("Ticker").distinct().fetchall())

                        failed_tickers_cache = set()
                        failed_tickers_path = state_dir() / "failed_tickers.json"
                        if failed_tickers_path.exists():
                            try:
                                with open(failed_tickers_path, "r") as f:
                                    failed_tickers_cache = set(json.load(f))
                            except Exception:
                                pass

                        requested_tickers = set(self.tickers)
                        missing_tickers = requested_tickers - cached_tickers - failed_tickers_cache

                        start_date_req = datetime.strptime(self.fetch_start, "%Y-%m-%d").date()
                        cache_start_d = datetime.strptime(str(cache_start), "%Y-%m-%d").date()
                        end_date_req = datetime.strptime(self.end_date, "%Y-%m-%d").date()
                        cache_end_d = datetime.strptime(str(cache_end), "%Y-%m-%d").date()

                        # Allow a small start buffer because the first requested day may be
                        # a weekend/holiday while the cache correctly starts on the first
                        # trading session after that date.
                        start_diff = (cache_start_d - start_date_req).days

                        # Allow 3-day buffer for weekends/holidays on cache_end
                        end_diff = (end_date_req - cache_end_d).days

                        # Ensure cache covers requested range AND tickers
                        missing_data = bool(missing_tickers) or start_diff > 3 or end_diff > 3

                        if cache_only:
                            missing_data = False  # Hard lock: use whatever we have

                        if not missing_data:
                            self.log(
                                f" Cache is fresh and complete ({len(cached_tickers)} assets, {cache_start} to {cache_end})."
                            )
                            # Native Polars load is more robust than DuckDB bridge for small/medium caches
                            # Use scan_parquet for lazy loading and predicate pushdown to reduce memory
                            if load_cached_slice(allow_broad_fallback=cache_only):
                                return
                            self.log(" Cache slice was empty after validation, refetching...")
                        else:
                            if missing_tickers:
                                self.log(
                                    f" Cache missing {len(missing_tickers)} tickers: {list(missing_tickers)[:5]}..."
                                )
                            if start_diff > 3:
                                self.log(f" Cache start insufficient: {cache_start} > {self.fetch_start}")
                            if end_diff > 3:
                                self.log(f" Cache end insufficient: {cache_end} is > 3 days behind {self.end_date}")
                            self.log(" Refetching to cover full requested range...")
                except CacheLockTimeout:
                    raise
                except Exception as e:
                    import traceback

                    traceback.print_exc()
                    self.log(f" Cache check failed ({e}), refetching...")
            else:
                self.log(f" Cache expired ({int((time.time() - mtime) / 60)}m old), refetching...")

        self.log(f" Fetching data for {len(self.tickers)} assets in batches of {batch_size}...")

        # Download all + EURUSD + Breadth + VIX + HEDGES
        HEDGE_ASSETS = ["SH", "PSQ", "SQQQ", "SGOV", "BIL"]
        all_tickers = sorted(list(set(self.tickers + BREADTH_TICKERS + HEDGE_ASSETS + ["EURUSD=X", "^GSPC", "^VIX"])))

        # --- BATCH FETCHING TO PREVENT TIMEOUTS ---
        chunks = [all_tickers[i : i + batch_size] for i in range(0, len(all_tickers), batch_size)]
        all_pl_dfs = []

        # Split logic: Alpaca for last 30 days, yf for historical
        cutoff_date = (datetime.now() - timedelta(days=30)).date()
        fetch_start_d = datetime.strptime(self.fetch_start, "%Y-%m-%d").date()
        end_date_d = datetime.strptime(self.end_date, "%Y-%m-%d").date()

        try:
            all_pl_dfs = asyncio.run(self._fetch_all_batches_async(chunks, fetch_start_d, cutoff_date, end_date_d))
        except Exception as e:
            self.log(f"  Critical Error during parallel fetch: {e}")
            all_pl_dfs = []

        if not all_pl_dfs:
            self.log(" Error: No data returned from any batch.")
            self.combined_df = None
            return

        self._fetched_fresh = True  # Track that we have new data to cache (Fix #5)

        # 3. POLARS ONLY FROM HERE
        pdf = pl.concat(all_pl_dfs, how="diagonal")

        # Sector & Country Mapping (Polars Native)
        pdf = self._apply_metadata_mapping(pdf)

        # 4. Normalize EURUSD (Polars Native Join)
        fx_df = (
            pdf.filter(pl.col("Ticker") == "EURUSD=X")
            .select([pl.col("trade_date"), pl.col("Close").alias("fx_rate")])
            .group_by("trade_date")
            .mean()
        )

        pdf = pdf.filter(pl.col("Ticker") != "EURUSD=X")
        pdf = pdf.join(fx_df, on="trade_date", how="left")

        # Sort and ffill fx_rate
        pdf = pdf.sort(["Ticker", "trade_date"])
        pdf = pdf.with_columns(pl.col("fx_rate").forward_fill().over("Ticker").fill_null(1.085))

        # Explicit type normalization
        pdf = pdf.with_columns(
            [
                pl.col(c).cast(pl.Float64)
                for c in ["Open", "High", "Low", "Close", "Volume", "fx_rate"]
                if c in pdf.columns
            ]
        )

        # 6. Sanitize Outliers
        pdf = pdf.sort(["Ticker", "trade_date"])

        # Detect SGOV anomalies (Treasury bond ETFs don't move 5% in a day)
        # FORCE SGOV to 100.0 for stable backtesting (Institutional Zero-Drawdown Cash Sweep)
        pdf = pdf.with_columns(
            [pl.when(pl.col("Ticker") == "SGOV").then(100.0).otherwise(pl.col("Close")).alias("Close")]
        )

        # v1.9.9: MOMENTUM (ROC 126d - 6 months standard)
        pdf = pdf.with_columns(
            [
                ((pl.col("Close") / pl.col("Close").shift(5).over("Ticker")) - 1).fill_null(0.0).alias("ROC_5"),
                ((pl.col("Close") / pl.col("Close").shift(126).over("Ticker")) - 1).fill_null(0.0).alias("ROC_126"),
                ((pl.col("Close") / pl.col("Close").shift(1).over("Ticker")) - 1).fill_null(0.0).alias("Daily_Return"),
            ]
        )

        # 7. Vectorized Indicator Calculations
        self.log(" Calculating vectorized indicators (EMA, RSI, ATR, SMA)...")
        pdf = pdf.sort(["Ticker", "trade_date"])

        # Fill gaps
        pdf = pdf.with_columns(
            [
                pl.col("Close").fill_null(strategy="forward"),
                pl.col("High").fill_null(strategy="forward"),
                pl.col("Low").fill_null(strategy="forward"),
                pl.col("Volume").fill_null(0.0),
            ]
        )

        pdf = pdf.filter(pl.col("Close").is_not_null())

        # EMA and SMA.
        # min_periods=span so an EMA only emits once enough observations exist,
        # matching the rolling SMA warmup (BorgInvestor-z4o). Without it Polars
        # emits a value from the first bar (just the price), so EMA_200 was an
        # unconverged number masquerading as a 200-period EMA early in the window.
        pdf = pdf.with_columns(
            [
                pl.col("Close").ewm_mean(span=10, min_periods=10).over("Ticker").alias("EMA_10"),
                pl.col("Close").ewm_mean(span=21, min_periods=21).over("Ticker").alias("EMA_21"),
                pl.col("Close").ewm_mean(span=50, min_periods=50).over("Ticker").alias("EMA_50"),
                pl.col("Close").ewm_mean(span=200, min_periods=200).over("Ticker").alias("EMA_200"),
                pl.col("Close").rolling_mean(window_size=20).over("Ticker").alias("SMA_20"),
                pl.col("Close").rolling_mean(window_size=50).over("Ticker").alias("SMA_50"),
                pl.col("Close").rolling_mean(window_size=200).over("Ticker").alias("SMA_200"),
                pl.col("Volume").rolling_mean(window_size=20).over("Ticker").alias("AVG_VOL"),
                pl.col("Low").rolling_min(window_size=30).over("Ticker").alias("MIN_30"),
                pl.col("High").rolling_max(window_size=30).over("Ticker").alias("MAX_30"),
            ]
        )

        # RSI (Tier 2: Optimized for Incremental Phase 4)
        pdf = pdf.with_columns([(pl.col("Close") - pl.col("Close").shift(1)).over("Ticker").alias("_diff")])
        pdf = pdf.with_columns(
            [
                pl.when(pl.col("_diff") > 0).then(pl.col("_diff")).otherwise(0.0).alias("_gain"),
                pl.when(pl.col("_diff") < 0).then(-pl.col("_diff")).otherwise(0.0).alias("_loss"),
            ]
        )
        # alpha = 1 / 14 (Wilder) -> span = 27
        pdf = pdf.with_columns(
            [
                pl.col("_gain").ewm_mean(span=27).over("Ticker").alias("RSI_avg_gain"),
                pl.col("_loss").ewm_mean(span=27).over("Ticker").alias("RSI_avg_loss"),
            ]
        )
        pdf = pdf.with_columns(
            (100.0 - (100.0 / (1.0 + pl.col("RSI_avg_gain") / pl.col("RSI_avg_loss")))).fill_nan(50.0).alias("RSI")
        )
        # Drop temp columns
        pdf = pdf.drop(["_diff", "_gain", "_loss"])

        # ATR (Tier 2: Multiple Columns via Struct)
        def compute_atr_batch(s: pl.Series) -> pl.Series:
            # s is a Series of Structs {High, Low, Close}
            df_struct = s.struct.unnest()
            high = df_struct["High"].to_numpy()
            low = df_struct["Low"].to_numpy()
            close = df_struct["Close"].to_numpy()
            return pl.Series(calculate_atr_jit(high, low, close))

        pdf = pdf.with_columns(
            pl.struct(["High", "Low", "Close"]).map_batches(compute_atr_batch).over("Ticker").alias("ATR")
        )

        # GARCH Volatility (v11.1 Tier 2: Pre-calculation)
        self.log(" Estimating GARCH Volatility surfaces (Tier 2 Optimization)...")
        # We compute this for ^GSPC and potentially lead assets
        # For performance, we use a simple rolling std as proxy if fitting is too slow,
        # but here we'll use the VolatilityEngine for ^GSPC specifically
        from simulator.Engine.volatility_engine import VolatilityEngine

        vol_eng = VolatilityEngine()

        # Pre-calculating for ^GSPC (Performance Fix #1: Cache-First Batch)
        gspc_df = pdf.filter(pl.col("Ticker") == "^GSPC").select(["trade_date", "Daily_Return"])
        gspc_data = gspc_df.to_numpy()  # [trade_date, Daily_Return]
        gspc_vols = {}
        gspc_regimes = {}
        rets = []

        # Cold-fit bound (BorgInvestor-djr): GARCH ensemble vol is slow-moving, so
        # on a cold backtest we refit only every GARCH_REFIT_STRIDE sessions and
        # carry the last value forward between refits. Cached dates always hit the
        # cache first (no refit), so warm runs are unchanged. Override via env.
        garch_stride = int(os.environ.get("GARCH_REFIT_STRIDE", "5"))
        last_vol = 0.20
        last_regime = "NORMAL"

        self.log(f"  Checking GARCH cache for {len(gspc_data)} dates (refit stride={garch_stride})...")
        for i in range(len(gspc_data)):
            date_str = str(gspc_data[i, 0])
            ret = gspc_data[i, 1]
            rets.append(ret)

            # Simple check if already in VolatilityEngine internal cache
            if date_str in vol_eng.cache:
                v_res = vol_eng.cache[date_str]
                last_vol = v_res.get("ensemble_avg", 0.20)
                last_regime = v_res.get("regime", "NORMAL")
                gspc_vols[date_str] = last_vol
                gspc_regimes[date_str] = last_regime
            elif len(rets) >= 100 and (i % garch_stride == 0):
                recent_rets = np.array(rets[-252:])
                v_res = vol_eng.forecast_ensemble(recent_rets, date_key=date_str)
                last_vol = v_res["ensemble_avg"]
                last_regime = vol_eng.get_regime_vote(recent_rets)
                gspc_vols[date_str] = last_vol
                gspc_regimes[date_str] = last_regime
            elif len(rets) >= 100:
                # Between refits: carry forward the last fitted vol/regime.
                gspc_vols[date_str] = last_vol
                gspc_regimes[date_str] = last_regime
            else:
                gspc_vols[date_str] = 0.20
                gspc_regimes[date_str] = "NORMAL"

        vol_eng.save_cache()

        pdf = pdf.with_columns(
            [
                pl.col("trade_date").replace(gspc_vols, default=0.20).cast(pl.Float64).alias("GSPC_Vol"),
                pl.col("trade_date").replace(gspc_regimes, default="NORMAL").alias("GSPC_Regime"),
            ]
        )

        # 7b. Volume Profile (v11.6 High-Fidelity Order Blocks)
        self.log(" Building Volume Profiles (POC/VAH/VAL) via Numba-JIT...")
        from simulator.TradingPlatform.UNIMATRIX.numba_utils import (
            calculate_volume_profile_jit,
        )

        def compute_vp_batch(s: pl.Series) -> pl.Series:
            df_struct = s.struct.unnest()
            # Window 30, Bins 20 (Institutional Defaults)
            prices = df_struct["Close"].to_numpy()
            volumes = df_struct["Volume"].to_numpy()
            poc, vah, val = calculate_volume_profile_jit(prices, volumes, window=30, bins=20)

            # Return as a Struct Series
            return pl.Series([{"POC": p, "VAH": vh, "VAL": vl} for p, vh, vl in zip(poc, vah, val)])

        pdf = (
            pdf.with_columns(pl.struct(["Close", "Volume"]).map_batches(compute_vp_batch).over("Ticker").alias("VP"))
            .with_columns(
                [
                    pl.col("VP").struct.field("POC").alias("POC_30"),
                    pl.col("VP").struct.field("VAH").alias("VAH_30"),
                    pl.col("VP").struct.field("VAL").alias("VAL_30"),
                ]
            )
            .drop("VP")
        )

        # Fix nulls
        pdf = pdf.with_columns(
            [
                pl.col("EMA_10").fill_null(pl.col("Close")),
                pl.col("EMA_21").fill_null(pl.col("Close")),
                pl.col("EMA_50").fill_null(pl.col("Close")),
                pl.col("EMA_200").fill_null(pl.col("Close")),
                pl.col("SMA_200").fill_null(pl.col("Close")),
                pl.col("RSI").fill_null(50.0),
                pl.col("ATR").fill_null(0.0),
                pl.col("AVG_VOL").fill_null(pl.col("Volume")),
                pl.col("ROC_5").fill_null(0.0),
                pl.col("ROC_126").fill_null(0.0),
                pl.col("MIN_30").fill_null(pl.col("Low")),
                pl.col("MAX_30").fill_null(pl.col("High")),
                pl.col("POC_30").fill_null(pl.col("Close")),
                pl.col("VAH_30").fill_null(pl.col("Close")),
                pl.col("VAL_30").fill_null(pl.col("Close")),
            ]
        )

        # 8. CALCULATE SYSTEMIC BREADTH (Tier 3: Breadth Velocity)
        self.log(" Calculating Institutional Market Breadth Velocity (S&P 500 Proxy)...")
        # Ensure BREADTH_TICKERS is accessible (module level)
        breadth_df = pdf.filter(pl.col("Ticker").is_in(BREADTH_TICKERS))

        breadth_agg = (
            breadth_df.group_by("trade_date")
            .agg([(pl.col("Close") > pl.col("SMA_200")).mean().alias("MarketBreadth")])
            .sort("trade_date")
            .with_columns(pl.col("MarketBreadth").rolling_mean(window_size=5, min_periods=1).alias("MarketBreadth"))
        )

        # Calculate Velocity (ROC of Breadth) using Numba JIT
        from simulator.TradingPlatform.UNIMATRIX.numba_utils import (
            calculate_breadth_velocity,
        )

        breadth_vals = breadth_agg.select("MarketBreadth").to_numpy().flatten()
        b_velocity = calculate_breadth_velocity(breadth_vals, window=10)

        breadth_agg = breadth_agg.with_columns(pl.Series(b_velocity).alias("BreadthVelocity"))

        pdf = pdf.join(breadth_agg, on="trade_date", how="left").with_columns(
            [
                pl.col("MarketBreadth").fill_null(strategy="forward").fill_null(0.5),
                pl.col("BreadthVelocity").fill_null(0.0),
            ]
        )

        # 8b. SECTOR PARTICIPATION (Tier 4: Relative Greed)
        self.log(" Aggregating Sector Participation (OVTLYR Breadth)...")

        # Optimized: Single pass aggregation for all sectors instead of multiple joins
        sector_aggs = []
        for sector, tickers in SECTOR_TICKERS.items():
            # Use sum/count logic to avoid multiple filters/joins
            # Breadth = (Number of stocks above SMA_50) / (Total stocks in sector present that day)
            expr = (
                (pl.when(pl.col("Ticker").is_in(tickers)).then(pl.col("Close") > pl.col("SMA_50")).otherwise(None))
                .mean()
                .alias(f"Breadth_{sector}")
            )
            sector_aggs.append(expr)

        sector_breadth_df = pdf.group_by("trade_date").agg(sector_aggs)
        pdf = pdf.join(sector_breadth_df, on="trade_date", how="left").with_columns(
            [pl.col(f"Breadth_{s}").fill_null(strategy="forward").fill_null(0.5) for s in SECTOR_TICKERS.keys()]
        )

        # 8c. RELATIVE GREED CALCULATION
        # Greed = (MarketBreadth * 3 + SectorMeanBreadth * 1) / 4 smoothed by short window
        sector_breadth_cols = [f"Breadth_{s}" for s in SECTOR_TICKERS.keys()]
        pdf = pdf.with_columns(
            (
                (
                    pl.sum_horizontal(sector_breadth_cols) / len(sector_breadth_cols) * 1.5
                    + pl.col("MarketBreadth") * 2.0
                )
                / 3.5
            ).alias("RelativeGreed")
        )

        # Smooth RelativeGreed to ensure stable conviction signal
        pdf = pdf.with_columns(
            pl.col("RelativeGreed").rolling_mean(window_size=10, min_periods=1).alias("RelativeGreed")
        )

        # 8d. BREADTH THRUST DETECTION (v11.4 Advance)
        # Zweig-inspired: Significant upward breadth shift in a momentum regime
        pdf = pdf.with_columns(
            ((pl.col("MarketBreadth") > 0.615) & (pl.col("BreadthVelocity") > 0.01))
            .cast(pl.Float64)
            .alias("BreadthThrust")
        )

        # 9. EMULATE OVTLYR Sentiment
        pdf = pdf.with_columns(
            [
                (
                    (pl.col("Close") > pl.col("SMA_200")).cast(pl.Float64) * 1.5
                    + (pl.col("Close") > pl.col("SMA_50")).cast(pl.Float64) * 1.5
                    + (pl.col("SMA_50") > pl.col("SMA_200")).cast(pl.Float64) * 2.0
                ).alias("m_trend"),
                (
                    (pl.col("RSI") > 50).cast(pl.Float64) * 1.5
                    + (pl.col("Close") > pl.col("Close").shift(1).over("Ticker")).cast(pl.Float64) * 1.5
                    + (pl.col("MarketBreadth") > 0.612).cast(pl.Float64) * 2.5
                ).alias("m_signal"),
            ]
        )

        self.combined_df = pdf.with_columns(pl.col("trade_date").cast(pl.String)).filter(
            pl.col("trade_date").is_not_null()
        )

        # Cache to local Parquet only if we fetched fresh data (Performance Fix #5)
        if self._fetched_fresh and self.combined_df is not None:
            self.log(f" Writing fresh cache to {self.CACHE_V2_FILE}...")
            with cache_lock(self.CACHE_DUCKDB_FILE, timeout=self.CACHE_LOCK_TIMEOUT):
                self._write_cache_tiers(self.combined_df)
                with atomic_destination(self.CACHE_V2_FILE) as temporary:
                    self.combined_df.write_parquet(temporary)
        elif self.combined_df is not None:
            self.log(" Skipping cache write (Warm Cache / No new data).")
        else:
            self.log(" Warning: No data to cache.")

    async def _fetch_all_batches_async(self, chunks, fetch_start_d, cutoff_date, end_date_d):
        """Orchestrates parallel fetching for all batches (Phase 2 Optimization)."""
        concurrency = data_fetch_concurrency()
        semaphore = asyncio.Semaphore(concurrency)

        async def guarded_fetch(idx, chunk):
            async with semaphore:
                result = await self._fetch_batch_async(idx, chunk, fetch_start_d, cutoff_date, end_date_d)
                pause = batch_pause_seconds()
                if pause > 0:
                    await asyncio.sleep(pause)
                return result

        tasks = []
        for i, chunk in enumerate(chunks):
            tasks.append(guarded_fetch(i, chunk))

        results = await asyncio.gather(*tasks, return_exceptions=True)

        all_frames = []
        for res in results:
            if isinstance(res, list):
                all_frames.extend(res)
            elif isinstance(res, Exception):
                self.log(f"  Warning: Batch failed with error: {res}")
        return all_frames

    async def _fetch_batch_async(self, idx, chunk, fetch_start_d, cutoff_date, end_date_d):
        """Fetches a single batch of symbols (YF Historical + Alpaca/YF Recent)."""
        batch_frames = []

        # 1. Historical Segment (yfinance - Threaded)
        if fetch_start_d < cutoff_date:
            hist_end = min(end_date_d, cutoff_date)
            # Use to_thread to avoid blocking the event loop
            df_hist = await asyncio.to_thread(
                profiled_download,
                yf.download,
                chunk,
                start=self.fetch_start,
                end=hist_end.strftime("%Y-%m-%d"),
                progress=False,
                group_by="column",
                threads=yf_threads_enabled(),
            )

            if df_hist is not None and not df_hist.empty:
                p_stacked = df_hist.stack(level=1, future_stack=True).reset_index()
                batch_frames.append(pl.from_pandas(p_stacked))

        # 2. Recent Segment
        if end_date_d >= cutoff_date:
            recent_start = max(fetch_start_d, cutoff_date)
            end_str = self.end_date
            if end_str == datetime.now().strftime("%Y-%m-%d"):
                end_str = (datetime.now() + timedelta(days=1)).strftime("%Y-%m-%d")

            df_recent_yf = await asyncio.to_thread(
                profiled_download,
                yf.download,
                chunk,
                start=recent_start.strftime("%Y-%m-%d"),
                end=end_str,
                progress=False,
                group_by="column",
                threads=yf_threads_enabled(),
            )
            if df_recent_yf is not None and not df_recent_yf.empty:
                p_stacked = df_recent_yf.stack(level=1, future_stack=True).reset_index()
                batch_frames.append(pl.from_pandas(p_stacked))

        if not batch_frames:
            return []

        return self._normalize_batch_frames(batch_frames)

    @staticmethod
    def _normalize_batch_frames(batch_frames: list[pl.DataFrame]) -> list[pl.DataFrame]:
        with span("provider_normalize", provider="yfinance") as operation:
            result = DataEngine._normalize_batch_frames_impl(batch_frames)
            operation.count(rows=sum(len(frame) for frame in result))
            return result

    @staticmethod
    def _normalize_batch_frames_impl(batch_frames: list[pl.DataFrame]) -> list[pl.DataFrame]:
        # Optimization: Pre-process and cast in one go
        cleaned_frames = []
        for frm in batch_frames:
            cmap = {}
            for col in frm.columns:
                col_str = str(col).lower()
                if col_str in ["date", "level_0", "index", "timestamp"]:
                    cmap[col] = "trade_date"
                if col_str in ["ticker", "level_1", "symbol"]:
                    cmap[col] = "Ticker"
            frm = frm.rename(cmap)

            exprs = []
            for c in frm.columns:
                if c in ["trade_date", "Ticker"]:
                    exprs.append(pl.col(c).cast(pl.String))
                else:
                    exprs.append(pl.col(c).cast(pl.Float64))
            cleaned_frames.append(frm.select(exprs))

        pl_chunk = pl.concat(cleaned_frames, how="diagonal")

        # Standardize numeric columns
        numeric_cols = ["Open", "High", "Low", "Close", "Adj Close", "Volume"]
        pl_chunk = pl_chunk.with_columns([pl.col(c).cast(pl.Float64) for c in numeric_cols if c in pl_chunk.columns])
        pl_chunk = pl_chunk.with_columns(pl.col("trade_date").cast(pl.String).str.slice(0, 10))

        return [pl_chunk]

    def _apply_metadata_mapping(self, df: pl.DataFrame) -> pl.DataFrame:
        """
        Applies Sector and Country metadata mapping to the DataFrame using cached maps.
        (Performance Fix #3: Uses self._sector_map and self._country_map)
        """
        # Vectorized mapping in Polars using cached maps
        if "Sector" not in df.columns or "Country" not in df.columns:
            df = df.with_columns(
                [
                    pl.col("Ticker").replace_strict(self._sector_map, default="Unknown").alias("Sector"),
                    pl.col("Ticker").replace_strict(self._country_map, default="Unknown").alias("Country"),
                ]
            )

        return df

    def replay(self, symbol_filter: str = None):
        """Memory-efficient streaming replay using Polars partitioning."""
        if self.combined_df is None:
            self.log(" Error: No data loaded in engine.")
            return

        self.flush_bars()  # ensure buffered injected bars are visible (BorgInvestor-9zz)
        data = self.combined_df.sort(["trade_date", "Ticker"])
        if symbol_filter:
            data = data.filter(pl.col("Ticker") == symbol_filter)

        # Efficient streaming replay using Polars (Performance Fix #2: Columnar-First)
        # We materialise columns to numpy arrays for the fastest traversal
        # This avoid O(N_tickers * N_days) dict creations
        for (date_val,), day_df in data.group_by("trade_date", maintain_order=True):
            # Extract common pillars once per day
            # Since these are broadcast columns, any row will do
            row0 = day_df.row(0, named=True)

            snapshot = {
                "Date": date_val,
                "Prices": {},
                "FX": row0.get("fx_rate", 1.0),
                "MarketBreadth": row0.get("MarketBreadth", 0.5),
                "BreadthVelocity": row0.get("BreadthVelocity", 0.0),
                "RelativeGreed": row0.get("RelativeGreed", 0.5),
                "BreadthThrust": row0.get("BreadthThrust", 0.0),
                "GSPC_Vol": row0.get("GSPC_Vol", 0.20),
                "GSPC_Regime": row0.get("GSPC_Regime", "NORMAL"),
                "SectorBreadths": {s: row0.get(f"Breadth_{s}", 0.5) for s in SECTOR_TICKERS.keys()},
            }

            # Map the day's rows into the Prices dict
            # Optimization: iterate over named rows directly
            for row in day_df.iter_rows(named=True):
                ticker = row["Ticker"]
                snapshot["Prices"][ticker] = {
                    "Open": row["Open"],
                    "High": row["High"],
                    "Low": row["Low"],
                    "Close": row["Close"],
                    "Volume": row["Volume"],
                    "indicators": {
                        "EMA_10": row.get("EMA_10"),
                        "EMA_21": row.get("EMA_21"),
                        "EMA_50": row.get("EMA_50"),
                        "SMA_20": row.get("SMA_20"),
                        "SMA_50": row.get("SMA_50"),
                        "SMA_200": row.get("SMA_200"),
                        "RSI": row.get("RSI"),
                        "ATR": row.get("ATR"),
                        "CUR_VOL": row["Volume"],
                        "AVG_VOL": row.get("AVG_VOL"),
                        "ROC_5": row.get("ROC_5"),
                        "ROC_126": row.get("ROC_126"),
                        "Daily_Return": row.get("Daily_Return"),
                        "m_trend": row.get("m_trend"),
                        "m_signal": row.get("m_signal"),
                        "Sector": row.get("Sector", "Unknown"),
                        "Country": row.get("Country", "Unknown"),
                        "MIN_30": row.get("MIN_30"),
                        "MAX_30": row.get("MAX_30"),
                        "POC_30": row.get("POC_30"),
                        "VAH_30": row.get("VAH_30"),
                        "VAL_30": row.get("VAL_30"),
                    },
                }

            yield snapshot

    def get_latest_snapshot(self):
        """Phase 4: O(1) retrieval of the latest market snapshot for live streaming."""
        if self.combined_df is None:
            return None

        self.flush_bars()  # ensure buffered injected bars are visible (BorgInvestor-9zz)
        latest_date = self.combined_df.select(pl.col("trade_date").max()).item()
        day_df = self.combined_df.filter(pl.col("trade_date") == latest_date)

        # Reuse the logic from replay but only for one day
        row0 = day_df.row(0, named=True)
        snapshot = {
            "Date": latest_date,
            "Prices": {},
            "FX": row0.get("fx_rate", 1.0),
            "MarketBreadth": row0.get("MarketBreadth", 0.5),
            "BreadthVelocity": row0.get("BreadthVelocity", 0.0),
            "RelativeGreed": row0.get("RelativeGreed", 0.5),
            "BreadthThrust": row0.get("BreadthThrust", 0.0),
            "GSPC_Vol": row0.get("GSPC_Vol", 0.20),
            "GSPC_Regime": row0.get("GSPC_Regime", "NORMAL"),
            "SectorBreadths": {s: row0.get(f"Breadth_{s}", 0.5) for s in SECTOR_TICKERS.keys()},
        }

        for row in day_df.iter_rows(named=True):
            ticker = row["Ticker"]
            snapshot["Prices"][ticker] = {
                "Open": row["Open"],
                "High": row["High"],
                "Low": row["Low"],
                "Close": row["Close"],
                "Volume": row["Volume"],
                "indicators": {
                    k: row.get(k)
                    for k in [
                        "EMA_10",
                        "EMA_21",
                        "EMA_50",
                        "EMA_200",
                        "SMA_20",
                        "SMA_50",
                        "SMA_200",
                        "RSI",
                        "ATR",
                        "AVG_VOL",
                        "ROC_5",
                        "ROC_126",
                        "Daily_Return",
                        "m_trend",
                        "m_signal",
                        "Sector",
                        "Country",
                        "MIN_30",
                        "MAX_30",
                        "POC_30",
                        "VAH_30",
                        "VAL_30",
                    ]
                },
            }
        return snapshot

    def _update_indicator_state(self):
        """Caches the latest indicator values for each ticker to support incremental updates."""
        if self.combined_df is None:
            return

        # Get the last row for each ticker
        latest = self.combined_df.group_by("Ticker").tail(1)
        for row in latest.iter_rows(named=True):
            t = row["Ticker"]
            self._indicator_state[t] = {
                "EMA_10": row.get("EMA_10"),
                "EMA_21": row.get("EMA_21"),
                "EMA_50": row.get("EMA_50"),
                "EMA_200": row.get("EMA_200"),
                "RSI_avg_gain": row.get("RSI_avg_gain", 0.0),  # Need to store these for RSI parity
                "RSI_avg_loss": row.get("RSI_avg_loss", 0.0),
                "ATR": row.get("ATR"),
                "Close": row["Close"],
                "High": row["High"],
                "Low": row["Low"],
                "Volume": row["Volume"],
            }

    def inject_bar(self, ticker: str, bar: dict):
        """
        Phase 4: Institutional-grade incremental bar injection.
        Updates indicators in O(1) and appends to the in-memory combined_df.
        """
        if self.combined_df is None:
            self.log(f" Warning: Cannot inject bar for {ticker}, engine not primed.")
            return

        state = self._indicator_state.get(ticker)
        if not state:
            self.log(f" Warning: No state for {ticker}, performing full re-calc for this asset.")
            # Fallback logic could go here, but usually we're primed
            return

        # 1. Incremental EMA: EMA = Price * alpha + EMA_prev * (1 - alpha)
        # alpha = 2 / (span + 1)
        close = bar["Close"]

        def calc_ema(prev_ema, val, span):
            if prev_ema is None:
                return val
            alpha = 2.0 / (span + 1.0)
            return val * alpha + prev_ema * (1.0 - alpha)

        new_ema_10 = calc_ema(state["EMA_10"], close, 10)
        new_ema_21 = calc_ema(state["EMA_21"], close, 21)
        new_ema_50 = calc_ema(state["EMA_50"], close, 50)
        new_ema_200 = calc_ema(state["EMA_200"], close, 200)

        # 2. Incremental RSI (Wilder/Polars EWM parity)
        delta = close - state["Close"]
        gain = max(0, delta)
        loss = max(0, -delta)

        alpha_rsi = 2.0 / (27 + 1.0)  # Span 27 matches Polars internal default for 14-day RSI
        new_avg_gain = gain * alpha_rsi + state.get("RSI_avg_gain", 0.0) * (1.0 - alpha_rsi)
        new_avg_loss = loss * alpha_rsi + state.get("RSI_avg_loss", 0.0) * (1.0 - alpha_rsi)

        if new_avg_loss == 0:
            new_rsi = 100.0 if new_avg_gain > 0 else 50.0
        else:
            rs = new_avg_gain / new_avg_loss
            new_rsi = 100.0 - (100.0 / (1.0 + rs))

        # 3. Incremental ATR (Approximate Wilder)
        tr = max(bar["High"] - bar["Low"], abs(bar["High"] - state["Close"]), abs(bar["Low"] - state["Close"]))
        alpha_atr = 1.0 / 14.0
        new_atr = tr * alpha_atr + state["ATR"] * (1.0 - alpha_atr) if state["ATR"] else tr

        # 4. Construct New Row
        new_row = {
            "Ticker": ticker,
            "trade_date": bar["trade_date"],
            "Open": bar["Open"],
            "High": bar["High"],
            "Low": bar["Low"],
            "Close": close,
            "Volume": bar["Volume"],
            "EMA_10": new_ema_10,
            "EMA_21": new_ema_21,
            "EMA_50": new_ema_50,
            "EMA_200": new_ema_200,
            "RSI": new_rsi,
            "RSI_avg_gain": new_avg_gain,
            "RSI_avg_loss": new_avg_loss,
            "ATR": new_atr,
            "Sector": state.get("Sector", "Unknown"),
            "Country": state.get("Country", "Unknown"),
        }

        # 5. Buffer the new row; concat in batches to avoid an O(N) full-frame
        # copy on every tick (BorgInvestor-9zz). flush_bars() merges the buffer.
        self._bar_buffer.append(new_row)
        if len(self._bar_buffer) >= self._bar_buffer_flush_size:
            self.flush_bars()

        # 6. Update State
        self._indicator_state[ticker] = {
            "EMA_10": new_ema_10,
            "EMA_21": new_ema_21,
            "EMA_50": new_ema_50,
            "EMA_200": new_ema_200,
            "RSI_avg_gain": new_avg_gain,
            "RSI_avg_loss": new_avg_loss,
            "ATR": new_atr,
            "Close": close,
            "High": bar["High"],
            "Low": bar["Low"],
            "Volume": bar["Volume"],
            "Sector": state.get("Sector"),
            "Country": state.get("Country"),
        }
        self._fetched_fresh = True  # Trigger save on exit

    def flush_bars(self) -> None:
        """Merge any buffered injected bars into combined_df in one concat.

        Amortises the per-tick append cost (BorgInvestor-9zz). Safe to call when
        the buffer is empty. Readers (replay/get_latest_snapshot) flush first so
        buffered rows are always visible.
        """
        if not self._bar_buffer or self.combined_df is None:
            self._bar_buffer = []
            return
        rows_df = pl.DataFrame(self._bar_buffer).cast(self.combined_df.schema)
        self.combined_df = self.combined_df.vstack(rows_df)
        self._bar_buffer = []
