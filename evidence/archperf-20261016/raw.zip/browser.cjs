const fs=require('node:fs');
const {chromium}=require('./dashboard/node_modules/playwright');
(async()=>{
 const [url,file]=process.argv.slice(2);const browser=await chromium.launch({headless:true});
 const page=await browser.newPage({viewport:{width:1440,height:1000}});const errors=[],failed=[];
 page.on('pageerror',e=>errors.push(e.message));page.on('requestfailed',r=>failed.push({url:r.url(),error:r.failure()}));
 const samples=[],streamHttp=[];
 try{
  if(process.env.BORG_SSE_PROBE==='1') {
   const live=await fetch(url+'/api/stream');const reader=live.body.getReader();
   try {
    streamHttp.push({initial:new TextDecoder().decode((await reader.read()).value),contentType:live.headers.get('content-type')});
    const posted=await fetch(url+'/api/stream',{method:'POST',body:JSON.stringify({synthetic_probe:true})});
    streamHttp.push({published:await posted.json(),event:new TextDecoder().decode((await reader.read()).value)});
   } finally {await reader.cancel();reader.releaseLock();}
   for(let i=0;i<10;i++){const response=await fetch(url+'/api/stream');const reader=response.body.getReader();await reader.read();await reader.cancel();reader.releaseLock();}
   const settled=await fetch(url+'/api/stream',{method:'POST',body:JSON.stringify({synthetic_probe:true})});const result=await settled.json();streamHttp.push({afterDisconnect:result});
   if(result.subscribers!==0||!streamHttp[1].event.includes('"synthetic_probe":true'))throw Error('SSE transport parity failed');
  }
  for(let i=0;i<5;i++){
   const response=await page.goto(url+'/operations?size=50&asof=2026-01-02T00%3A00%3A00Z',{waitUntil:'load'});
   await page.getByRole('heading',{name:'Run registry',exact:true}).waitFor();
   await page.getByText('Accounting & promotion: unknown',{exact:true}).waitFor();
   await page.waitForTimeout(300);
   samples.push(await page.evaluate(({i,status})=>{const n=performance.getEntriesByType('navigation')[0];return {repetition:i,firstNavigation:i===0,status,responseStart:n.responseStart,domContentLoaded:n.domContentLoadedEventEnd,load:n.loadEventEnd,documentTransfer:n.transferSize,documentBytes:n.encodedBodySize,domBytes:new TextEncoder().encode(document.documentElement.outerHTML).length,resources:performance.getEntriesByType('resource').map(r=>({name:r.name,initiator:r.initiatorType,transfer:r.transferSize,encoded:r.encodedBodySize,decoded:r.decodedBodySize,duration:r.duration})),renderedRows:document.querySelectorAll('ul[class*="runs"]>li').length,text:document.body.textContent.includes('Accounting & promotion: unknown')};},{i,status:response.status()}));
  }
  fs.writeFileSync(file,JSON.stringify({samples,errors,failed,streamHttp},null,2));
  if(errors.length||failed.some(r=>!String(r.error?.errorText).includes('ERR_ABORTED'))||samples.some(s=>s.status!==200||!s.text))throw Error('Browser acceptance failed');
 }finally{await browser.close();}
})().catch(e=>{console.error(e);process.exitCode=1});
