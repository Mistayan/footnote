const fs=require('node:fs'),vm=require('node:vm'),ts=require('./dashboard/node_modules/typescript');
const {performance}=require('node:perf_hooks');
(async()=>{
 const all=[];
 for(const [lane,file] of [['baseline','./dashboard/app/api/stream/route.ts'],['candidate','D:/Projets/BorgInvestor/dashboard/app/api/stream/route.ts']]){
  const source=fs.readFileSync(file,'utf8');
  for(let sample=0;sample<7;sample++){
   const sets=[];class ObservedSet extends Set{constructor(...args){super(...args);sets.push(this);}}
   const exp={};const compiled=ts.transpileModule(source,{compilerOptions:{module:ts.ModuleKind.CommonJS,target:ts.ScriptTarget.ES2022}}).outputText;
   vm.runInNewContext(compiled,{exports:exp,Set:ObservedSet,TextEncoder,ReadableStream,Response,JSON});
   const started=performance.now();
   for(let i=0;i<1000;i++){const response=await exp.GET();await response.body.cancel('synthetic');}
   const cancel_ms=performance.now()-started,retained=sets[0].size;
   const publish_start=performance.now();const result=await exp.POST({text:async()=>'{"synthetic_probe":true}'});const broadcast_ms=performance.now()-publish_start;
   all.push({lane,sample,connections:1000,cancel_ms,retained_before_publication:retained,broadcast_ms,response:await result.json(),source_sha256:require('node:crypto').createHash('sha256').update(source).digest('hex')});
  }
 }
 fs.writeFileSync('stream-benchmark.json',JSON.stringify({kind:'real route source, instrumented Set to observe retention; synthetic connections, not browser RSS',samples:all},null,2));
 console.log(JSON.stringify(all,null,2));
})().catch(e=>{console.error(e);process.exitCode=1});
