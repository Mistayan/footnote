from pathlib import Path
import os,sys,subprocess,json,time,socket,urllib.request,hashlib,importlib.util,logging,statistics,shutil,uuid
ROOT=Path('D:/Projets/BorgInvestor');OUT=Path(__file__).parent
sys.path.insert(0,str(ROOT))
ROUND=sys.argv[1];dest=OUT/('round-'+ROUND);dest.mkdir(exist_ok=False)
for key in list(os.environ):
 if key.startswith(('BORG_RUN_','BORG_OPERATIONAL_ALERT')) or key=='BORG_RESTATEMENT_DIR':os.environ.pop(key)
os.environ.update(PYTHON_DOTENV_DISABLED='1',BORG_STATE_DIR=str(dest/'state'),BORG_LOGS_DIR=str(dest/'logs'),BORG_TELEMETRY_DIR=str(dest/'telemetry'),BORG_QUOTE_CACHE_DIR=str(dest/'quotes'),BORG_RUN_REGISTRY_PATH=str(dest/'observability.sqlite'))
from simulator.run_registry import process_identity,run_context
from simulator.observability import span
from scripts.verify_state_alert_refresh_integration import protected,sources,differences

def save(path,value):path.write_text(json.dumps(value,indent=2),encoding='utf8')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def module(p,name):
 s=importlib.util.spec_from_file_location(name,p);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
before_sources=sources();before_protected=protected();save(dest/'sources-before.json',before_sources);save(dest/'protected-before.json',before_protected)
shutil.copy2(ROOT/'scripts/read_registry_dashboard.py',OUT/'scripts/read_registry_dashboard.py')
reader=module(OUT/'scripts/read_registry_dashboard.py','candidate');oracle=module(OUT/'baseline/read_registry_dashboard.py','oracle')
spans=[]
class Handler(logging.Handler):
 def emit(self,r):
  if r.msg=='operation.end':spans.append({k:v for k,v in r.__dict__.items() if k in ['operation','run_id','span_id','parent_span_id','started_at','ended_at','duration_ms','status','rows','bytes','coverage_status','freshness_status','inputs_requested','inputs_available']})
log=logging.getLogger('simulator.observability');log.setLevel(logging.INFO);handler=Handler();log.addHandler(handler)
backend=[];parity=[];http=[];owners=[];fixture_before={name:sha(OUT/(name+'.sqlite')) for name in ['small','scale']}
query={'size':50,'page':1,'asof':'2026-01-02T00:00:00Z'}
with run_context('script') as run:
 for name in ['small','scale']:
  fixture=OUT/(name+'.sqlite')
  for lane,mod in [('baseline',oracle),('candidate',reader)]:
   for i in range(7):
    with span('db_snapshot') as op:
     start=time.perf_counter();result=mod.read_page(fixture,query);elapsed=(time.perf_counter()-start)*1000
     op.count(rows=len(result['rows']));op.coverage(1,int(result['status']=='ready'))
    backend.append({'fixture':name,'lane':lane,'repetition':i,'firstRead':i==0,'wall_ms':elapsed,'status':result['status'],'bytes':len(json.dumps(result).encode()),'sha256':hashlib.sha256(json.dumps(result,sort_keys=True).encode()).hexdigest()})
    assert result['status']=='ready'
  for status in ['all','degraded','running','ok','interrupted','recovered']:
   for page in [1,2]:
    q={**query,'status':status,'size':10,'page':page}
    a,b=oracle.read_page(fixture,q),reader.read_page(fixture,q)
    parity.append({'fixture':name,'query':q,'equal':a==b,'rows':len(b['rows'])});assert a==b
  env=os.environ.copy();env.update(BORG_SSE_PROBE='1' if int(ROUND)>=4 else '0',BORG_RUN_REGISTRY_PATH=str(fixture),BORG_OPERATIONAL_ALERTS_PATH=str(OUT/'absent-alerts.sqlite'),BORG_REGISTRY_PYTHON=str(ROOT/'.venv/Scripts/python.exe'),NEXT_DIST_DIR='.next-archperf',NEXT_TELEMETRY_DISABLED='1')
  with socket.socket() as sock:sock.bind(('127.0.0.1',0));port=sock.getsockname()[1]
  server_log=(dest/(name+'-server.log')).open('w',encoding='utf8')
  child=subprocess.Popen(['node','node_modules/next/dist/bin/next','start','-p',str(port),'-H','127.0.0.1'],cwd=OUT/'dashboard',env=env,stdin=subprocess.DEVNULL,stdout=server_log,stderr=subprocess.STDOUT)
  owner={'pid':child.pid,'identity':process_identity(child.pid),'port':port,'fixture':name,'build_id':(OUT/'dashboard/.next-archperf/BUILD_ID').read_text().strip(),'reader_sha256':sha(OUT/'scripts/read_registry_dashboard.py')}
  try:
   deadline=time.monotonic()+30
   while True:
    if child.poll() is not None:raise RuntimeError('Owned server exited')
    try:
     with socket.create_connection(('127.0.0.1',port),timeout=.5):break
    except OSError:
     if time.monotonic()>deadline:raise RuntimeError('Owned readiness timeout')
     time.sleep(.1)
   owner['listener_pid']=json.loads(subprocess.check_output(['powershell.exe','-NoProfile','-Command',f'@(Get-NetTCPConnection -LocalPort {port} -State Listen | Select-Object -ExpandProperty OwningProcess) | ConvertTo-Json -Compress'],text=True))
   assert owner['listener_pid'] in (child.pid,[child.pid])
   base='http://127.0.0.1:'+str(port)
   for route in ['/api/registry?size=50&asof=2026-01-02T00%3A00%3A00Z','/operations?size=50&asof=2026-01-02T00%3A00%3A00Z','/api/operational-alerts']:
    for i in range(7):
     request=urllib.request.Request(base+route)
     start=time.perf_counter()
     try:
      response=urllib.request.urlopen(request,timeout=10)
     except urllib.error.HTTPError as e:response=e
     with response:
      ttfb=(time.perf_counter()-start)*1000;body=response.read();elapsed=(time.perf_counter()-start)*1000
      record={'fixture':name,'route':route,'repetition':i,'firstHit':i==0,'status':response.status,'ttfb_ms':ttfb,'total_ms':elapsed,'bytes':len(body),'sha256':hashlib.sha256(body).hexdigest(),'cache_control':response.headers.get('Cache-Control')}
     http.append(record)
     if route.startswith('/api/registry'):
      parsed=json.loads(body);assert response.status==200 and parsed['matching']==(36 if name=='small' else 50)
      assert all(r['accounting_status']==r['promotion_status']=='unknown' for r in parsed['rows'])
      if i==0:save(dest/(name+'-api.json'),parsed)
     elif route.startswith('/operations'):assert response.status==200
     else:assert response.status==503
   if int(ROUND)>=5:
    paired=[]
    for repetition in range(7):
     for lane,source in [('baseline',OUT/'baseline/read_registry_dashboard.py'),('candidate',ROOT/'scripts/read_registry_dashboard.py')]:
      shutil.copy2(source,OUT/'scripts/read_registry_dashboard.py')
      for route in ['/api/registry?size=50&asof=2026-01-02T00%3A00%3A00Z','/operations?size=50&asof=2026-01-02T00%3A00%3A00Z']:
       start=time.perf_counter()
       with urllib.request.urlopen(base+route,timeout=10) as response:
        ttfb=(time.perf_counter()-start)*1000;body=response.read();elapsed=(time.perf_counter()-start)*1000
        paired.append({'fixture':name,'lane':lane,'repetition':repetition,'route':route,'status':response.status,'ttfb_ms':ttfb,'total_ms':elapsed,'bytes':len(body),'body_sha256':hashlib.sha256(body).hexdigest(),'reader_sha256':sha(source)})
    save(dest/(name+'-paired-http.json'),paired)
   r=subprocess.run(['node',str(OUT/'browser.cjs'),base,str(dest/(name+'-browser.json'))],cwd=OUT,env=env,capture_output=True,text=True,timeout=90)
   (dest/(name+'-browser.log')).write_text(r.stdout+r.stderr,encoding='utf8');assert r.returncode==0
  finally:
   child.terminate();child.wait(timeout=10);server_log.close();owner.update(exitcode=child.returncode,after_identity=process_identity(child.pid));owners.append(owner);save(dest/'owners.json',owners)
 run_id=run.run_id
save(dest/'backend.json',backend);save(dest/'spans.json',spans);save(dest/'http.json',http);save(dest/'parity.json',parity)
summary={'round':int(ROUND),'run_id':run_id,'backend':{},'http':{},'parity_cases':len(parity),'all_parity':all(r['equal'] for r in parity),'spans':len(spans),'owners':owners,'fixture_before':fixture_before,'fixture_after':{n:sha(OUT/(n+'.sqlite')) for n in fixture_before}}
for name in ['small','scale']:
 for lane in ['baseline','candidate']:
  rows=[r for r in backend if r['fixture']==name and r['lane']==lane];summary['backend'][name+'-'+lane]={'first_ms':rows[0]['wall_ms'],'warm_median_ms':statistics.median(r['wall_ms'] for r in rows[1:]),'warm_n':len(rows)-1}
 for route in sorted({r['route'] for r in http}):
  rows=[r for r in http if r['fixture']==name and r['route']==route];summary['http'][name+route]={'first_ms':rows[0]['total_ms'],'warm_median_ms':statistics.median(r['total_ms'] for r in rows[1:]),'bytes':rows[-1]['bytes'],'status':rows[-1]['status'],'warm_n':len(rows)-1}
after_sources=sources();after_protected=protected();save(dest/'sources-after.json',after_sources);save(dest/'protected-after.json',after_protected)
summary.update(source_changed=differences(before_sources,after_sources),protected_changed=differences(before_protected,after_protected),fixture_preserved=summary['fixture_before']==summary['fixture_after'],limits=['first read, not OS cache eviction','synthetic small and scale fixtures; no live database or provider calls','six warm repetitions do not establish tail latency','production-mode Next transport; no installed production-health certification'])
save(dest/'receipt.json',summary);print(json.dumps(summary,indent=2))
