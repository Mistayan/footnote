"""Standalone bounded PUBLIC provider microprofile; never a trading/feed executor.

Run as a module. No yfinance cookie/crumb calls, broker, dotenv or production DB.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import logging
import math
import os
import statistics
import time
from datetime import date, datetime, timedelta, timezone
from pathlib import Path
from typing import Any

from simulator.Relay.fx_feed import FXRateFeed
from simulator.Relay.provider_phases import ProviderResponse, PublicProviderSession
from simulator.observability import span

_PUBLIC_TARGETS = {
    "yfinance": "https://query1.finance.yahoo.com/v8/finance/chart/SPY",
    "ecb": "https://data-api.ecb.europa.eu/service/data/EXR/D.USD.EUR.SP00.A",
}
_EVENT_FIELDS = (
    "operation", "provider", "run_id", "span_id", "parent_span_id", "started_at", "ended_at",
    "duration_ms", "status", "bytes", "rows", "http_status", "cache_hits", "cache_misses",
    "coverage_status", "freshness_status", "inputs_requested", "inputs_available", "error_type",
)


class Capture(logging.Handler):
    def __init__(self) -> None:
        super().__init__()
        self.events: list[dict[str, Any]] = []

    def emit(self, record: logging.LogRecord) -> None:
        if record.msg == "operation.end":
            self.events.append({key: getattr(record, key) for key in _EVENT_FIELDS if hasattr(record, key)})


def normalize_chart(data: dict[str, Any], start: str, as_of: str) -> tuple[list[dict[str, Any]], dict[str, Any]]:
    """Validate daily historical read identity; day bars do not prove policy-time availability."""
    with span("provider_normalize", provider="yfinance") as operation:
        if data["chart"].get("error"):
            raise ValueError("public chart provider error")
        result = data["chart"]["result"][0]
        meta = result["meta"]
        if meta.get("symbol") != "SPY" or meta.get("currency") != "USD" or meta.get("exchangeName") not in {"PCX", "NYSEArca"}:
            raise ValueError("public chart listing mismatch")
        stamps = result["timestamp"]
        closes = result["indicators"]["quote"][0]["close"]
        if len(stamps) != len(closes):
            raise ValueError("public chart row mismatch")
        rows: list[dict[str, Any]] = []
        for stamp, close in zip(stamps, closes, strict=True):
            day = datetime.fromtimestamp(stamp, timezone.utc).date().isoformat()
            if not start <= day <= as_of:
                raise ValueError("public chart outside requested as-of")
            if close is None:
                continue
            if not isinstance(close, (float, int)) or isinstance(close, bool) or not math.isfinite(close) or close <= 0:
                raise ValueError("invalid public chart close")
            rows.append({"date": day, "close_native": float(close)})
        if not rows or len({row["date"] for row in rows}) != len(rows):
            raise ValueError("empty or duplicate public chart dates")
        operation.count(rows=len(rows))
        return rows, {"listing": "SPY/ARCX/USD", "provider_exchange": meta["exchangeName"],
                      "first_consumed_date": min(row["date"] for row in rows),
                      "last_consumed_date": max(row["date"] for row in rows),
                      "price_basis": "daily unadjusted close", "availability_at_policy_cutoff": "unknown"}


def normalize_ecb(data: dict[str, Any], as_of: str) -> tuple[dict[str, float], dict[str, Any]]:
    rates = FXRateFeed.parse_ecb_rates(data)
    values = data["structure"]["dimensions"]["observation"][0]["values"]
    days = {values[int(key)]["id"] for series in data["dataSets"][0]["series"].values()
            for key in series["observations"]}
    if days != {as_of} or set(rates) != {"USD"} or not math.isfinite(rates["USD"]) or rates["USD"] <= 0:
        raise ValueError("ECB missing/invalid requested as-of observation")
    return rates, {"pair": "USD/EUR", "rate_basis": "USD units per EUR", "observation_date": as_of,
                   "availability_at_policy_cutoff": "unknown"}


def normalize(provider: str, data: dict[str, Any], start: str, as_of: str) -> tuple[Any, dict[str, Any]]:
    return normalize_chart(data, start, as_of) if provider == "yfinance" else normalize_ecb(data, as_of)


def digest(value: Any) -> str:
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(",", ":"), allow_nan=False).encode()).hexdigest()


def sample(provider: str, body: bytes, start: str, as_of: str) -> tuple[str, dict[str, Any]]:
    response = ProviderResponse()
    response.provider = provider
    response.content = body
    value, provenance = normalize(provider, response.json(), start, as_of)
    return digest(value), provenance


def summarize(events: list[dict[str, Any]]) -> dict[str, Any]:
    groups: dict[str, list[float]] = {}
    for event in events:
        key = f"{event['operation']}/{event.get('provider', 'unknown')}/{event['status']}"
        groups.setdefault(key, []).append(event["duration_ms"])
    return {key: {"samples": len(values), "min_ms": min(values), "median_ms": statistics.median(values),
                  "max_ms": max(values), "sum_ms": sum(values)} for key, values in sorted(groups.items())}


def run(out: Path, *, start: str, as_of: str, repeats: int, request_budget: int,
        timeout_seconds: float) -> dict[str, Any]:
    start_day, end_day = date.fromisoformat(start), date.fromisoformat(as_of)
    if not 0 <= (end_day - start_day).days <= 7 or not 1 <= repeats <= 3 or request_budget != 2 * repeats:
        raise ValueError("require <=7-day fixture, 1..3 repeats, budget exactly twice repeats")
    scratch = (Path.home() / "AppData/Local/hermes/cache/scratch").resolve()
    if not out.resolve().is_relative_to(scratch) or out.exists():
        raise ValueError("output must be a NEW directory below Hermes scratch")
    out.mkdir(parents=True)
    for key, leaf in (("BORG_STATE_DIR", "state"), ("BORG_TELEMETRY_DIR", "telemetry"),
                      ("BORG_LOGS_DIR", "logs"), ("BORG_QUOTE_CACHE_DIR", "quotes")):
        os.environ[key] = str(out / leaf)
    os.environ["PYTHON_DOTENV_DISABLED"] = "1"
    logger = logging.getLogger("simulator.observability")
    previous_level = logger.level
    capture = Capture()
    logger.addHandler(capture)
    logger.setLevel(logging.INFO)
    samples: list[dict[str, Any]] = []
    params = {
        "yfinance": {"period1": int(datetime.combine(start_day, datetime.min.time(), timezone.utc).timestamp()),
                     "period2": int(datetime.combine(end_day + timedelta(days=1), datetime.min.time(), timezone.utc).timestamp()),
                     "interval": "1d"},
        "ecb": {"format": "jsondata", "startPeriod": as_of, "endPeriod": as_of},
    }
    used = 0
    try:
        with PublicProviderSession(request_budget=request_budget, timeout_seconds=timeout_seconds) as session:
            for repetition in range(repeats):
                for provider in _PUBLIC_TARGETS:
                    cold: dict[str, Any] = {"provider": provider, "repetition": repetition, "lane": "network_read",
                                            "cache_state": "no application response cache", "status": "unknown"}
                    offset = len(capture.events)
                    begun, cpu = time.perf_counter(), time.process_time()
                    try:
                        with span("data_fetch"):
                            response = session.get(_PUBLIC_TARGETS[provider], params=params[provider])
                            cold["http_status"] = response.status_code
                            cold["body_bytes"] = len(response.content)
                            cold["body_sha256"] = hashlib.sha256(response.content).hexdigest()
                            if response.status_code != 200:
                                raise ValueError("public HTTP read failed")
                            # Only public response bodies are retained as scratch fixtures, never telemetry payloads.
                            fixture = f"fixture-{repetition}-{provider}.json"
                            (out / fixture).write_bytes(response.content)
                            cold["fixture"] = fixture
                            value, provenance = normalize(provider, response.json(), start, as_of)
                            cold.update(normalized_sha256=digest(value), provenance=provenance, status="ok")
                    except Exception as exc:
                        cold.update(status="failed", error_type=type(exc).__name__, data_status="unknown")
                    cold.update(wall_ms=(time.perf_counter() - begun) * 1000,
                                process_cpu_ms=(time.process_time() - cpu) * 1000,
                                events=capture.events[offset:])
                    samples.append(cold)
                    if cold["status"] == "ok":
                        for warm_index in range(3):
                            warm: dict[str, Any] = {"provider": provider, "repetition": repetition,
                                                    "warm_index": warm_index, "lane": "same_fixture_replay",
                                                    "fixture_sha256": cold["body_sha256"], "network_requests": 0}
                            offset = len(capture.events)
                            begun, cpu = time.perf_counter(), time.process_time()
                            with span("cache_read", provider="cache") as operation:
                                body = (out / cold["fixture"]).read_bytes()
                                operation.count(bytes=len(body), cache_hits=1)
                            try:
                                with span("data_fetch"):
                                    normalized_sha, provenance = sample(provider, body, start, as_of)
                                    if normalized_sha != cold["normalized_sha256"]:
                                        raise ValueError("same-fixture normalization parity failed")
                                    warm.update(status="ok", normalized_sha256=normalized_sha, provenance=provenance)
                            except Exception as exc:
                                warm.update(status="failed", error_type=type(exc).__name__)
                            warm.update(wall_ms=(time.perf_counter() - begun) * 1000,
                                        process_cpu_ms=(time.process_time() - cpu) * 1000,
                                        events=capture.events[offset:])
                            samples.append(warm)
            used = session.requests_used
    finally:
        logger.removeHandler(capture)
        logger.setLevel(previous_level)
    root = Path(__file__).resolve().parents[1]
    sources = ["scripts/profile_provider_phases.py", "simulator/Relay/provider_phases.py",
               "simulator/Relay/fx_feed.py", "simulator/Relay/quote_fetcher.py",
               "simulator/Database/data_engine.py", "simulator/observability.py"]
    receipt = {"schema": "provider-phase-profile-v1", "measured_at": datetime.now(timezone.utc).isoformat(),
               "start": start, "as_of": as_of, "listing": "SPY/ARCX/USD", "fx": "USD/EUR ECB daily",
               "request_budget": request_budget, "requests_used": used, "timeout_seconds": timeout_seconds,
               "retries": 0, "redirects": False, "authentication": "none", "production_db_access": False,
               "cold_definition": "first application response read; NOT OS/DNS/TLS cold-cache eviction",
               "warm_definition": "same captured response bytes; disk read + JSON parse + normalize; zero network",
               "tail_latency": "not estimated: bounded sample count", "samples": samples,
               "phase_summary": summarize(capture.events),
               "source_sha256": {path: hashlib.sha256((root / path).read_bytes()).hexdigest() for path in sources},
               "limits": ["public chart path is not the complete yfinance fast_info/fallback caller",
                          "SDK envelope is not split into network and CPU in normal application telemetry",
                          "process CPU is whole-sample CPU, not per-phase thread CPU",
                          "daily historical bars/rates do not prove policy-cutoff availability"]}
    (out / "receipt.json").write_text(json.dumps(receipt, indent=2, allow_nan=False), encoding="utf-8")
    return receipt


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--out", required=True, type=Path)
    parser.add_argument("--start", required=True)
    parser.add_argument("--as-of", required=True)
    parser.add_argument("--repeats", type=int, default=2)
    parser.add_argument("--request-budget", type=int, default=4)
    parser.add_argument("--timeout-seconds", type=float, default=10)
    args = parser.parse_args()
    receipt = run(args.out, start=args.start, as_of=args.as_of, repeats=args.repeats,
                  request_budget=args.request_budget, timeout_seconds=args.timeout_seconds)
    failures = sum(row["status"] != "ok" for row in receipt["samples"])
    print(json.dumps({"receipt": str(args.out / "receipt.json"), "requests_used": receipt["requests_used"],
                      "samples": len(receipt["samples"]), "failed_samples": failures}))
    return int(failures > 0)


if __name__ == "__main__":
    raise SystemExit(main())
