"""Source/docs-frozen, protected-byte-bound offline final integration gates.

No domain database opens, jobs, network campaign, stop/restore, commit or push.
The Python guard is not a native-process sandbox. Exit codes, source stability,
protected preservation and guard evidence are deliberately separate verdicts.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
from typing import Any
from xml.etree import ElementTree

ROOT = Path(__file__).resolve().parents[1]
PROTECTED = ('data', 'state', 'reports', 'dashboard/public', 'public_site')
SKIP = {'.git', '.venv', 'node_modules', '.next', '__pycache__', '.mypy_cache',
        '.ruff_cache', '.pytest_cache', 'worktrees', 'target', 'test-results',
        '.beads', '.gitnexus', '.playwright-cli'}
EXTENSIONS = {'.py', '.ts', '.tsx', '.js', '.mjs', '.cjs', '.json', '.toml',
              '.md', '.yaml', '.yml', '.ps1', '.sh', '.rs', '.html', '.css', '.lock'}


def digest(path: Path) -> str:
    value = hashlib.sha256()
    with path.open('rb') as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b''):
            value.update(chunk)
    return value.hexdigest()


def protected() -> dict[str, str]:
    return {p.relative_to(ROOT).as_posix(): digest(p) for folder in PROTECTED
            for p in (ROOT / folder).rglob('*') if p.is_file()}


def sources() -> dict[str, str]:
    result = {}
    for directory, children, files in os.walk(ROOT):
        parent = Path(directory)
        children[:] = [name for name in children if name not in SKIP
                       and not any((parent / name).is_relative_to(ROOT / item) for item in PROTECTED)]
        for name in files:
            path = parent / name
            if path.suffix in EXTENSIONS and not name.endswith('.tsbuildinfo'):
                result[path.relative_to(ROOT).as_posix()] = digest(path)
    return result


def differences(before: dict[str, str], after: dict[str, str]) -> list[str]:
    return sorted(key for key in before.keys() | after.keys() if before.get(key) != after.get(key))


def run_gate(command: list[str], cwd: Path, env: dict[str, str], *, timeout: float = 600) -> tuple[str, dict[str, Any]]:
    """Own one child handle; preserve timeout evidence instead of abandoning it."""
    from simulator.run_registry import process_identity
    effective = list(command)
    child_env = env.copy()
    if os.name == 'nt' and command[0] == sys.executable:
        # Bypass the Windows venv redirector, preserving its venv getpath contract.
        # This owns the actual interpreter handle, not a launcher with an orphanable child.
        effective[0] = sys._base_executable
        child_env['__PYVENV_LAUNCHER__'] = sys.executable
    try:
        process = subprocess.Popen(effective, cwd=cwd, env=child_env, stdout=subprocess.PIPE,
                                   stderr=subprocess.STDOUT, text=True)
    except OSError as error:
        return '', {'command': command, 'cwd': str(cwd), 'pid': None,
                    'creation_identity': None, 'after_identity': None,
                    'timed_out': False, 'returncode': 127, 'error_type': type(error).__name__}
    identity = process_identity(process.pid)
    timed_out = False
    try:
        log, _ = process.communicate(timeout=timeout)
    except subprocess.TimeoutExpired:
        timed_out = True
        # Popen's retained Windows handle identifies this exact owned child,
        # not an arbitrary PID lookup. Never stop unrelated/production jobs.
        process.terminate()
        try:
            log, _ = process.communicate(timeout=5)
        except subprocess.TimeoutExpired:
            process.kill()
            log, _ = process.communicate(timeout=5)
    return log, {'command': command, 'effective_command': effective, 'cwd': str(cwd), 'pid': process.pid,
                 'creation_identity': identity, 'after_identity': process_identity(process.pid),
                 'timed_out': timed_out, 'returncode': process.returncode}


def exact_process_owned(exact: dict[str, Any] | None, gate: dict[str, Any]) -> bool:
    # Windows venv redirectors retain a launcher PID and run Python in its child.
    # Use the receipt's exact interpreter PID + kernel creation identity and
    # explicit immediate-parent chain; do not equate the launcher with pytest.
    return bool(exact and exact.get('identity') not in (None, 'absent')
                and (exact.get('pid') == gate['pid'] or exact.get('parent_pid') == gate['pid']))


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--out', type=Path, required=True)
    args = parser.parse_args()
    out = args.out.resolve()
    scratch = (Path.home() / 'AppData/Local/hermes/cache/scratch').resolve()
    if not out.is_relative_to(scratch) or out.exists():
        raise ValueError('new explicit scratch directory required')
    out.mkdir(parents=True)
    env = os.environ.copy()
    for key in tuple(env):
        if key.startswith(('BORG_RUN_', 'BORG_OPERATIONAL_ALERT')) or key in {'BORG_PARENT_RUN_ID', 'BORG_RESTATEMENT_DIR'}:
            env.pop(key)
    env['PYTHON_DOTENV_DISABLED'] = '1'
    env['COVERAGE_FILE'] = str(out / '.coverage')
    env['NUMBA_CACHE_DIR'] = str(out / 'numba')
    before_source, before_protected = sources(), protected()
    for name, value in [('sources-before', before_source), ('protected-before', before_protected)]:
        (out / (name + '.json')).write_text(json.dumps(value, indent=2), encoding='utf-8')
    pytest_args = ['tests/', '-q', '-o', 'filterwarnings=error', '-o',
                   'asyncio_default_fixture_loop_scope=function', '-p', 'no:cacheprovider',
                   '--basetemp', str(out / 'pytest'), '--junitxml', str(out / 'junit.xml')]
    code = ('import json,os,pytest\n'
            'try:\n'
            f'    rc=pytest.main({pytest_args!r})\n'
            'finally:\n'
            '    from simulator.run_registry import process_identity\n'
            '    print("BORG_EXACT_PROCESS="+json.dumps({"pid":os.getpid(),"parent_pid":os.getppid(),"identity":process_identity(os.getpid()),"guard":os.environ.get("BORG_TEST_GUARD_RECEIPT")}))\n'
            'raise SystemExit(rc)\n')
    commands = {
        'pytest_full_strict': ([sys.executable, '-W', 'error', '-c', code], ROOT),
        'ruff_configured': ([sys.executable, '-m', 'ruff', 'check', 'simulator',
                             'scripts/verify_state_alert_refresh_integration.py',
                             'tests/test_registry_alert_integration.py', 'tests/test_state_attribution.py'], ROOT),
        'mypy_configured': ([sys.executable, '-m', 'mypy'], ROOT),
        'mypy_strict_new_modules': ([sys.executable, '-m', 'mypy', '--strict',
                                    'simulator/state_attribution.py', 'simulator/operational_alerts.py',
                                    'simulator/Database/incremental_refresh.py', 'simulator/run_registry.py',
                                    'simulator/Database/sentinel_store.py', 'scripts/profile_incremental_refresh.py',
                                    'scripts/verify_state_alert_refresh_integration.py'], ROOT),
        'dashboard_type': (['node', str(ROOT / 'dashboard/node_modules/typescript/bin/tsc'), '--noEmit', '--incremental', 'false'], ROOT / 'dashboard'),
        'dashboard_alert_loader': (['node', str(ROOT / 'dashboard/node_modules/@playwright/test/cli.js'), 'test', '--config=playwright.alerts.config.ts'], ROOT / 'dashboard'),
    }
    gates: dict[str, Any] = {}
    exact_process = None
    for name, (command, cwd) in commands.items():
        log, gate = run_gate(command, cwd, env)
        (out / (name + '.log')).write_text(log, encoding='utf-8')
        gates[name] = gate
        if name == 'pytest_full_strict':
            for line in log.splitlines():
                if line.startswith('BORG_EXACT_PROCESS='):
                    exact_process = json.loads(line.split('=', 1)[1])
        print(name, gate['returncode'], flush=True)
    after_source, after_protected = sources(), protected()
    for name, value in [('sources-after', after_source), ('protected-after', after_protected)]:
        (out / (name + '.json')).write_text(json.dumps(value, indent=2), encoding='utf-8')
    attempts = None
    if exact_process:
        guard = Path(exact_process['guard'])
        rows = guard.read_text(encoding='utf-8').splitlines() if guard.exists() else []
        attempts = len(rows)
        (out / 'exact-guard.jsonl').write_text('\n'.join(rows), encoding='utf-8')
    totals = {}
    if (out / 'junit.xml').exists():
        tree = ElementTree.parse(out / 'junit.xml').getroot()
        totals = {field: sum(int(s.get(field, '0')) for s in tree.iter('testsuite'))
                  for field in ('tests', 'failures', 'errors', 'skipped')}
    source_changed = differences(before_source, after_source)
    protected_changed = differences(before_protected, after_protected)
    accepted = (all(g['returncode'] == 0 for g in gates.values()) and attempts == 0
                and not source_changed and not protected_changed and exact_process is not None
                and exact_process_owned(exact_process, gates['pytest_full_strict']))
    receipt = {'schema': 'state-alert-refresh-integration-acceptance-v1', 'accepted': accepted,
               'gates': gates, 'junit_totals': totals, 'exact_pytest_process': exact_process,
               'guard_attempts': attempts, 'source_files': len(before_source),
               'protected_files': len(before_protected), 'source_changed': source_changed,
               'protected_changed': protected_changed,
               'limits': ['configured mypy covers Engine/Relay only; separate strict gate covers seven explicit changed/new modules',
                          'JUnit includes successful subtests; skipped includes xfails',
                          'all-source/docs freeze excludes protected/generated/dependency/worktree directories',
                          'Python guard is not a native-process sandbox',
                          'no browser certification in this aggregate receipt',
                          'no accounting, freshness, promotion or live health certification',
                          'no independent reviewer score is fabricated'],
               'artifacts_sha256': {p.name: digest(p) for p in out.iterdir() if p.is_file()}}
    (out / 'receipt.json').write_text(json.dumps(receipt, indent=2), encoding='utf-8')
    print(json.dumps({'receipt': str(out / 'receipt.json'), 'receipt_sha256': digest(out / 'receipt.json'),
                      'accepted': accepted, 'junit': totals, 'guard_attempts': attempts,
                      'source_changed': source_changed, 'protected_changed': protected_changed}, indent=2))
    return int(not accepted)


if __name__ == '__main__':
    raise SystemExit(main())
