"""Pinned 9406006 vs current offline real-caller request-boundary comparison.

Uses bounded public captured bytes. Counts SDK/enrichment calls, not HTTP. No
production cache or DB acquisition; output restricted to a new scratch directory.
"""
from __future__ import annotations
import argparse
import asyncio
import hashlib
import importlib.util
from importlib.metadata import version
import json
import os
import time
import warnings
from datetime import datetime, timedelta, tzinfo
from pathlib import Path
from typing import Any
from unittest.mock import patch
import pandas as pd
from scripts.profile_provider_phases import normalize_chart, normalize_ecb
from simulator.Database import data_engine

PINNED_REVISION = '940600638b1aeea1bf1a6098063865e6cabf90ed'
PINNED_SHA256 = '07627aa2e548e04c3c4526c352001a294d09cefef767708d606578815e63a934'


def compare_offline(baseline: Path, out: Path) -> dict[str, Any]:
    """Execute the real fetch/normalization/indicator/FX/cache path offline.

    The deterministic adapter is the SDK boundary, not a transport simulator.
    Fixtures intentionally lack annual warmup/provenance: parity is bounded,
    never economic certification or measured public-network improvement.
    """
    from simulator import pathing

    scratch = (Path.home() / 'AppData/Local/hermes/cache/scratch').resolve()
    if not out.resolve().is_relative_to(scratch) or out.exists():
        raise ValueError('new scratch output required')
    if hashlib.sha256(baseline.read_bytes()).hexdigest() != PINNED_SHA256:
        raise ValueError('baseline does not match literal pinned revision')
    out.mkdir(parents=True)
    spec = importlib.util.spec_from_file_location('pinned_refresh_offline', baseline)
    assert spec is not None and spec.loader is not None
    legacy = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(legacy)

    class FrozenDatetime(datetime):
        @classmethod
        def now(cls, tz: tzinfo | None = None) -> FrozenDatetime:
            return cls(2026, 10, 15, 12, tzinfo=tz)

    days = pd.to_datetime(['2026-09-28', '2026-09-29', '2026-09-30', '2026-10-01', '2026-10-02'])
    symbols = sorted(set(data_engine.BREADTH_TICKERS + ['SPY', '^GSPC', '^VIX', 'SH', 'PSQ', 'SQQQ', 'SGOV', 'BIL', 'EURUSD=X']))
    values = {}
    for symbol in symbols:
        for column in ['Open', 'High', 'Low', 'Close', 'Volume']:
            values[column, symbol] = [
                (1.10 + i / 1000) if symbol == 'EURUSD=X' else
                (10000.0 if column == 'Volume' else 100.0 + i + symbols.index(symbol) / 10)
                for i in range(len(days))]
    fixture = pd.DataFrame(values, index=days)
    fixture.index.name = 'Date'
    (out / 'fixture.json').write_text(fixture.to_json(orient='split'), encoding='utf-8')
    lanes: dict[str, Any] = {}
    outputs: dict[str, list[str]] = {}
    missing_fx_refused = False
    policy = asyncio.get_event_loop_policy()
    borrowed = getattr(policy._local, '_loop', None)
    try:
        for name, module in [('before', legacy), ('after', data_engine)]:
            samples, calls, outputs[name] = [], [], []
            for repetition in range(3):
                lane = out / name / str(repetition)
                lane.mkdir(parents=True)
                environment = {key: str(lane / leaf) for key, leaf in (
                    ('BORG_STATE_DIR', 'state'), ('BORG_LOGS_DIR', 'logs'),
                    ('BORG_TELEMETRY_DIR', 'telemetry'), ('BORG_QUOTE_CACHE_DIR', 'quotes'))}
                environment.update(CACHE_ONLY='0', PYTHON_DOTENV_DISABLED='1', BORG_DATA_BATCH_PAUSE_SECONDS='0')
                with patch.dict(os.environ, environment), patch.object(module, 'datetime', FrozenDatetime):
                    pathing.state_dir.cache_clear()
                    engine = module.DataEngine(['SPY'], '2026-09-28', '2026-10-03', ai_mode=True)
                    for key in ('CACHE_FILE', 'CACHE_V2_FILE', 'CACHE_ARCHIVE_FILE', 'CACHE_DUCKDB_FILE'):
                        setattr(engine, key, str(lane / (key + ('.duckdb' if key == 'CACHE_DUCKDB_FILE' else '.parquet'))))

                    def download(chunk: list[str], **kwargs: Any) -> pd.DataFrame:
                        calls.append({'symbols': list(chunk), 'kwargs': kwargs})
                        if len(calls) > 6:
                            raise RuntimeError('offline SDK budget exceeded')
                        return fixture.loc[(fixture.index >= kwargs['start']) & (fixture.index < kwargs['end']),
                                           fixture.columns.get_level_values(1).isin(chunk)].copy()

                    with patch.object(module.yf, 'download', side_effect=download), warnings.catch_warnings(record=True) as captured:
                        # The archived oracle uses deprecated Polars keyword names.
                        # Retain those diagnostics explicitly; never hide resource,
                        # unraisable or other warning classes behind this replay.
                        warnings.simplefilter('error')
                        warnings.filterwarnings('always', message=r'.*(min_periods|default).*deprecated.*',
                                                category=DeprecationWarning)
                        wall, cpu = time.perf_counter(), time.process_time()
                        if name == 'after':
                            engine.fetch_data(batch_size=500, refresh_policy='refresh')
                        else:
                            engine.fetch_data(batch_size=500)
                        elapsed, used_cpu = time.perf_counter() - wall, time.process_time() - cpu
                    frame = engine.combined_df.sort(['Ticker', 'trade_date'])
                    serialized = frame.write_json()
                    outputs[name].append(serialized)
                    (lane / 'output.json').write_text(serialized, encoding='utf-8')
                    samples.append({'wall_ms': elapsed * 1000, 'cpu_ms': used_cpu * 1000,
                                    'rows': frame.height, 'output_sha256': hashlib.sha256(serialized.encode()).hexdigest(),
                                    'deprecations': [str(warning.message) for warning in captured],
                                    'exact_fx': all(abs(row['fx_rate'] - (1.10 + list(days.strftime('%Y-%m-%d')).index(row['trade_date']) / 1000)) < 1e-12
                                                    for row in frame.iter_rows(named=True))})
            lanes[name] = {'sdk_boundary_calls': len(calls), 'calls': calls, 'samples': samples}

        engine = data_engine.DataEngine(['SPY'], '2026-09-28', '2026-10-03', ai_mode=True)
        async def missing_fx(*args: Any) -> list[Any]:
            import polars as pl
            return [pl.DataFrame({'Ticker': ['SPY'], 'trade_date': ['2026-09-28'], 'Close': [100.0]})]
        with patch.dict(os.environ, {'CACHE_ONLY': '0'}), patch.object(engine, '_fetch_all_batches_async', missing_fx):
            try:
                engine.fetch_data(refresh_policy='refresh')
            except RuntimeError as error:
                missing_fx_refused = 'exact FX' in str(error) and engine.combined_df is None
    finally:
        pathing.state_dir.cache_clear()
        policy.set_event_loop(borrowed)

    result = {
        'schema': 'incremental-refresh-offline-full-path-v1', 'baseline_revision': PINNED_REVISION,
        'baseline_sha256': PINNED_SHA256, 'fixture_kind': 'deterministic synthetic SDK responses',
        'fixture_sha256': hashlib.sha256((out / 'fixture.json').read_bytes()).hexdigest(),
        'start': '2026-09-28', 'end_exclusive': '2026-10-03', 'clock': '2026-10-15T12:00:00',
        'lanes': lanes, 'exact_economic_parity': outputs['before'] == outputs['after'] and bool(outputs['before']),
        'network_requests': 0, 'public_requests_used': 0,
        'sdk_attempt_budget_per_lane': 6,
        'versions': {package: version(package) for package in ['yfinance', 'pandas', 'polars', 'duckdb']},
        'cpu_clock_resolution_seconds': time.get_clock_info('process_time').resolution,
        'sdk_calls_avoided': lanes['before']['sdk_boundary_calls'] - lanes['after']['sdk_boundary_calls'],
        'missing_fx_refused': missing_fx_refused, 'certification': False,
        'source_sha256': {str(p): hashlib.sha256(p.read_bytes()).hexdigest() for p in
                          [Path(__file__), Path(data_engine.__file__), Path(data_engine.__file__).with_name('incremental_refresh.py'),
                           *[Path(data_engine.__file__).parents[1] / relative for relative in
                             ['Relay/provider_phases.py', 'provider_resilience.py', 'provider_limits.py',
                              'Engine/volatility_engine.py', 'TradingPlatform/UNIMATRIX/numba_utils.py',
                              'cache_coordination.py', 'pathing.py', 'observability.py']]]},
        'limits': ['synthetic SDK boundary counts are not hidden HTTP counts or public performance',
                   'first sample includes process/JIT warmup; no OS cold-cache eviction',
                   'only DataEngine oracle is pinned; helper dependencies are shared current hash-bound sources',
                   'five fixture sessions do not cover annual warmup or independently validated provenance',
                   'strict exact-FX refusal is new opt-in behavior; default legacy FX fallbacks remain uncertified',
                   'no automatic skipping, tail refresh, adjustment revision validation or network savings certified'],
    }
    (out / 'receipt.json').write_text(json.dumps(result, indent=2), encoding='utf-8')
    return result


def compare(public: Path, baseline: Path, out: Path) -> dict[str, Any]:
    scratch = (Path.home() / 'AppData/Local/hermes/cache/scratch').resolve()
    if not out.resolve().is_relative_to(scratch) or out.exists():
        raise ValueError('new scratch output required')
    if hashlib.sha256(baseline.read_bytes()).hexdigest() != PINNED_SHA256:
        raise ValueError('baseline does not match literal pinned revision')
    receipt = json.loads((public / 'receipt.json').read_text())
    bodies = {}
    for sample in receipt['samples']:
        if sample['lane'] == 'network_read' and sample['repetition'] == 0 and sample['status'] == 'ok':
            body = (public / sample['fixture']).read_bytes()
            if hashlib.sha256(body).hexdigest() != sample['body_sha256']:
                raise ValueError('fixture hash mismatch')
            bodies[sample['provider']] = body
    rows, _ = normalize_chart(json.loads(bodies['yfinance']), receipt['start'], receipt['as_of'])
    rates, _ = normalize_ecb(json.loads(bodies['ecb']), receipt['as_of'])
    spec = importlib.util.spec_from_file_location('pinned_refresh_baseline', baseline)
    legacy = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(legacy)
    frame = pd.DataFrame([[r['close_native']] for r in rows],
                         index=pd.to_datetime([r['date'] for r in rows]),
                         columns=pd.MultiIndex.from_tuples([('Close', 'SPY')]))
    lanes: dict[str, Any] = {}
    for name, module in [('before', legacy), ('after', data_engine)]:
        engine = object.__new__(module.DataEngine)
        engine.fetch_start, engine.ai_mode = receipt['start'], True
        outputs = []
        with patch.object(module.yf, 'download', return_value=frame) as sdk:
            for _ in range(3):
                start = datetime.fromisoformat(receipt['start'])
                end = datetime.fromisoformat(receipt['as_of'])
                frames = asyncio.run(engine._fetch_batch_async(0, ['SPY'], start,
                                      end + timedelta(days=2), end + timedelta(days=1)))
                outputs.append([f.to_dicts() for f in frames])
        lanes[name] = {'sdk_boundary_calls': sdk.call_count, 'network_requests': 0,
                       'outputs': outputs}
    result = {'schema': 'incremental-refresh-measurement-v1', 'baseline_revision': PINNED_REVISION,
              'baseline_sha256': PINNED_SHA256, 'repeats': 3,
              'source_sha256': {str(p): hashlib.sha256(p.read_bytes()).hexdigest() for p in
                    [Path(__file__), Path(data_engine.__file__), Path(data_engine.__file__).with_name('incremental_refresh.py')]},
              'fixture_sha256': {p: hashlib.sha256(b).hexdigest() for p, b in bodies.items()},
              'public_requests_used': receipt['requests_used'], 'fx_last_date_rate': rates,
              'lanes': lanes, 'exact_parity': lanes['before']['outputs'] == lanes['after']['outputs'],
              'actual_network_requests_avoided': 0,
              'sdk_calls_avoided': lanes['before']['sdk_boundary_calls'] - lanes['after']['sdk_boundary_calls'],
              'certification': False,
              'limits': ['offline SDK normalization replay is not network latency',
                         'ECB single end-date rate is not full-window FX session coverage',
                         'no executable listing/session/adjustment/FX receipt adapter: no automatic skip enabled',
                         'wrapper rc alone does not certify economics; compare exact nonempty outputs']}
    out.mkdir(parents=True)
    (out / 'receipt.json').write_text(json.dumps(result, default=str, indent=2), encoding='utf-8')
    return result


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--public-fixtures', type=Path)
    parser.add_argument('--baseline', type=Path, required=True)
    parser.add_argument('--out', type=Path, required=True)
    args = parser.parse_args()
    if args.public_fixtures:
        r = compare(args.public_fixtures, args.baseline, args.out)
        accepted = r['exact_parity']
    else:
        r = compare_offline(args.baseline, args.out)
        accepted = r['exact_economic_parity'] and r['missing_fx_refused']
    print(json.dumps({'accepted': accepted, 'sdk_calls_avoided': r['sdk_calls_avoided'], 'receipt': str(args.out / 'receipt.json')}))
    raise SystemExit(0 if accepted else 1)
