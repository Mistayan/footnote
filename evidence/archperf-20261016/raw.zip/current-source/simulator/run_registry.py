"""Durable operational receipts, independent of accounting/promotion.

SQLite transactions serialize cooperating processes on local Windows/POSIX disks.
No domain store is accessed; no connection/thread is created on import.
"""
from __future__ import annotations

import ctypes
import json
import math
import os
import re
import sqlite3
import uuid
from collections.abc import Callable, Iterator, Mapping
from contextlib import closing, contextmanager
from contextvars import ContextVar
from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
from pathlib import Path
from threading import Event, Thread
from typing import Any

from simulator.run_registry_maintenance import RetentionPolicy, prune_terminal

_NAMES = frozenset({"cli", "monitor", "sentinel", "script", "cache_update", "news_feed", "unknown"})
_OPERATION_NAMES = _NAMES | frozenset({
    "feed_cycle", "feed_context", "dashboard_feed", "public_snapshot", "cache_read", "parquet_read",
    "duckdb_read", "data_fetch", "quote", "quote_batch", "quote_provider", "quote_cache_load",
    "quote_cache_write", "serialization", "db_snapshot",
})
_TERMINAL = frozenset({"ok", "partial", "failed", "timeout", "interrupted", "recovered_orphan"})
_KINDS = frozenset({"start", "heartbeat", "end", "input", "operation", "manifest", "task"})
_TASKS = frozenset({
    "monitor", "sentinel", "screener", "sma150-screen", "audit", "freeze-state", "borgdiv-screen",
    "borgdiv-backtest", "borgdiv-exit", "borgpea-screen", "borgpea-backtest", "shadow-status",
    "telegram-bot", "divcal-refresh", "claude-competitors", "momentumb-shadow", "refresh-dashboard",
    "equity-update", "etf-allocation-backtest", "comparison-audit", "comparison-migration-audit",
    "holdings-refresh", "cto-backtest", "cache_update", "news_feed", "unknown",
})
_current: ContextVar[RunContext | None] = ContextVar("borg_durable_run", default=None)


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


def _uuid(value: str | None) -> str | None:
    if value is None:
        return None
    if str(uuid.UUID(value)) != value:
        raise ValueError("noncanonical run identifier")
    return value


def _instant(value: str) -> str:
    parsed = datetime.fromisoformat(value)
    if parsed.tzinfo is None:
        raise ValueError("aware timestamp required")
    return parsed.astimezone(timezone.utc).isoformat()


def process_identity(pid: int) -> str | None:
    """Kernel creation identity, never PID-only. Permission/platform ambiguity => None."""
    if os.name == "nt":
        from ctypes import wintypes
        kernel = ctypes.WinDLL("kernel32", use_last_error=True)
        kernel.OpenProcess.argtypes = [wintypes.DWORD, wintypes.BOOL, wintypes.DWORD]
        kernel.OpenProcess.restype = wintypes.HANDLE
        kernel.GetProcessTimes.argtypes = [wintypes.HANDLE] + [ctypes.POINTER(wintypes.FILETIME)] * 4
        kernel.GetProcessTimes.restype = wintypes.BOOL
        kernel.CloseHandle.argtypes = [wintypes.HANDLE]
        handle = kernel.OpenProcess(0x1000, False, pid)
        if not handle:
            # ERROR_INVALID_PARAMETER proves no such PID, not access denied.
            return "absent" if ctypes.get_last_error() == 87 else None
        try:
            created, exited, system, user = (wintypes.FILETIME() for _ in range(4))
            if not kernel.GetProcessTimes(handle, ctypes.byref(created), ctypes.byref(exited),
                                          ctypes.byref(system), ctypes.byref(user)):
                return None
            if exited.dwHighDateTime or exited.dwLowDateTime:
                return "absent"
            return f"windows:{(created.dwHighDateTime << 32) | created.dwLowDateTime}"
        finally:
            kernel.CloseHandle(handle)
    try:
        stat = Path(f"/proc/{pid}/stat").read_text(encoding="ascii")
        boot = Path("/proc/sys/kernel/random/boot_id").read_text(encoding="ascii").strip()
        fields = stat.rsplit(')', 1)[1].split()
        if fields[0] in {"Z", "X"}:
            return "absent"
        return f"linux:{boot}:{fields[19]}"
    except FileNotFoundError:
        return "absent" if Path("/proc/self/stat").exists() else None
    except (OSError, IndexError):
        return None


@dataclass(frozen=True)
class ConsumedInput:
    """Only actual consumed coverage, not cache/renderer dates or inferred currencies."""
    role: str
    listing: str
    source_sha256: str | None = None
    required_session: str | None = None
    consumed_session: str | None = None
    rows: int | None = None

    def receipt(self) -> dict[str, object]:
        if self.role not in {"listing", "benchmark", "fx"}:
            raise ValueError("invalid input role")
        if not re.fullmatch(r"[A-Z0-9^][A-Z0-9.^:/_-]{0,47}", self.listing):
            raise ValueError("invalid bounded listing identifier")
        if self.source_sha256 is not None and not re.fullmatch(r"[a-f0-9]{64}", self.source_sha256):
            raise ValueError("invalid source digest")
        if self.rows is not None and (type(self.rows) is not int or not 0 <= self.rows <= 10**12):
            raise ValueError("invalid consumed row count")
        required = _instant(self.required_session) if self.required_session else None
        consumed = _instant(self.consumed_session) if self.consumed_session else None
        freshness = "unknown"
        if required and consumed and self.source_sha256 and self.rows:
            freshness = "complete" if consumed == required else "stale" if consumed < required else "unknown"
        return {"role": self.role, "listing": self.listing, "source_sha256": self.source_sha256,
                "required_session": required, "consumed_session": consumed, "rows": self.rows,
                "freshness_status": freshness}


class RunRegistry:
    """Dedicated receipt database with bounded waits and immutable event history."""

    def __init__(self, path: Path, *, lock_timeout: float = 5.0,
                 maintenance_seconds: float = 300.0, maintenance_batch: int = 128,
                 retention: RetentionPolicy | None = None) -> None:
        self.retention = retention or RetentionPolicy()
        self.path = path
        self.lock_timeout = lock_timeout
        if not math.isfinite(maintenance_seconds) or not 0.01 <= maintenance_seconds <= 86400:
            raise ValueError("maintenance interval must be in [0.01, 86400]")
        if type(maintenance_batch) is not int or not 1 <= maintenance_batch <= 1024:
            raise ValueError("maintenance batch must be in [1, 1024]")
        self.maintenance_seconds = maintenance_seconds
        self.maintenance_batch = maintenance_batch
        if lock_timeout <= 0 or lock_timeout > 60:
            raise ValueError("lock timeout must be in (0, 60]")

    @contextmanager
    def _db(self) -> Iterator[sqlite3.Connection]:
        self.path.parent.mkdir(parents=True, exist_ok=True)
        with closing(sqlite3.connect(self.path, timeout=self.lock_timeout)) as db:
            db.row_factory = sqlite3.Row
            db.execute("PRAGMA foreign_keys=ON")
            # Include the implicit old-row DELETE in REPLACE attribution.
            # Observer callbacks never write rows or recursively invoke _db.
            db.execute("PRAGMA recursive_triggers=ON")
            db.execute("PRAGMA synchronous=FULL")
            if db.execute("PRAGMA user_version").fetchone()[0] not in (0, 1):
                raise ValueError("unsupported registry schema")
            if db.execute("PRAGMA user_version").fetchone()[0] == 0:
                # New dedicated databases only; never VACUUM/migrate an existing live file.
                db.execute("PRAGMA auto_vacuum=INCREMENTAL")
            with db:
                db.execute("CREATE TABLE IF NOT EXISTS runs (run_id TEXT PRIMARY KEY, parent_run_id TEXT, "
                           "name TEXT NOT NULL, pid INTEGER NOT NULL, identity TEXT, started_at TEXT NOT NULL, "
                           "heartbeat_at TEXT NOT NULL, ended_at TEXT, status TEXT NOT NULL)")
                db.execute("CREATE TABLE IF NOT EXISTS receipts (sequence INTEGER PRIMARY KEY AUTOINCREMENT, "
                           "run_id TEXT NOT NULL REFERENCES runs(run_id), kind TEXT NOT NULL, "
                           "at TEXT NOT NULL, body TEXT NOT NULL)")
                db.execute("CREATE INDEX IF NOT EXISTS receipts_run ON receipts(run_id, sequence)")
                db.execute("CREATE INDEX IF NOT EXISTS runs_status ON runs(status, run_id)")
                db.execute("CREATE INDEX IF NOT EXISTS runs_parent ON runs(parent_run_id)")
                db.execute("CREATE INDEX IF NOT EXISTS runs_started ON runs(started_at DESC, run_id)")
                db.execute("CREATE TABLE IF NOT EXISTS registry_maintenance (singleton INTEGER PRIMARY KEY "
                           "CHECK(singleton=1), last_at TEXT NOT NULL, recovery_cursor TEXT NOT NULL)")
                db.execute("CREATE TABLE IF NOT EXISTS registry_maintenance_stats (singleton INTEGER PRIMARY KEY "
                           "CHECK(singleton=1), body TEXT NOT NULL)")
                db.execute("CREATE TRIGGER IF NOT EXISTS immutable_receipt BEFORE UPDATE ON receipts "
                           "BEGIN SELECT RAISE(ABORT, 'immutable receipt'); END")
                db.execute("PRAGMA user_version=1")
            # TEMP triggers observe actual row writes without storing their payloads.
            # Audit rows are excluded: no recursive record-writer or second lock.
            from simulator.state_attribution import digest, writer_identity
            import hashlib

            before_hash, after_hash = hashlib.sha256(), hashlib.sha256()
            changed = [0]

            def observe(table: str, old: str, new: str) -> int:
                before_hash.update(json.dumps([table, old], separators=(",", ":")).encode())
                after_hash.update(json.dumps([table, new], separators=(",", ":")).encode())
                changed[0] += 1
                return 0

            db.create_function("observe_mutation", 3, observe)
            for table in ("runs", "receipts", "registry_maintenance", "registry_maintenance_stats"):
                columns = [row[1] for row in db.execute(f"PRAGMA table_info({table})")]
                old = "json_array(" + ",".join("OLD." + column for column in columns) + ")"
                new = "json_array(" + ",".join("NEW." + column for column in columns) + ")"
                for operation, previous, following in (("INSERT", "'null'", new),
                                                       ("UPDATE", old, new), ("DELETE", old, "'null'")):
                    db.execute(f"CREATE TEMP TRIGGER observe_{table}_{operation} AFTER {operation} ON {table} "
                               f"BEGIN SELECT observe_mutation('{table}',{previous},{following}); END")
            with db:
                db.execute("CREATE TABLE IF NOT EXISTS state_mutations(sequence INTEGER PRIMARY KEY AUTOINCREMENT, "
                           "mutation_id TEXT UNIQUE NOT NULL, body TEXT NOT NULL)")
                db.execute("CREATE TRIGGER IF NOT EXISTS immutable_mutation BEFORE UPDATE ON state_mutations "
                           "BEGIN SELECT RAISE(ABORT, 'immutable mutation'); END")
                db.execute("CREATE TRIGGER IF NOT EXISTS immutable_mutation_delete BEFORE DELETE ON state_mutations "
                           "BEGIN SELECT RAISE(ABORT, 'immutable mutation'); END")
            owner = writer_identity()
            with db:
                db.execute("BEGIN IMMEDIATE")
                last = db.execute("SELECT COALESCE(MAX(sequence),0) FROM receipts").fetchone()[0]
                yield db
                if changed[0]:
                    receipts = db.execute("SELECT sequence,run_id FROM receipts WHERE sequence>? ORDER BY sequence",
                                          (last,)).fetchall()
                    if owner["scope"] == "standalone":
                        candidates = {row[1] for row in receipts}
                        # A transaction touching multiple runs has no unique run
                        # owner without an explicit active context. Never choose
                        # arbitrarily from a set of same-process candidates.
                        if len(candidates) == 1:
                            candidate = next(iter(candidates))
                            run = db.execute("SELECT pid,identity FROM runs WHERE run_id=?", (candidate,)).fetchone()
                            if (run and owner["identity"] not in (None, "absent")
                                    and run[0] == owner["pid"] and run[1] == owner["identity"]):
                                owner.update(run_id=candidate, scope="explicit_run")
                    body = dict(owner, mutation_id=str(uuid.uuid4()), status="committed",
                                boundary="sqlite_transaction", hash_scope="ordered_changed_rows",
                                destination_sha256=digest(str(self.path.resolve()).encode()),
                                destination_kind="run_registry", before_sha256=before_hash.hexdigest(),
                                after_sha256=after_hash.hexdigest(), changed_rows=changed[0],
                                receipt_sequences=[row[0] for row in receipts], committed_at=utc_now())
                    db.execute("INSERT INTO state_mutations(mutation_id,body) VALUES(?,?)",
                               (body["mutation_id"], json.dumps(body, separators=(",", ":"))))

    def read_mutations(self, *, after_sequence: int = 0, limit: int = 1000) -> list[dict[str, Any]]:
        """Read-only incremental exact-commit receipts; never opens a missing registry."""
        if type(after_sequence) is not int or after_sequence < 0 or type(limit) is not int or not 1 <= limit <= 10000:
            raise ValueError("invalid mutation cursor")
        if not self.path.exists():
            return []
        with closing(sqlite3.connect(self.path.resolve().as_uri() + "?mode=ro", uri=True,
                                     timeout=self.lock_timeout)) as db:
            if not db.execute("SELECT 1 FROM sqlite_master WHERE name='state_mutations'").fetchone():
                return []
            return [dict(json.loads(body), sequence=sequence) for sequence, body in db.execute(
                "SELECT sequence,body FROM state_mutations WHERE sequence>? ORDER BY sequence LIMIT ?",
                (after_sequence, limit))]

    @staticmethod
    def _append(db: sqlite3.Connection, run_id: str, kind: str, body: Mapping[str, object]) -> None:
        if kind not in _KINDS:
            raise ValueError("invalid receipt kind")
        encoded = json.dumps(dict(body), separators=(",", ":"), allow_nan=False)
        if len(encoded) > 4096:
            raise ValueError("receipt exceeds bounded size")
        db.execute("INSERT INTO receipts(run_id,kind,at,body) VALUES(?,?,?,?)",
                   (run_id, kind, utc_now(), encoded))

    def start(self, name: str, *, parent_run_id: str | None = None) -> str:
        parent_run_id = _uuid(parent_run_id)
        run_id = str(uuid.uuid4())
        now = utc_now()
        pid = os.getpid()
        identity = process_identity(pid)
        with self._db() as db:

            if parent_run_id and not db.execute("SELECT 1 FROM runs WHERE run_id=?", (parent_run_id,)).fetchone():
                raise ValueError("parent run does not exist")
            db.execute("INSERT INTO runs VALUES(?,?,?,?,?,?,?,?,?)", (run_id, parent_run_id,
                       name if name in _NAMES else "unknown", pid, identity, now, now, None, "running"))
            self._append(db, run_id, "start", {"coverage_status": "unknown", "freshness_status": "unknown"})
        self.maintain()
        return run_id

    def heartbeat(self, run_id: str) -> None:
        with self._db() as db:
            changed = db.execute("UPDATE runs SET heartbeat_at=? WHERE run_id=? AND status='running'",
                                 (utc_now(), _uuid(run_id))).rowcount
            if changed:
                self._append(db, run_id, "heartbeat", {})
        self.maintain()

    def finish(self, run_id: str, status: str, *, error_type: str | None = None) -> None:
        if status not in _TERMINAL:
            raise ValueError("invalid terminal state")
        # Error messages, tracebacks, arbitrary exception names and payloads are not stored.
        error = error_type if error_type in {"TimeoutError", "KeyboardInterrupt", "SystemExit",
                                            "GeneratorExit", "ValueError", "RuntimeError", "OSError"} else "unknown"
        with self._db() as db:
            changed = db.execute("UPDATE runs SET status=?,ended_at=? WHERE run_id=? AND status='running'",
                                 (status, utc_now(), _uuid(run_id))).rowcount
            if changed:
                self._append(db, run_id, "end", {"status": status, "error_type": error if error_type else None,
                                                "coverage_status": "unknown", "freshness_status": "unknown"})

    def task(self, run_id: str, task: str) -> None:
        self._active_receipt(run_id, "task", {"task": task if task in _TASKS else "unknown"})

    def expect_inputs(self, run_id: str, inputs: list[tuple[str, str]]) -> None:
        """An explicit bounded required universe. Absence/empty is UNKNOWN, not complete."""
        if not 1 <= len(inputs) <= 10000 or len(set(inputs)) != len(inputs):
            raise ValueError("required inputs must be unique and bounded")
        for role, listing in inputs:
            ConsumedInput(role, listing).receipt()
        with self._db() as db:

            row = db.execute("SELECT status FROM runs WHERE run_id=?", (_uuid(run_id),)).fetchone()
            if row is None or row[0] != "running":
                raise ValueError("manifest requires an active run")
            if db.execute("SELECT 1 FROM receipts WHERE run_id=? AND kind='manifest'", (run_id,)).fetchone():
                raise ValueError("required universe is immutable")
            for offset in range(0, len(inputs), 32):
                self._append(db, run_id, "manifest", {"required": inputs[offset:offset + 32]})

    def consumed(self, run_id: str, evidence: ConsumedInput) -> None:
        self._active_receipt(run_id, "input", evidence.receipt())

    def operation(self, run_id: str, name: str, status: str, fields: Mapping[str, object]) -> None:
        safe: dict[str, object] = {"operation": name if name in _OPERATION_NAMES else "unknown",
                                   "status": status if status in {"ok", "partial", "error", "interrupted"} else "unknown"}
        for key in ("span_id", "parent_span_id"):
            value = fields.get(key)
            if isinstance(value, str) and re.fullmatch(r"[a-f0-9]{32}", value):
                safe[key] = value
        for key in ("rows", "bytes", "inputs_requested", "inputs_available", "feeds_requested", "feeds_failed", "feeds_scheduled"):
            value = fields.get(key)
            if type(value) is int:
                safe[key] = max(0, min(value, 10**12))
        self._active_receipt(run_id, "operation", safe)

    def _active_receipt(self, run_id: str, kind: str, body: Mapping[str, object]) -> None:
        with self._db() as db:

            row = db.execute("SELECT status FROM runs WHERE run_id=?", (_uuid(run_id),)).fetchone()
            if row is None or row[0] != "running":
                raise ValueError("receipt requires an active known run")
            self._append(db, run_id, kind, body)

    def read(self, run_id: str) -> dict[str, Any] | None:
        with self._db() as db:

            row = db.execute("SELECT * FROM runs WHERE run_id=?", (_uuid(run_id),)).fetchone()
            if row is None:
                return None
            result = dict(row)
            actual_owner = process_identity(result["pid"]) if result["status"] == "running" else None
            result["owner_status"] = ("unknown" if actual_owner is None or result["identity"] is None
                                      else "alive" if actual_owner == result["identity"] else "gone")
            result["task"] = "unknown"
            result["receipts"] = [{"sequence": r[0], "kind": r[1], "at": r[2], "body": json.loads(r[3])}
                                  for r in db.execute("SELECT sequence,kind,at,body FROM receipts WHERE run_id=? "
                                                      "ORDER BY sequence", (run_id,))]
            # No manifest of required inputs => no claim of strategy-wide completeness.
            result.update(coverage_status="unknown", freshness_status="unknown",
                          accounting_status="unknown", promotion_status="unknown")
            required: list[list[str]] = []
            consumed: dict[tuple[str, str], dict[str, Any]] = {}
            for event in result["receipts"]:
                if event["kind"] == "task":
                    result["task"] = event["body"]["task"]
                elif event["kind"] == "manifest":
                    required.extend(event["body"]["required"])
                elif event["kind"] == "input":
                    body = event["body"]
                    consumed[(body["role"], body["listing"])] = body
            if required:
                evidence = [consumed.get((role, listing)) for role, listing in required]
                available = sum(bool(e and e["rows"]) for e in evidence)
                result.update(inputs_requested=len(required), inputs_available=available,
                              coverage_status="complete" if available == len(required) else "partial")
                statuses = {e["freshness_status"] if e else "unknown" for e in evidence}
                result["freshness_status"] = "stale" if "stale" in statuses else "unknown" if "unknown" in statuses else "complete"
            return result

    def maintain(self, *, now: str | None = None,
                 probe: Callable[[int], str | None] = process_identity) -> dict[str, object]:
        """One finite, transactional due pass shared by all cooperating owners."""
        instant = _instant(now or utc_now())
        with self._db() as db:

            state = db.execute("SELECT last_at,recovery_cursor FROM registry_maintenance WHERE singleton=1").fetchone()
            if state:
                elapsed = (datetime.fromisoformat(instant) - datetime.fromisoformat(state[0])).total_seconds()
                if 0 <= elapsed < self.maintenance_seconds:
                    return {"due": False, "recovered": [], "probed": 0}
            cursor = state[1] if state else ""
            rows = db.execute("SELECT run_id,pid,identity FROM runs WHERE status='running' AND run_id > ? "
                              "ORDER BY run_id LIMIT ?", (cursor, self.maintenance_batch)).fetchall()
            if not rows and cursor:
                rows = db.execute("SELECT run_id,pid,identity FROM runs WHERE status='running' "
                                  "ORDER BY run_id LIMIT ?", (self.maintenance_batch,)).fetchall()
            recovered = self._recover(db, rows, probe)
            cursor = rows[-1][0] if len(rows) == self.maintenance_batch else ""
            pruned = 0
            if self.retention.days is not None:
                cutoff = (datetime.fromisoformat(instant) - timedelta(days=self.retention.days)).isoformat()
                pruned = prune_terminal(db, cutoff=cutoff, keep_latest=self.retention.keep_latest,
                                        batch=self.maintenance_batch)
                # Finite page reclamation, not an unbounded blocking full VACUUM.
                db.execute("PRAGMA incremental_vacuum(32)").fetchall()
            page_size = db.execute("PRAGMA page_size").fetchone()[0]
            allocated = db.execute("PRAGMA page_count").fetchone()[0] * page_size
            used = allocated - db.execute("PRAGMA freelist_count").fetchone()[0] * page_size
            db.execute("INSERT OR REPLACE INTO registry_maintenance VALUES(1,?,?)", (instant, cursor))
            result: dict[str, object] = {"due": True, "recovered": recovered, "probed": len(rows), "pruned": pruned,
                                         "database_bytes": allocated, "used_bytes": used,
                                         "over_soft_cap": allocated > self.retention.max_database_bytes}
            summary = {"at": instant, "probed": len(rows), "recovered": len(recovered), "pruned": pruned,
                       "database_bytes": allocated, "used_bytes": used,
                       "over_soft_cap": result["over_soft_cap"], "retention_days": self.retention.days,
                       "keep_latest": self.retention.keep_latest,
                       "max_database_bytes": self.retention.max_database_bytes}
            db.execute("INSERT OR REPLACE INTO registry_maintenance_stats VALUES(1,?)", (json.dumps(summary),))
        # Durable maintenance cadence, not every mutation. The connection and
        # attribution transaction are closed before invoking the read adapter.
        if os.environ.get("BORG_OPERATIONAL_ALERTS_ENABLED") == "1":
            try:
                from simulator.operational_alerts import maintain_from_environment
                maintain_from_environment(self.path, now=instant)
            except Exception:
                # Optional operational failures cannot alter lifecycle results or
                # recursively write a registry receipt; keep payloads private.
                pass
        return result

    def maintenance_status(self) -> dict[str, Any] | None:
        """Latest mutable operational summary; not immutable run/financial evidence."""
        with self._db() as db:
            row = db.execute("SELECT body FROM registry_maintenance_stats WHERE singleton=1").fetchone()
            if row is None:
                return None
            result: dict[str, Any] = json.loads(row[0])
            return result

    def _recover(self, db: sqlite3.Connection, rows: list[sqlite3.Row],
                 probe: Callable[[int], str | None]) -> list[str]:
        recovered: list[str] = []
        for row in rows:
            actual = probe(row[1])
            if actual is None or row[2] is None or actual == row[2]:
                continue
            # Proven dead/reused owner only. Age never proves crash or timeout.
            db.execute("UPDATE runs SET status='recovered_orphan',ended_at=? WHERE run_id=? AND status='running'",
                       (utc_now(), row[0]))
            self._append(db, row[0], "end", {"status": "recovered_orphan", "cause": "unknown"})
            recovered.append(row[0])
        return recovered

    def recover_orphans(self, *, probe: Callable[[int], str | None] = process_identity) -> list[str]:
        """Explicit full inspection; periodic owners use bounded maintain instead."""
        with self._db() as db:

            rows = db.execute("SELECT run_id,pid,identity FROM runs WHERE status='running'").fetchall()
            return self._recover(db, rows, probe)

    def prune(self, *, before: str, keep_latest: int = 1000, batch: int = 1024) -> int:
        """Explicit finite whole terminal-run retention; protect retained families."""
        cutoff = _instant(before)
        RetentionPolicy(keep_latest=keep_latest)
        if type(batch) is not int or not 1 <= batch <= 1024:
            raise ValueError("prune batch must be in [1, 1024]")
        with self._db() as db:

            return prune_terminal(db, cutoff=cutoff, keep_latest=keep_latest, batch=batch)


@dataclass
class RunContext:
    registry: RunRegistry
    run_id: str
    status: str = "ok"
    persistence_error: bool = False

    def consumed(self, evidence: ConsumedInput) -> None:
        self.registry.consumed(self.run_id, evidence)

    def child_environment(self) -> dict[str, str]:
        """For a managed child ONLY. The worker creates/ends its own child run."""
        return {"BORG_PARENT_RUN_ID": self.run_id, "BORG_RUN_REGISTRY_PATH": str(self.registry.path)}


def current_run() -> RunContext | None:
    return _current.get()


def default_registry() -> RunRegistry:
    from simulator.pathing import state_dir
    path = os.environ.get("BORG_RUN_REGISTRY_PATH")
    days = os.environ.get("BORG_RUN_RETENTION_DAYS")
    return RunRegistry(
        Path(path) if path else state_dir() / "run_registry.sqlite",
        maintenance_seconds=float(os.environ.get("BORG_RUN_MAINTENANCE_SECONDS", "300")),
        maintenance_batch=int(os.environ.get("BORG_RUN_MAINTENANCE_BATCH", "128")),
        retention=RetentionPolicy(days=int(days) if days is not None else None,
                                  keep_latest=int(os.environ.get("BORG_RUN_KEEP_LATEST", "1000")),
                                  max_database_bytes=int(os.environ.get("BORG_RUN_MAX_DATABASE_BYTES", "67108864"))),
    )


@contextmanager
def run_context(name: str, *, registry: RunRegistry | None = None,
                heartbeat_seconds: float = 30.0, parent_run_id: str | None = None) -> Iterator[RunContext]:
    """Own a correlated lifetime. Nested callers borrow without closing the owner."""
    existing = current_run()
    if existing is not None:
        yield existing
        return
    if not 0.01 <= heartbeat_seconds <= 3600:
        raise ValueError("invalid heartbeat interval")
    registry = registry or default_registry()
    parent = parent_run_id if parent_run_id is not None else os.environ.get("BORG_PARENT_RUN_ID")
    context = RunContext(registry, registry.start(name, parent_run_id=parent))
    token = _current.set(context)
    stop = Event()

    def beat() -> None:
        while not stop.wait(heartbeat_seconds):
            try:
                registry.heartbeat(context.run_id)
            except (OSError, sqlite3.Error):
                context.persistence_error = True
                return

    thread = Thread(target=beat, name="borg-run-heartbeat", daemon=True)
    error_type = None
    try:
        thread.start()
        yield context
    except BaseException as exc:
        error_type = type(exc).__name__
        if isinstance(exc, TimeoutError):
            context.status = "timeout"
        elif isinstance(exc, (KeyboardInterrupt, GeneratorExit)):
            context.status = "interrupted"
        elif isinstance(exc, SystemExit) and exc.code in (None, 0):
            pass
        else:
            context.status = "failed"
        raise
    finally:
        stop.set()
        if thread.ident is not None:
            thread.join(timeout=registry.lock_timeout + 1)
        _current.reset(token)
        if context.persistence_error and context.status == "ok":
            context.status = "partial"
        registry.finish(context.run_id, context.status, error_type=error_type)
