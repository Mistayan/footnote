"""Dependency-free, bounded, payload-free operation telemetry.

One completion per boundary by default; BORG_OBSERVABILITY_DETAIL=1 adds starts.
Operation success is NOT input freshness or financial/accounting certification.
"""
from __future__ import annotations

import logging
import os
import sqlite3
import time
import uuid
from contextlib import contextmanager, nullcontext
from contextvars import ContextVar
from dataclasses import dataclass, field
from functools import wraps
from threading import Lock
from typing import Iterator
from datetime import datetime, timezone

logger = logging.getLogger("simulator.observability")
_OPERATIONS = frozenset({
    "cli", "feed_cycle", "feed_context", "dashboard_feed", "news_feed", "public_snapshot",
    "cache_read", "parquet_read", "duckdb_read", "data_fetch", "quote", "quote_batch",
    "quote_provider", "quote_cache_load", "quote_cache_write", "serialization",
    "db_snapshot", "script", "cache_update", "sentinel", "monitor", "unknown",
    "provider_transport", "provider_parse", "provider_normalize", "provider_sdk", "fx", "fx_cache",
})
MAX_OPERATIONS = len(_OPERATIONS)
_NUMERIC_FIELDS = frozenset({"rows", "bytes", "http_status", "cache_hits", "cache_misses", "feeds_requested", "feeds_failed", "feeds_scheduled"})
_LABELS = {
    "provider": frozenset({"ibkr", "yfinance", "ecb", "cache", "unknown"}),
    "feed": frozenset({"price_history", "trades", "dividends", "intents", "kpis", "news", "journal", "public_site"}),
}
_current: ContextVar[Operation | None] = ContextVar("borg_operation", default=None)
_lock = Lock()
_metrics: dict[str, dict[str, float | int]] = {}


def _run_id() -> str:
    try:
        return str(uuid.UUID(os.environ.get("BORG_RUN_ID", "")))
    except ValueError:
        return str(uuid.uuid4())


def _fields(fields: dict) -> dict:
    safe: dict[str, int | str] = {}
    for key, value in fields.items():
        if key in _NUMERIC_FIELDS and isinstance(value, int) and not isinstance(value, bool):
            safe[key] = max(0, min(value, 10**12))
        elif key in _LABELS and isinstance(value, str) and value in _LABELS[key]:
            safe[key] = value
    return safe


@dataclass
class Operation:
    name: str
    run_id: str
    span_id: str
    parent_span_id: str | None
    status: str = "ok"
    values: dict = field(default_factory=dict)

    def coverage(self, requested: int, available: int) -> None:
        if not 0 <= available <= requested:
            raise ValueError("invalid coverage counts")
        self.values.update(inputs_requested=requested, inputs_available=available,
                           coverage_status="complete" if requested == available else "partial")
        if available < requested:
            self.status = "partial"

    def count(self, **fields: int) -> None:
        self.values.update(_fields(fields))


def degraded(exc: BaseException | None = None) -> None:
    """Mark a swallowed boundary failure without retaining its message or traceback."""
    operation = _current.get()
    if operation is not None:
        operation.status = "partial"
        if exc is not None:
            operation.values["error_type"] = type(exc).__name__[:64]


def interrupted() -> None:
    """Preserve interruption when a supported outer loop intentionally catches it."""
    from simulator.run_registry import current_run

    operation = _current.get()
    if operation is not None:
        operation.status = "interrupted"
    run = current_run()
    if run is not None:
        run.status = "interrupted"


def metrics_snapshot() -> dict[str, dict[str, float | int]]:
    """Detached fixed-cardinality cumulative counters, no retained event samples."""
    with _lock:
        return {name: dict(row) for name, row in _metrics.items()}


@contextmanager
def span(name: str, **fields: object) -> Iterator[Operation]:
    """Canonical CLI/lifecycle roots own a durable lifetime; other spans borrow it."""
    from simulator.run_registry import current_run, run_context

    owns = _current.get() is None and current_run() is None and name in {
        "cli", "script", "cache_update", "monitor", "sentinel",
    }
    with run_context(name) if owns else nullcontext():
        with _span(name, **fields) as operation:
            yield operation


@contextmanager
def _span(name: str, **fields: object) -> Iterator[Operation]:
    """Correlate completion, partial input coverage and interruption; never log payloads."""
    from simulator.run_registry import current_run

    durable = current_run()
    parent = _current.get()
    operation = Operation(name if name in _OPERATIONS else "unknown",
                          parent.run_id if parent else durable.run_id if durable else _run_id(), uuid.uuid4().hex,
                          parent.span_id if parent else None, values=_fields(fields))
    started = time.perf_counter()
    started_at = datetime.now(timezone.utc).isoformat()
    token = _current.set(operation)
    base = {"operation": operation.name, "run_id": operation.run_id,
            "span_id": operation.span_id, "parent_span_id": operation.parent_span_id,
            "started_at": started_at}
    if os.environ.get("BORG_OBSERVABILITY_DETAIL") == "1":
        logger.info("operation.start", extra=base)
    error_type = None
    try:
        yield operation
    except BaseException as exc:
        if isinstance(exc, (KeyboardInterrupt, GeneratorExit)):
            operation.status = "interrupted"
        elif isinstance(exc, SystemExit) and exc.code in (None, 0):
            pass
        else:
            operation.status = "error"
        if operation.status != "ok":
            error_type = type(exc).__name__[:64]
        raise
    finally:
        elapsed_ms = round((time.perf_counter() - started) * 1000, 3)
        _current.reset(token)
        if parent and operation.status != "ok" and parent.status == "ok":
            parent.status = "partial"
        with _lock:
            counters = _metrics.setdefault(operation.name, {"count": 0, "duration_ms": 0.0,
                                                             "partial": 0, "error": 0, "interrupted": 0})
            counters["count"] += 1
            counters["duration_ms"] += elapsed_ms
            if operation.status != "ok":
                counters[operation.status] += 1
        payload = {**base, "ended_at": datetime.now(timezone.utc).isoformat(),
                   "duration_ms": elapsed_ms, "status": operation.status,
                   "coverage_status": "unknown", "freshness_status": "unknown", **operation.values}
        if error_type:
            payload["error_type"] = error_type
        if durable is not None:
            try:
                durable.registry.operation(durable.run_id, operation.name, operation.status,
                                           {**operation.values, "span_id": operation.span_id,
                                            "parent_span_id": operation.parent_span_id})
            except (sqlite3.Error, OSError):
                durable.persistence_error = True
                if operation.status == "ok":
                    operation.status = "partial"
                    with _lock:
                        _metrics[operation.name]["partial"] += 1
                payload["status"] = operation.status
                logger.warning("registry.persistence_failure", extra={"run_id": durable.run_id,
                                                                      "status": "unknown"})
            if operation.status != "ok" and durable.status == "ok":
                durable.status = "partial"
        logger.log(logging.WARNING if operation.status != "ok" else logging.INFO,
                   "operation.end", extra=payload)


def observed(name: str, *, status_map: bool = False, availability: bool = False, provider: str | None = None):
    """Instrument a synchronous boundary without changing its result or exceptions."""
    def decorate(function):
        @wraps(function)
        def wrapped(*args, **kwargs):
            with span(name, provider=provider) as operation:
                result = function(*args, **kwargs)
                if availability:
                    operation.coverage(1, int(result is not None))
                if status_map and isinstance(result, dict):
                    failed = sum(value == "failed" for value in result.values())
                    pending = sum(value == "scheduled" for value in result.values())
                    completed = sum(value == "ok" for value in result.values())
                    operation.count(feeds_requested=len(result), feeds_failed=failed, feeds_scheduled=pending)
                    operation.coverage(len(result), completed)
                return result
        return wrapped
    return decorate
