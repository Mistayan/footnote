"""Bounded cooperating-process cache locks and owned atomic publication.

The stable sidecar is never removed (unlinking creates split lock ownership).
The OS releases locks after a crash. All DuckDB users of a cache must cooperate;
this is not a sandbox for arbitrary native clients or network filesystems.
"""

from __future__ import annotations

import math
import os
import tempfile
import threading
import time
import weakref
from contextlib import contextmanager
from pathlib import Path
from typing import Iterator


class CacheLockTimeout(TimeoutError):
    """No cache observation/publication occurred before the lock deadline."""


class _Owner:
    def __init__(self) -> None:
        self.mutex = threading.RLock()
        self.depth = 0


_registry_guard = threading.Lock()
_registry: weakref.WeakValueDictionary[tuple[int, str], _Owner] = weakref.WeakValueDictionary()


@contextmanager
def cache_lock(path: str | Path, *, timeout: float = 5.0) -> Iterator[None]:
    """Serialize readers/writers, reentrant only for the owning process/thread."""
    if not math.isfinite(timeout) or timeout < 0:
        raise ValueError("cache lock timeout must be finite and nonnegative")
    lock_path = Path(path).resolve().with_name(Path(path).name + ".lock")
    key = (os.getpid(), os.path.normcase(str(lock_path)))
    with _registry_guard:
        owner = _registry.get(key)
        if owner is None:
            owner = _Owner()
            _registry[key] = owner
    deadline = time.monotonic() + timeout
    if not owner.mutex.acquire(timeout=timeout):
        raise CacheLockTimeout("cache lock thread deadline exceeded")
    try:
        if owner.depth:
            owner.depth += 1
            try:
                yield
            finally:
                owner.depth -= 1
            return
        lock_path.parent.mkdir(parents=True, exist_ok=True)
        with lock_path.open("a+b") as handle:
            handle.seek(0, os.SEEK_END)
            if handle.tell() == 0:
                handle.write(b"\0")
                handle.flush()
            while True:
                try:
                    handle.seek(0)
                    if os.name == "nt":
                        import msvcrt

                        msvcrt.locking(handle.fileno(), msvcrt.LK_NBLCK, 1)
                    else:
                        import fcntl

                        fcntl.flock(handle.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
                    break
                except OSError as exc:
                    import errno

                    if exc.errno not in (errno.EACCES, errno.EAGAIN, errno.EDEADLK):
                        raise
                    remaining = deadline - time.monotonic()
                    if remaining <= 0:
                        raise CacheLockTimeout("cache lock process deadline exceeded") from exc
                    time.sleep(min(0.01, remaining))
            owner.depth = 1
            try:
                yield
            finally:
                owner.depth = 0
                handle.seek(0)
                if os.name == "nt":
                    msvcrt.locking(handle.fileno(), msvcrt.LK_UNLCK, 1)
                else:
                    fcntl.flock(handle.fileno(), fcntl.LOCK_UN)
    finally:
        owner.mutex.release()


@contextmanager
def atomic_destination(path: str | Path) -> Iterator[Path]:
    """Yield an exclusive same-directory staging file; replace only on success.

    Clean only the staging file owned by this operation. Never touch .tmp files
    belonging to another process. Replacement is atomic, not multi-file atomic.
    """
    target = Path(path)
    target.parent.mkdir(parents=True, exist_ok=True)
    fd, name = tempfile.mkstemp(prefix=f".{target.name}.", suffix=".tmp", dir=target.parent)
    os.close(fd)
    temporary = Path(name)
    try:
        yield temporary
        os.replace(temporary, target)
    finally:
        temporary.unlink(missing_ok=True)


def atomic_write_text(path: str | Path, text: str) -> None:
    """Flush an owned staging file before publishing an indivisible snapshot."""
    with atomic_destination(path) as temporary:
        with temporary.open("w", encoding="utf-8") as handle:
            handle.write(text)
            handle.flush()
            os.fsync(handle.fileno())
