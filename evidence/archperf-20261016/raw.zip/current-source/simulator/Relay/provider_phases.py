"""Provider diagnostics: actual bounded PUBLIC reads and opaque SDK envelopes.

No broker imports, credential loading, cookies, auth endpoints or global patches.
The public session is deliberately unsuitable for yfinance's cookie/crumb flow.
"""
from __future__ import annotations

from threading import Lock
from typing import Any, Callable
from urllib.parse import urlsplit

from curl_cffi import requests

from simulator.observability import span

_MAX_BODY_BYTES = 2_000_000
_TARGETS = {
    ("query1.finance.yahoo.com", "/v8/finance/chart/SPY"): "yfinance",
    ("data-api.ecb.europa.eu", "/service/data/EXR/D.USD.EUR.SP00.A"): "ecb",
}


class ProviderResponse(requests.Response):
    """Observe the actual JSON parser, preserving curl_cffi's result/errors."""

    provider: str = "unknown"

    def json(self, **kwargs: Any) -> Any:
        with span("provider_parse", provider=self.provider):
            parser: Callable[..., Any] = super().json
            return parser(**kwargs)


class PublicProviderSession(requests.Session):
    """Allowlist-only, zero-retry public GET transport with an attempt budget."""

    def __init__(self, *, request_budget: int = 6, timeout_seconds: float = 10) -> None:
        if not 1 <= request_budget <= 6 or not 0 < timeout_seconds <= 15:
            raise ValueError("invalid public request budget/timeout")
        super().__init__(impersonate="chrome", response_class=ProviderResponse,
                         timeout=timeout_seconds, retry=0, trust_env=False,
                         allow_redirects=False, discard_cookies=True)
        self.request_budget = request_budget
        self.timeout_seconds = timeout_seconds
        self.requests_used = 0
        self._budget_lock = Lock()

    def request(self, method: Any, url: str, *args: Any, **kwargs: Any) -> Any:
        parts = urlsplit(url)
        provider = _TARGETS.get((parts.hostname, parts.path))
        allowed = {"params"}
        if (args or method != "GET" or not provider or parts.scheme != "https" or parts.port is not None
                or parts.username or parts.password or parts.query or parts.fragment
                or set(kwargs) - allowed):
            raise ValueError("refused non-public request")
        params = kwargs.get("params", {})
        keys = {"period1", "period2", "interval", "events"} if provider == "yfinance" else {
            "format", "startPeriod", "endPeriod"}
        if not isinstance(params, dict) or set(params) - keys:
            raise ValueError("refused non-public parameters")
        with self._budget_lock:
            if self.requests_used >= self.request_budget:
                raise ValueError("public request budget exhausted")
            self.requests_used += 1
        body = bytearray()

        def receive(chunk: bytes) -> None:
            if len(body) + len(chunk) > _MAX_BODY_BYTES:
                raise ValueError("public response byte budget exhausted")
            body.extend(chunk)

        with span("provider_transport", provider=provider) as operation:
            try:
                response = super().request(method, url, **kwargs,
                                           timeout=self.timeout_seconds, allow_redirects=False,
                                           content_callback=receive)
                if body:
                    response.content = bytes(body)
                if len(response.content) > _MAX_BODY_BYTES:
                    raise ValueError("public response byte budget exhausted")
                response.provider = provider
                operation.count(bytes=len(response.content), http_status=response.status_code)
                if response.status_code != 200:
                    operation.status = "error"
                return response
            finally:
                self.cookies.clear()
                if body:
                    operation.count(bytes=len(body))


def download(function: Callable[..., Any], *args: Any, **kwargs: Any) -> Any:
    """Observe an actual SDK download without changing sessions, retries or output.

    This includes SDK cache/network/parse work; never label it network-only.
    """
    with span("provider_sdk", provider="yfinance") as operation:
        result = function(*args, **kwargs)
        available = result is not None and not result.empty
        operation.coverage(1, int(available))
        if available:
            operation.count(rows=len(result))
        return result
