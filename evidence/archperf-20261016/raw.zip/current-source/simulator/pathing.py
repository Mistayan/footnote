from __future__ import annotations

from functools import lru_cache
from pathlib import Path


@lru_cache(maxsize=1)
def repo_root() -> Path:
    return Path(__file__).resolve().parents[1]


@lru_cache(maxsize=1)
def simulator_root() -> Path:
    return repo_root() / "simulator"


@lru_cache(maxsize=1)
def engine_models_dir() -> Path:
    return simulator_root() / "Algo" / "models"


@lru_cache(maxsize=1)
def data_dir() -> Path:
    import os

    env_path = os.environ.get("BORG_DATA_DIR")
    if env_path:
        return Path(env_path).resolve()
    return repo_root() / "data"


def quote_cache_dir() -> Path:
    """Writable quote cache location, independent of read-only data fixtures."""
    import os

    override = os.environ.get("BORG_QUOTE_CACHE_DIR")
    return Path(override).resolve() if override else data_dir()


@lru_cache(maxsize=1)
def state_dir() -> Path:
    import os

    env_path = os.environ.get("BORG_STATE_DIR")
    if env_path:
        return Path(env_path).resolve()
    path = repo_root() / "state"
    path.mkdir(exist_ok=True)
    return path


@lru_cache(maxsize=1)
def logs_dir() -> Path:
    import os

    env_path = os.environ.get("BORG_LOGS_DIR")
    if env_path:
        return Path(env_path).resolve()
    path = repo_root() / "logs"
    path.mkdir(exist_ok=True)
    return path


@lru_cache(maxsize=1)
def profile_matrix_reports_dir() -> Path:
    return repo_root() / "reports" / "profile_matrix_2019_2026"


def resolve_repo_path(value: str | Path) -> Path:
    path = Path(value)
    return path if path.is_absolute() else repo_root() / path


def to_repo_relative(value: str | Path) -> str:
    path = resolve_repo_path(value)
    try:
        return path.resolve().relative_to(repo_root().resolve()).as_posix()
    except ValueError:
        return str(path)
