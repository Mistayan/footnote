"""Read-only incremental-refresh diagnostics. Never authorizes a cache skip.

Schedules must be supplied independently of cached rows, anchored to the request
start (not cache minima). This is NOT a listing/receipt ingestion adapter.
"""
from __future__ import annotations

import math
from datetime import date, datetime
from typing import Any


def _instant(value: str) -> datetime:
    parsed = datetime.fromisoformat(value)
    if parsed.tzinfo is None or parsed.utcoffset() is None:
        raise ValueError('timezone-aware instant required')
    return parsed


def plan_incremental_refresh(rows: list[dict[str, Any]], inventory: dict[str, Any], *,
                             start: str, end: str, as_of: str) -> dict[str, Any]:
    """Count exact completed-session candidates, withholding all freshness claims.

    Inventory entries carry venue, currency, adjustment, calendar_source and a
    session-date -> timezone-aware closing-instant map. A complete map is the
    caller's responsibility and still cannot establish receipt/FX provenance.
    Malformed inputs return unknown, not an optimistic empty-success result.
    """
    result: dict[str, Any] = {
        'schema': 'incremental-refresh-plan-v1', 'can_skip': False,
        'actual_requests_avoided': 0, 'coverage_status': 'unknown',
        'candidate_covered_symbols': [], 'missing_sessions': {},
        'incomplete_sessions': {},
        'blockers': ['listing identity, adjustment lineage, exact FX correspondences and '
                     'point-in-time retrieval receipts are not executable in DataEngine'],
    }
    try:
        lo, hi, cutoff = date.fromisoformat(start), date.fromisoformat(end), _instant(as_of)
        if lo > hi or not isinstance(rows, list) or not isinstance(inventory, dict) or not inventory:
            raise ValueError('invalid request or inventory')
        indexed: dict[tuple[str, str], dict[str, Any]] = {}
        for row in rows:
            if not isinstance(row, dict):
                raise ValueError('malformed row')
            symbol, day, close = row['Ticker'], row['trade_date'], row['Close']
            if not isinstance(symbol, str) or not isinstance(day, str):
                raise ValueError('invalid identity')
            date.fromisoformat(day)
            if isinstance(close, bool) or not isinstance(close, (int, float)) or not math.isfinite(close) or close <= 0:
                raise ValueError('invalid price')
            if (symbol, day) in indexed:
                raise ValueError('duplicate session')
            indexed[symbol, day] = row
        for symbol, spec in sorted(inventory.items()):
            if not isinstance(symbol, str) or not symbol or not isinstance(spec, dict):
                raise ValueError('unknown listing')
            for field in ('venue', 'currency', 'adjustment', 'calendar_source'):
                if not isinstance(spec.get(field), str) or not spec[field].strip():
                    raise ValueError('unknown listing or calendar')
            sessions = spec['sessions']
            if not isinstance(sessions, dict) or not sessions:
                raise ValueError('calendar unavailable')
            expected, incomplete = [], []
            for day, closing in sorted(sessions.items()):
                session_day, close_at = date.fromisoformat(day), _instant(closing)
                if lo <= session_day <= hi:
                    if close_at <= cutoff:
                        expected.append(day)
                    else:
                        incomplete.append(day)
            missing = [day for day in expected if (symbol, day) not in indexed]
            result['missing_sessions'][symbol] = missing
            result['incomplete_sessions'][symbol] = incomplete
            if expected and not missing:
                result['candidate_covered_symbols'].append(symbol)
        result['coverage_status'] = 'incomplete' if any(result['missing_sessions'].values()) else 'unproved'
    except (ValueError, TypeError, KeyError, OverflowError):
        result.update(coverage_status='unknown', candidate_covered_symbols=[],
                      missing_sessions={}, incomplete_sessions={})
        result['blockers'].append('malformed or unavailable row/listing/calendar input')
    return result
