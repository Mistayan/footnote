from typing import Literal

import numpy as np
import polars as pl

try:
    from arch import arch_model

    HAS_ARCH = True
except ImportError:
    HAS_ARCH = False


class VolatilityEngine:
    """
    Borg Volatility Ensemble Voting System.
    Combines GARCH(1,1), GJR-GARCH, and EGARCH to identify volatility regimes.
    """

    def __init__(
        self,
        omega: float = 0.000002,
        alpha: float = 0.05,
        beta: float = 0.90,
        cache_file: str = None,
    ):
        # Legacy parameters for proxy fallback
        self.omega = omega
        self.alpha = alpha
        self.beta = beta
        from simulator.pathing import state_dir

        self.cache_file = cache_file or str(state_dir() / "garch_params_cache.parquet")
        self.cache: dict[str, dict[str, float]] = {}
        self._load_cache()

    def _load_cache(self):
        """Loads existing GARCH forecasts from Parquet."""
        import os

        if os.path.exists(self.cache_file):
            try:
                df = pl.read_parquet(self.cache_file)
                # Convert to dict for O(1) lookup during loop
                # Expected schema: [date, garch, gjr, egarch, ensemble_avg]
                for row in df.to_dicts():
                    date = row.pop("date")
                    self.cache[date] = row
                if not os.getenv("AI_MODE", "false").lower() == "true":
                    print(f" [CACHE] Loaded {len(self.cache)} GARCH forecasts from {self.cache_file}")
            except Exception as e:
                print(f" [CACHE] Warning: Could not load cache: {e}")

    def save_cache(self):
        """Persists memory cache to Parquet."""
        if not self.cache:
            return
        try:
            data = []
            for date, vals in self.cache.items():
                row = {"date": date}
                row.update(vals)
                data.append(row)
            df = pl.DataFrame(data)
            df.write_parquet(self.cache_file)
            print(f" [CACHE] Saved {len(self.cache)} GARCH forecasts to {self.cache_file}")
        except Exception as e:
            print(f" [CACHE] Error saving cache: {e}")

    def _get_proxy_vol(self, returns: np.ndarray, window: int = 40) -> float:
        """Fallback GARCH(1,1) approximation if arch-py fails."""
        from simulator.TradingPlatform.UNIMATRIX.numba_utils import garch_proxy_jit

        return garch_proxy_jit(returns, window, self.omega, self.alpha, self.beta)

    def forecast_ensemble(self, returns: np.ndarray, date_key: str | None = None) -> dict[str, float]:
        """
        Executes a 3-way model ensemble to triangulate volatility.
        Returns: { 'garch': vol, 'gjr': vol, 'egarch': vol, 'ensemble_avg': vol }
        """
        if date_key and date_key in self.cache:
            return self.cache[date_key]

        if len(returns) < 100:  # Need enough data for ARCH convergence
            v = self._get_proxy_vol(returns)
            return {"garch": v, "gjr": v, "egarch": v, "ensemble_avg": v}

        results = {}
        # Convert to percentage returns for stability
        data = returns * 100.0

        # --- v11.1: Ticker-specific Tuning ---
        is_fx = "EURUSD" in str(getattr(data, "name", "")).upper() or len(data) < 500  # Heuristic or passed context

        # GJR-ARCH tuning:
        # For Equities: o=1 (asymmetry/leverage effect is strong)
        # For FX: Symmetric GARCH with student-t distribution is standard,
        # but we use GJR with o=1 and dist='t' to capture 'volatility of volatility' clusters
        dist_type: Literal["t", "normal"] = "t" if is_fx else "normal"

        models = {
            "garch": arch_model(data, vol="GARCH", p=1, q=1, dist=dist_type, rescale=False),
            "gjr": arch_model(data, vol="GARCH", p=1, o=1, q=1, dist=dist_type, rescale=False),
            "egarch": arch_model(data, vol="EGARCH", p=1, q=1, dist="normal", rescale=False),
        }

        vols = []
        for name, model in models.items():
            try:
                fit = model.fit(disp="off", show_warning=False)
                # Forecast 1-day ahead variance
                forecast = fit.forecast(horizon=1)
                variance_rescaled = forecast.variance.values[-1, 0]
                # Convert back to decimal volatility
                vol = np.sqrt(max(0, variance_rescaled)) / 100.0 * np.sqrt(252)
                results[name] = vol
                vols.append(vol)
            except Exception as e:
                # Fallback to uncalibrated proxy — warn so this is visible in logs
                import warnings

                warnings.warn(
                    f"[GARCH] {name} convergence failed ({e}); using proxy fallback "
                    f"(omega={self.omega}, alpha={self.alpha}, beta={self.beta}). "
                    "Proxy params are uncalibrated defaults — vol forecast may be inaccurate.",
                    RuntimeWarning,
                    stacklevel=2,
                )
                v = self._get_proxy_vol(returns)
                results[name] = v
                vols.append(v)

        results["ensemble_avg"] = np.median(vols)

        if date_key:
            self.cache[date_key] = results

        return results

    def get_regime_vote(self, returns: np.ndarray) -> str:
        """
        v11.7 Core: GARCH-Ensemble Voting System.
        Each model (GARCH, GJR, EGARCH) votes independently.
        Agreement level determines the regime.
        """
        ensemble = self.forecast_ensemble(returns)

        # Individual Votes (Panic Thresholds)
        # GJR and EGARCH are usually more reactive to downside;
        # GARCH is broader 'tail' sentiment.
        votes_panic = 0
        votes_turbulent = 0

        # 0.35 is often 'High', 0.45 is 'Extreme' for annualised vol
        panic_level = 0.42
        turbulent_level = 0.28

        for name in ["garch", "gjr", "egarch"]:
            val = ensemble.get(name, 0)
            if val > panic_level:
                votes_panic += 1
            elif val > turbulent_level:
                votes_turbulent += 1

        # --- Voting Logic ---
        # 1. Consensus Panic: 3/3 agree on high risk OR average is extreme
        if votes_panic >= 3 or ensemble["ensemble_avg"] > 0.50:
            return "PANIC"

        # 2. Majority Concern: 2/3 agree on panic or 3/3 agree on turbulence
        if votes_panic >= 2 or (votes_panic + votes_turbulent) >= 3:
            return "TURBULENT"

        # 3. High Average: Even if models disagree slightly, if avg is high, flag it
        if ensemble["ensemble_avg"] > 0.35:
            return "TURBULENT"

        return "NORMAL"

    def get_risk_adaptation_factor(self, current_vol: float, hist_vols: list[float]) -> float:
        """Institutional-grade risk scaling (Tighten stops when uncertainty rises)."""
        if not hist_vols or len(hist_vols) < 10:
            return 1.0

        avg_hist = np.mean(hist_vols)
        if avg_hist <= 0:
            return 1.0

        std_hist = np.std(hist_vols) + 1e-6
        z_score = (current_vol - avg_hist) / std_hist

        if z_score > 3.0:
            return 0.5  # Capitulation logic
        if z_score > 1.5:
            return 0.7  # Pre-panic logic
        if z_score < -1.0:
            return 1.1  # Low volatility expansion

        return 1.0
