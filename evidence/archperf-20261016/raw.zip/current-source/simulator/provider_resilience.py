from __future__ import annotations

import threading
import time
from dataclasses import dataclass
from typing import Any

from simulator.provider_limits import (
    alpaca_max_workers_default,
    batch_pause_seconds_default,
    data_fetch_concurrency_default,
    provider_limit_payload,
    yf_options_cooldown_seconds_default,
    yf_threads_enabled_default,
)


@dataclass
class ProviderProbe:
    provider: str
    healthy: bool
    reason: str | None = None
    cooldown_seconds_remaining: float = 0.0


_COOLDOWNS: dict[str, float] = {}
_LOCK = threading.Lock()


def _now() -> float:
    return time.time()


def provider_cooldown_seconds(provider: str) -> float:
    with _LOCK:
        until = _COOLDOWNS.get(provider, 0.0)
    return max(0.0, until - _now())


def provider_available(provider: str) -> bool:
    return provider_cooldown_seconds(provider) <= 0.0


def set_provider_cooldown(provider: str, seconds: float) -> float:
    cooldown = max(float(seconds), 0.0)
    with _LOCK:
        _COOLDOWNS[provider] = _now() + cooldown
    return cooldown


def provider_probe(provider: str, reason: str | None = None) -> ProviderProbe:
    remaining = provider_cooldown_seconds(provider)
    return ProviderProbe(
        provider=provider,
        healthy=remaining <= 0.0,
        reason=reason,
        cooldown_seconds_remaining=round(remaining, 2),
    )


def is_rate_limit_error(exc: Exception) -> bool:
    message = str(exc).lower()
    markers = [
        "429",
        "too many requests",
        "rate limit",
        "ratelimit",
        "yhf throttled",
    ]
    return any(marker in message for marker in markers)


def yf_options_cooldown_seconds() -> float:
    return yf_options_cooldown_seconds_default()


def data_fetch_concurrency() -> int:
    return data_fetch_concurrency_default()


def alpaca_max_workers() -> int:
    return alpaca_max_workers_default()


def yf_threads_enabled() -> bool:
    return yf_threads_enabled_default()


def batch_pause_seconds() -> float:
    return batch_pause_seconds_default()


def provider_limit_status(provider: str) -> dict[str, Any]:
    return provider_limit_payload(provider)


def probe_to_payload(probe: ProviderProbe) -> dict[str, Any]:
    return {
        "provider": probe.provider,
        "healthy": probe.healthy,
        "reason": probe.reason,
        "cooldown_seconds_remaining": probe.cooldown_seconds_remaining,
    }
