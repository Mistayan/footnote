import numpy as np
from numba import njit, prange


@njit(parallel=True, fastmath=True, cache=True)
def garch_proxy_jit(returns, window, omega, alpha, beta):
    """
    JIT-optimized GARCH(1,1) recursive variance calculation.
    """
    variance = np.var(returns)
    # Target only the last 'window' bars
    start_idx = max(0, len(returns) - window)
    subset = returns[start_idx:]

    for r in subset:
        variance = omega + (alpha * (r**2)) + (beta * variance)

    return np.sqrt(max(0.0, variance)) * np.sqrt(252.0)


@njit(parallel=True, fastmath=True, cache=True)
def calculate_rsi_jit(prices, span=27):
    """
    RSI calculation matching Polars ewm_mean(span=27) behavior.
    alpha = 2 / (span + 1). For N=14 Wilder, span=27 (alpha=1/14).
    """
    n = len(prices)
    if n < 2:
        return np.full(n, 50.0)

    deltas = np.diff(prices)
    rsi = np.full(n, 50.0)

    gains = np.zeros(n - 1)
    losses = np.zeros(n - 1)
    for i in range(n - 1):
        if deltas[i] > 0:
            gains[i] = deltas[i]
        else:
            losses[i] = -deltas[i]

    alpha = 2.0 / (span + 1.0)

    # Matching Polars ewm_mean(adjust=True) weighted average
    # cum_weight_t = (1-alpha)*cum_weight_{t-1} + 1
    # y_t = ((1-alpha) * y_{t-1} * cum_weight_{t-1} + x_t) / cum_weight_t

    avg_gain = 0.0
    avg_loss = 0.0
    cum_weight = 0.0

    for i in range(1, n):
        idx = i - 1
        g = gains[idx]
        loss = losses[idx]

        # Update cumulative weight
        new_weight = (1.0 - alpha) * cum_weight + 1.0

        # Update weighted average
        avg_gain = ((1.0 - alpha) * avg_gain * cum_weight + g) / new_weight
        avg_loss = ((1.0 - alpha) * avg_loss * cum_weight + loss) / new_weight

        cum_weight = new_weight

        if avg_loss == 0:
            rsi[i] = 100.0 if avg_gain > 0 else 50.0
        else:
            rs = avg_gain / avg_loss
            rsi[i] = 100.0 - (100.0 / (1.0 + rs))

    return rsi


@njit(parallel=True, fastmath=True, cache=True)
def calculate_atr_jit(highs, lows, closes, window=14):
    """
    ATR calculation matching Polars tr.rolling_mean(window_size=14).
    Note: Standard Wilder's ATR would use ewm_mean, but we match current Polars production.
    """
    n = len(highs)
    if n < 2:
        return np.zeros(n)

    tr = np.zeros(n)
    for i in range(1, n):
        tr[i] = max(
            highs[i] - lows[i],
            abs(highs[i] - closes[i - 1]),
            abs(lows[i] - closes[i - 1]),
        )

    atr = np.zeros(n)
    # Optimized sliding window O(N) for ATR parity with Polars native
    if n >= window:
        window_sum = 0.0
        for i in range(1, window + 1):
            window_sum += tr[i]
        atr[window] = window_sum / window

        for i in range(window + 1, n):
            window_sum = window_sum + tr[i] - tr[i - window]
            atr[i] = window_sum / window

    return atr


@njit(parallel=True, fastmath=True, cache=True)
def calculate_breadth_velocity(daily_returns, window=10):
    """
    Calculates the Rate of Change (ROC) of the mean cross-sectional returns.
    Helps detect structural velocity shifts in market breadth.
    """
    n = len(daily_returns)
    velocity = np.zeros(n)
    if n < 2 * window:
        return velocity

    for i in prange(2 * window, n):
        # ROC of the mean return over window
        current_mean = np.mean(daily_returns[i - window : i])
        prev_mean = np.mean(daily_returns[i - 2 * window : i - window])
        velocity[i] = current_mean - prev_mean

    return velocity


@njit(parallel=True, fastmath=True, cache=True)
def calculate_vol_regime_score(vols, threshold_low=0.15, threshold_high=0.30):
    """
    Computes a regime score (0-1) based on ensemble volatility distances.
    Score > 0.8 usually triggers PANIC mode.
    """
    n = len(vols)
    scores = np.zeros(n)
    for i in prange(n):
        v = vols[i]
        if v >= threshold_high:
            scores[i] = 1.0
        elif v <= threshold_low:
            scores[i] = 0.0
        else:
            # Linear scaling between thresholds
            scores[i] = (v - threshold_low) / (threshold_high - threshold_low)
    return scores


@njit(parallel=True, fastmath=True, cache=True)
def calculate_volume_profile_jit(prices, volumes, window=30, bins=20):
    """
    Institutional Volume Profile calculation.
    Returns (POC, VAH, VAL) for each bar based on a rolling window.
    """
    n = len(prices)
    poc = np.zeros(n)
    vah = np.zeros(n)
    val = np.zeros(n)

    if n < window:
        # Fill with current price to avoid zero-division or nulls
        for i in range(n):
            poc[i] = prices[i]
            vah[i] = prices[i]
            val[i] = prices[i]
        return poc, vah, val

    for i in prange(window, n):
        p_subset = prices[i - window : i]
        v_subset = volumes[i - window : i]

        p_min = np.min(p_subset)
        p_max = np.max(p_subset)

        if p_min == p_max:
            poc[i] = p_min
            vah[i] = p_min
            val[i] = p_min
            continue

        bin_size = (p_max - p_min) / bins
        bin_volumes = np.zeros(bins)

        # Calculate Volume at Price
        for j in range(window):
            p_val = p_subset[j]
            v_val = v_subset[j]
            b_idx = int((p_val - p_min) / bin_size)
            if b_idx >= bins:
                b_idx = bins - 1
            bin_volumes[b_idx] += v_val

        # Point of Control (POC)
        max_vol_idx = 0
        max_vol = 0.0
        for b in range(bins):
            if bin_volumes[b] > max_vol:
                max_vol = bin_volumes[b]
                max_vol_idx = b

        poc[i] = p_min + (max_vol_idx + 0.5) * bin_size

        # Value Area (70% of total volume)
        total_vol = 0.0
        for b in range(bins):
            total_vol += bin_volumes[b]

        target_vol = total_vol * 0.70
        curr_vol = bin_volumes[max_vol_idx]
        low_b = max_vol_idx
        high_b = max_vol_idx

        while curr_vol < target_vol:
            # Check price levels adjacent to the current area
            v_low = bin_volumes[low_b - 1] if low_b > 0 else 0.0
            v_high = bin_volumes[high_b + 1] if high_b < bins - 1 else 0.0

            if v_low == 0 and v_high == 0:
                break

            if v_low >= v_high:
                curr_vol += v_low
                low_b -= 1
            else:
                curr_vol += v_high
                high_b += 1

        val[i] = p_min + low_b * bin_size
        vah[i] = p_min + (high_b + 1) * bin_size

    return poc, vah, val


def calculate_breadth_torch(prices_matrix: np.ndarray, sma_matrix: np.ndarray) -> np.ndarray:
    """Cross-platform breadth analyzer.

    Priority: torch (CUDA/ROCm/MPS/DirectML) → ONNX DirectML (Windows) → NumPy.
    NumPy wins below ~1500 tickers; GPU paths are for the 1500–2000 universe.
    """
    from .gpu_breadth_torch import torch_breadth

    result = torch_breadth(prices_matrix, sma_matrix)
    if result is not None:
        return result

    try:
        from .gpu_breadth_engine import GpuBreadthEngine

        engine = GpuBreadthEngine()
        return engine.compute_market_breadth(prices_matrix, sma_matrix)
    except Exception as e:
        import warnings

        warnings.warn(f"[Breadth] GPU path failed: {e}. Using NumPy fallback.", RuntimeWarning)
        return np.mean(prices_matrix > sma_matrix, axis=1)
