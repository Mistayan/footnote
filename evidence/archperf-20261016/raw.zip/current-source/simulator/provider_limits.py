from __future__ import annotations

import os
from dataclasses import asdict, dataclass
from typing import Any


@dataclass(frozen=True)
class ProviderLimitProfile:
    provider: str
    source_type: str
    hard_limit: str
    safe_limit: str
    notes: tuple[str, ...]


PROVIDER_LIMITS: dict[str, ProviderLimitProfile] = {
    "alpaca_trading": ProviderLimitProfile(
        provider="alpaca_trading",
        source_type="official",
        hard_limit="200 requests/min/account by default",
        safe_limit="120-150 requests/min/account",
        notes=(
            "Retail default per Alpaca support.",
            "Some non-retail accounts may be raised to 1000 requests/min.",
        ),
    ),
    "alpaca_market_data_free": ProviderLimitProfile(
        provider="alpaca_market_data_free",
        source_type="official",
        hard_limit="200 calls/min on free data plans",
        safe_limit="120-150 calls/min",
        notes=(
            "Paid plans may go far higher.",
            "Free websocket symbol caps still matter for live monitoring.",
        ),
    ),
    "ibkr_web_api": ProviderLimitProfile(
        provider="ibkr_web_api",
        source_type="official",
        hard_limit="50 requests/sec/authenticated username; 10 requests/sec via CP Gateway",
        safe_limit="5-8 requests/sec steady-state plus endpoint-specific caps",
        notes=(
            "Some endpoints are much stricter than the global headline rate.",
            "IBKR can place violators in a 10-minute penalty box after 429 events.",
        ),
    ),
    "ibkr_account_management": ProviderLimitProfile(
        provider="ibkr_account_management",
        source_type="official",
        hard_limit="10 requests/sec/endpoint and 600 requests/min/master account",
        safe_limit="5 requests/sec/endpoint with burst discipline",
        notes=("Use slower pacing for account metadata and admin flows.",),
    ),
    "yfinance_market_data": ProviderLimitProfile(
        provider="yfinance_market_data",
        source_type="community",
        hard_limit="No official published limit",
        safe_limit="Best-effort fallback only; batch, cache, and pause",
        notes=(
            "Treat as non-contractual and unstable.",
            "Prefer cached/batched calls over per-symbol loops.",
        ),
    ),
    "yfinance_options": ProviderLimitProfile(
        provider="yfinance_options",
        source_type="community",
        hard_limit="No official published limit",
        safe_limit="Top-of-book scans only, cached, with cooldown after throttling",
        notes=("Options endpoints appear more fragile than historical download batching.",),
    ),
}


def get_provider_limit(provider: str) -> ProviderLimitProfile:
    return PROVIDER_LIMITS[provider]


def provider_limit_payload(provider: str) -> dict[str, Any]:
    profile = get_provider_limit(provider)
    return asdict(profile)


def safe_env_int(name: str, default: int) -> int:
    return max(1, int(os.getenv(name, str(default))))


def safe_env_bool(name: str, default: bool) -> bool:
    default_text = "true" if default else "false"
    return os.getenv(name, default_text).lower() in {"1", "true", "yes"}


def safe_env_float(name: str, default: float) -> float:
    return max(0.0, float(os.getenv(name, str(default))))


def data_fetch_concurrency_default() -> int:
    return safe_env_int("BORG_DATA_FETCH_CONCURRENCY", 2)


def alpaca_max_workers_default() -> int:
    return safe_env_int("BORG_ALPACA_MAX_WORKERS", 4)


def yf_threads_enabled_default() -> bool:
    return safe_env_bool("BORG_YF_THREADS", False)


def batch_pause_seconds_default() -> float:
    pause_ms = safe_env_float("BORG_FETCH_BATCH_PAUSE_MS", 250.0)
    return pause_ms / 1000.0


def yf_options_cooldown_seconds_default() -> float:
    return safe_env_float("BORG_YF_OPTIONS_COOLDOWN_SECONDS", 180.0)
