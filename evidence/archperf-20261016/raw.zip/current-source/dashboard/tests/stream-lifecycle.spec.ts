import {test, expect} from '@playwright/test';
import {NextRequest} from 'next/server';
import {GET, POST} from '../app/api/stream/route';

const publish = () => POST(new NextRequest('http://offline.invalid/api/stream', {
  method:'POST', body:JSON.stringify({synthetic_probe:true}),
}));

test('cancel releases exactly the owning SSE controller before another publication', async () => {
  const survivor=await GET();
  const removed=await GET();
  try {
    const deleted:unknown[]=[];
    const originalDelete=Set.prototype.delete;
    Set.prototype.delete=function(value:unknown) {deleted.push(value);return originalDelete.call(this,value);};
    try {await removed.body!.cancel('synthetic disconnect reason, not a controller');}
    finally {Set.prototype.delete=originalDelete;}
    // POST otherwise hides the leak by catching enqueue on dead controllers.
    expect(deleted.some(value=>value instanceof ReadableStreamDefaultController)).toBe(true);
    const result=await (await publish()).json();
    expect(result.subscribers).toBe(1);
  } finally {
    await survivor.body!.cancel();
  }
  expect((await (await publish()).json()).subscribers).toBe(0);
});

test('repeated SSE open/cancel retains no subscribers and preserves latest event', async () => {
  for(let i=0;i<50;i++) {
    const response=await GET();
    await response.body!.cancel();
  }
  expect((await (await publish()).json()).subscribers).toBe(0);
  const response=await GET();
  const reader=response.body!.getReader();
  try {
    const event=await reader.read();
    expect(new TextDecoder().decode(event.value)).toBe('event: signal\ndata: {"synthetic_probe":true}\n\n');
  } finally {await reader.cancel();reader.releaseLock();}
  expect((await (await publish()).json()).subscribers).toBe(0);
});
