import {defineConfig} from '@playwright/test';
export default defineConfig({testDir:'./tests',testMatch:'stream-lifecycle.spec.ts',workers:1,reporter:'list',outputDir:process.env.BORG_UI_EVIDENCE_DIR ?? 'C:/Users/johan/AppData/Local/hermes/cache/scratch/archperf-stream-tests'});
