"""Synthetic scratch registry only; never opens an actual production record."""
import importlib.util
import json
import sqlite3
from contextlib import closing
from pathlib import Path

spec = importlib.util.spec_from_file_location("registry_dashboard_reader", Path(__file__).parents[1] / "scripts/read_registry_dashboard.py")
reader = importlib.util.module_from_spec(spec)
spec.loader.exec_module(reader)


def seed(path):
    with closing(sqlite3.connect(path)) as db, db:
        db.executescript("""
        PRAGMA user_version=1;
        CREATE TABLE runs(run_id TEXT PRIMARY KEY,parent_run_id TEXT,name TEXT,pid INTEGER,identity TEXT,started_at TEXT,heartbeat_at TEXT,ended_at TEXT,status TEXT);
        CREATE TABLE receipts(sequence INTEGER PRIMARY KEY AUTOINCREMENT,run_id TEXT,kind TEXT,at TEXT,body TEXT);
        CREATE TABLE registry_maintenance_stats(singleton INTEGER PRIMARY KEY,body TEXT);
        """)
        for i, status in enumerate(["interrupted", "partial", "running", "recovered_orphan", "ok"]):
            rid = f"00000000-0000-4000-8000-{i:012d}"
            db.execute("INSERT INTO runs VALUES(?,?,?,?,?,?,?,?,?)", (rid, None, "cli", 999, "SECRET IDENTITY", "2026-01-01T00:00:00+00:00", "2026-01-01T00:01:00+00:00", None if status == "running" else "2026-01-01T00:02:00+00:00", status))
            db.execute("INSERT INTO receipts(run_id,kind,at,body) VALUES(?,?,?,?)", (rid, "start", "2026-01-01T00:00:00+00:00", json.dumps({"password": "SECRET RAW"})))


def test_bounded_read_only_projection_and_server_filter(tmp_path):
    path = tmp_path / "registry.sqlite"
    seed(path)
    before = path.read_bytes()
    result = reader.read_page(path, {"size": 2, "page": 1, "asof": "2026-01-02T00:00:00Z", "status": "all", "name": "all"})
    assert result["status"] == "ready"
    assert result["matching"] == 5
    assert len(result["rows"]) == 2
    assert "SECRET" not in json.dumps(result)
    assert result["rows"][0]["accounting_status"] == "unknown"
    assert result["rows"][0]["coverage_status"] == "unknown"
    filtered = reader.read_page(path, {"size": 2, "page": 1, "asof": "2026-01-02T00:00:00Z", "status": "degraded", "name": "cli"})
    assert filtered["matching"] == 1
    assert filtered["rows"][0]["status"] == "partial"
    assert path.read_bytes() == before


def test_bound_raw_receipt_materialization(tmp_path):
    path = tmp_path / "registry.sqlite"
    seed(path)
    with closing(sqlite3.connect(path)) as db, db:
        db.execute("INSERT INTO receipts(run_id,kind,at,body) VALUES(?,?,?,?)", ("00000000-0000-4000-8000-000000000000", "input", "2026-01-01T00:00:00+00:00", "x" * 10000))
    # SQL must apply the byte/character bound before returning raw data to Python.
    seen = []
    class Cursor:
        def fetchall(self):
            return [("input", "x" * 4097)]
    class DB:
        def execute(self, sql, args):
            seen.append(sql)
            return Cursor()
    result = reader.projection(DB(), "00000000-0000-4000-8000-000000000000", "2026-01-02T00:00:00Z")
    assert result["coverage_status"] == "unknown"
    assert "substr(body,1,4097)" in seen[0]


def test_wal_sidecars_are_refused_before_sqlite_access(tmp_path, monkeypatch):
    path = tmp_path / "registry.sqlite"
    seed(path)
    Path(str(path) + "-wal").write_bytes(b"synthetic WAL")
    monkeypatch.setattr(sqlite3, "connect", lambda *a, **k: (_ for _ in ()).throw(AssertionError("WAL access prohibited")))
    assert reader.read_page(path, {})["status"] == "unavailable"


def test_asof_pagination_and_pruning_detection(tmp_path):
    path = tmp_path / "registry.sqlite"
    seed(path)
    q = {"size": 2, "page": 1, "asof": "2026-01-02T00:00:00Z"}
    first = reader.read_page(path, q)
    ids = []
    for page in range(1, first["pages"] + 1):
        result = reader.read_page(path, {**q, "page": page, "snapshot": first["snapshot"]})
        ids.extend(r["run_id"] for r in result["rows"])
    assert len(ids) == len(set(ids)) == 5
    historic = reader.read_page(path, {**q, "asof": "2026-01-01T00:00:30Z", "size": 50})
    assert all(r["status"] == "running" for r in historic["rows"])
    with closing(sqlite3.connect(path)) as db, db:
        db.execute("DELETE FROM receipts WHERE sequence=1")
    changed = reader.read_page(path, {**q, "snapshot": first["snapshot"]})
    assert changed["status"] == "changed"
    assert changed["matching"] is None


def test_consumed_evidence_and_retention_are_independent(tmp_path):
    path = tmp_path / "registry.sqlite"
    seed(path)
    rid = "00000000-0000-4000-8000-000000000000"
    with closing(sqlite3.connect(path)) as db, db:
        db.execute("INSERT INTO receipts(run_id,kind,at,body) VALUES(?,?,?,?)", (rid, "manifest", "2026-01-01T00:00:00+00:00", json.dumps({"required": [["listing", "AAA.PA"]]})))
        body = {"role": "listing", "listing": "AAA.PA", "rows": 3, "source_sha256": "a" * 64, "required_session": "2025-12-31T00:00:00Z", "consumed_session": "2025-12-31T00:00:00Z", "freshness_status": "stale", "secret": "SECRET"}
        db.execute("INSERT INTO receipts(run_id,kind,at,body) VALUES(?,?,?,?)", (rid, "input", "2026-01-01T00:00:00+00:00", json.dumps(body)))
        summary = {"at": "2026-01-01T00:00:00Z", "probed": 5, "recovered": 1, "pruned": 2, "database_bytes": 8192, "used_bytes": 4096, "max_database_bytes": 4096, "keep_latest": 1, "retention_days": None, "over_soft_cap": True, "password": "SECRET"}
        db.execute("INSERT INTO registry_maintenance_stats VALUES(1,?)", (json.dumps(summary),))
    result = reader.read_page(path, {"runId": rid, "asof": "2026-01-02T00:00:00Z"})
    row = result["rows"][0]
    assert row["coverage_status"] == row["freshness_status"] == "complete"
    assert row["accounting_status"] == row["promotion_status"] == "unknown"
    assert result["maintenance"]["over_soft_cap"] is True
    assert "SECRET" not in json.dumps(result)
    with closing(sqlite3.connect(path)) as db, db:
        body["consumed_session"] = "2025-12-30T00:00:00Z"
        db.execute("INSERT INTO receipts(run_id,kind,at,body) VALUES(?,?,?,?)", (rid, "input", "2026-01-01T00:00:00+00:00", json.dumps(body)))
    assert reader.read_page(path, {"runId": rid, "asof": "2026-01-02T00:00:00Z"})["rows"][0]["freshness_status"] == "stale"
    with closing(sqlite3.connect(path)) as db, db:
        for _ in range(513):
            db.execute("INSERT INTO receipts(run_id,kind,at,body) VALUES(?,?,?,?)", (rid, "heartbeat", "2026-01-01T00:00:00+00:00", "{}"))
    bounded = reader.read_page(path, {"runId": rid, "asof": "2026-01-02T00:00:00Z"})["rows"][0]
    assert bounded["evidence_bounded"] is True
    assert bounded["coverage_status"] == bounded["freshness_status"] == "unknown"


def test_missing_retention_policy_is_unknown_not_disabled(tmp_path):
    path = tmp_path / "registry.sqlite"
    seed(path)
    with closing(sqlite3.connect(path)) as db, db:
        db.execute("INSERT INTO registry_maintenance_stats VALUES(1,?)", (json.dumps({"at": "2026-01-01T00:00:00Z", "over_soft_cap": False}),))
    assert reader.read_page(path, {"asof": "2026-01-02T00:00:00Z"})["maintenance"] is None


def test_unknown_source_is_not_valid_empty_and_frozen_refuses_before_open(tmp_path, monkeypatch):
    path = tmp_path / "missing.sqlite"
    assert reader.read_page(path, {})["matching"] is None
    assert not path.exists()
    monkeypatch.setenv("BORG_RESTATEMENT_DIR", "frozen-invalid")
    monkeypatch.setattr(sqlite3, "connect", lambda *a, **k: (_ for _ in ()).throw(AssertionError("access prohibited")))
    assert reader.read_page(path, {})["status"] == "blocked"


def test_irrelevant_receipt_bodies_are_not_materialized(tmp_path):
    """Bound retained history without copying every heartbeat payload to Python."""
    path = tmp_path / "registry.sqlite"
    seed(path)
    rid = "00000000-0000-4000-8000-000000000000"
    with closing(sqlite3.connect(path)) as db, db:
        db.executemany("INSERT INTO receipts(run_id,kind,at,body) VALUES(?,?,?,?)",
                       [(rid, "heartbeat", "2026-01-01T00:01:00+00:00", "x" * 4000)] * 20)
        materialized = []

        def observed_substr(body, start, length):
            materialized.append(len(body))
            return body[start - 1:start - 1 + length]

        db.create_function("substr", 3, observed_substr)
        result = reader.projection(db, rid, "2026-01-02T00:00:00+00:00")
        assert result["coverage_status"] == "unknown"
        assert result["evidence_bounded"] is False
        assert materialized == [], "non-evidence bodies must stay below the SQL boundary"

        db.executemany("INSERT INTO receipts(run_id,kind,at,body) VALUES(?,?,?,?)",
                       [(rid, "heartbeat", "2026-01-01T00:01:00+00:00", "x" * 4000)] * 513)
        assert reader.projection(db, rid, "2026-01-02T00:00:00+00:00")["evidence_bounded"] is True


