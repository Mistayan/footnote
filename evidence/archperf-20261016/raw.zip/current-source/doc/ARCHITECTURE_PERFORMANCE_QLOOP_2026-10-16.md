# Architecture + performance: five combined QLoop rounds — 2026-10-16

## Decision and evidence boundary

Exactly **five combined architecture/performance rounds**, not UI redesign loops.
Two narrow fixes were implemented: avoid materializing irrelevant registry receipt
bodies, and release an SSE subscriber at cancellation rather than at the next
publication. Strategy selection, prices, quantities, accounting, refresh defaults,
publication policy and broker behavior were not changed.

**Authoritative final verdicts:**
[`reports/evidence/archperf-20261016/acceptance.json`](../reports/evidence/archperf-20261016/acceptance.json).
That receipt separates architecture correctness, measured performance,
protected-state preservation and production health. It is not a claim that a
historical aggregate applies to new sources. The final source/docs freeze runs
**after this report and its maintained discovery links**. Read gate exits and
hash discrepancies from that receipt; do not infer them from this narrative.

Raw receipts, reproducing harnesses, fixture manifests, archived baseline reader,
span samples, HTTP samples, browser navigation/resource entries and failed harness
attempts are delivered in the adjacent `raw.zip`, with checksums in `manifest.json`.
Working evidence root:
`C:/Users/johan/AppData/Local/hermes/cache/scratch/archperf-20261016/`.
The reducer is `reduce.py`; its output is `summary.json`. Integrity hashes are
unauthenticated, not signatures or financial certification.

## Discovered architecture, before measurement

- Existing `simulator/observability.py` supplies fixed-cardinality counters,
  `span`, run/span/parent correlation, timestamps, duration, status and explicit
  coverage. `simulator/run_registry.py` owns durable lifecycle/operation receipts,
  an existing heartbeat and maintenance cadence. No parallel collector, daemon,
  provider client or scheduler was introduced.
- `RunRegistry.start/heartbeat -> maintain` invokes optional operational alert
  evaluation **after closing the registry write transaction**. Alerts remain
  opt-in; dashboard GET is presentation only. Unknown input/owner/accounting/
  promotion evidence remains Unknown.
- Real `/operations -> registryLoader -> disposable isolated Python reader ->
  SQLite` and `/api/registry` use the same bounded projection. Rollback journaling,
  read-only transaction, 50-row page cap, 512-receipt evidence cap, SQL deadline,
  subprocess limit and frozen-lane refusal remain. The page separately awaits
  the alert reader: this is sequential independent I/O, not an O(1) in-process API.
- Existing provider profiler `scripts/profile_incremental_refresh.py` executes
  actual DataEngine normalization, indicators, exact-date FX and scratch cache
  writes behind an offline SDK boundary. `provider_phases.py` distinguishes
  opaque SDK envelopes from actual public transport. No historical public
  transport timings were relabeled as new network measurements.
- MCP connection was verified in this session; project
  `D-Projets-BorgInvestor` is ready but coverage generation is **2026-08-13**.
  Registry/observability files were not tracked by that generation. `projection`
  impact lookup returned function-not-found. The SSE GET graph had zero recorded
  inbound callers, **not proof of no consumer**: current source explicitly shows
  `LiveDashboard.tsx` subscribing and `live_monitor` publishing. Current targeted
  source inspection supplemented the stale graph before both low-scope edits.

## Measurement contract

Next **15.5.23**, fresh `next build` and owned `next start`, desktop Chromium
1440×1000. The initial build ID is `vhy5RWOWoOR1eD6F1_hqO`; the post-SSE build is
`NNJplU-1Wn-dslRmxQenJ`. All app/components/lib inputs are byte-compared at final
acceptance. Dependencies were really copied, not junctioned; no `.env` or live
state was copied. Missing KPI/alert fixtures deliberately produce Unknown/503,
not fake healthy financial data. Build logs retain the old Browserslist warning.

Both registry inputs are **synthetic**, not production inventory: 36 runs with
5 receipts/run, and an explicit scale case of 50 runs with 511 receipts/run,
including 508 padded heartbeat bodies/run. They use the actual registry schema
and indexes initialized by `RunRegistry._db` in scratch. The scale case exposes
unnecessary payload materialization; it does not estimate the current live store.
Neither live SQLite nor live WAL/SHM was opened, even read-only.

Each round repeats both fixtures, seven direct-reader samples per lane, seven
HTTP samples per route and five browser navigations per fixture. The first hit
is separate from six warm samples (four warm browser navigations); **not** OS
cold-cache eviction and not a p95 claim. Routes are `/operations`, `/api/registry`
and `/api/operational-alerts`. Document transfer and individual resource sizes
are recorded separately in a bounded post-load window; prefetch is not attributed
to the document. Navigation-aborted requests are retained separately from page
errors. Initial `networkidle`/text-predicate harness failures are preserved as
unqualified attempts, not application latency samples. No screenshot/UI score
is used to certify architecture or speed.

Existing spans wrap the actual scratch reader, using `db_snapshot` under the
existing durable script run. Every successful round records its real run UUID,
28 completion samples with status/coverage and exact source/protected hashes.
The standalone provider replay captures another 31 existing operation samples.
These are diagnostic campaign samples, not a new permanent telemetry history.
Normal durable operation receipts are not a full persisted phase-timing history;
raw duration samples live in the campaign logs.

## QLoop 1 — ownership, transport baseline, materialization critique

**Architecture critique (P2):** `projection` fetches `substr(body,1,4097)` for
*every* receipt, then discards all lifecycle/heartbeat bodies in Python. Keeping
all receipt kinds for overflow detection is correct; copying their bodies is not
needed. The declared row cap therefore bounded output but still caused avoidable
large temporary allocations. Source impact: only this standalone reader and its
operator-reader tests were found; no financial caller changed.

**Performance evidence:** `round-1/receipt.json`, `backend.json`, `http.json`,
`spans.json` and the two `*-browser.json` files. Scale warm reader baseline
202.246 ms; the unchanged candidate 205.344 ms. Small baseline 1.833 ms versus
1.935 ms. Scale API 343.840 ms and operations 1508.512 ms in this first campaign.
Those HTTP figures are a baseline, **not** a controlled causal comparison with
later warmer campaigns. Alert API correctly returns 503 for the absent store.

**Correction/defer:** select a SQL-boundary body suppression, not a schema/index
migration or persistent cache. Do not filter away heartbeat rows: that would
weaken the 512-receipt Unknown rule. Two measurement-bootstrap failures were
corrected and archived before qualification. No previous product finding to
retest. All 24 oracle comparisons passed; fixture/source/protected hashes were
stable during the qualified round; owned listeners were stopped and read back
as absent.

## QLoop 2 — minimal registry correction, parity and repeated measurement

**Architecture critique (P2, fixed):** a real SQLite regression overrides `substr`
to observe which bodies cross the projection boundary. It failed before the fix
on 21 irrelevant materializations. The corrected SQL uses `CASE WHEN kind IN
('manifest','input') THEN substr(...) END`, preserving order, the full receipt
count, overflow Unknown, malformed evidence behavior and all existing bounds.
No writer, journal mode, schema, cache or lifecycle policy changed.

**Correction evidence:** `round-2-red.log`; `round-2-green.log` (8 passed), exact
process guard receipt, and the one-query implementation diff. The 513-heartbeat
overflow still withholds coverage. Previous P2 is retested by the real boundary
regression and 24 independent old/new page comparisons.

**Performance remeasurement:** scale warm reader 203.137 → 42.901 ms in this
round; small 2.007 → 1.531 ms is too small/noisy to generalize. Production-mode
HTTP/browser repeats passed with the same static Next build and the separately
hash-bound updated external Python reader. This is not falsely called a rebuilt
JavaScript artifact. No new source/protected drift in the round.

## QLoop 3 — SSE ownership critique and resource correction

**Architecture critique (P2, fixed):** `UnderlyingSource.cancel` receives a
*reason*, not its stream controller. Existing code deleted that reason from the
subscriber Set, retaining disconnected controllers until a later POST caught
failed enqueue. A first black-box subscriber-count test passed because POST
masked the leak; that insufficient test/log is preserved. The strengthened test
observes the actual cancellation deletion before publication: it failed, then
passed after a closure retained and removed only its owned controller.

**Correction evidence:** `round-3-red.log`, `round-3-green.log` (2 tests),
`dashboard/tests/stream-lifecycle.spec.ts`. Surviving subscribers and exact latest
SSE event text are preserved. Source-bound real-route execution with an observed
Set and 1,000 synthetic open/cancel operations retained **1,000 → 0** controllers
before the next POST. Warm publication/sweep median **4.238 → 0.097 ms**; cancellation
work **4.600 → 4.897 ms/1,000**, a small cleanup trade-off, not a universal speed
improvement or browser-RSS measurement. Raw samples: `stream-benchmark.json`.

**Prior-finding retest/performance:** registry page parity 24/24; scale warm
reader 189.230 → 38.352 ms. The round's operations/API measurements still use the
previous Next build: **they do not certify the new SSE executable**. Fresh rebuild
and HTTP SSE behavior are explicitly carried into round 4, rather than pretending
a source-level regression is packaged runtime acceptance.

## QLoop 4 — fresh executable, real backend replay, conservative deference

**Architecture critique (P2, justified defer):** no executable provenance adapter
exists to authorize automatic market-refresh skipping. File dates/complete rows
cannot establish listing/calendar/adjustment/retrieval/FX lineage. Keep conservative
refresh blocked and the legacy default intact; do not manufacture request savings.
A storage rewrite, provider fan-out or permanent worker is not warranted by these
fixtures. The sequential registry/alerts reads remain a measured opportunity, not
an implemented concurrency gain.

**Correction/retest:** fresh `build-after.log` passes production compile, type/lint
and static generation. The new build is actually served by owned listeners;
`round-4/*-browser.json` contains the real HTTP SSE connected marker, unchanged
synthetic event text, publication and disconnect results. Immediate cleanup and
registry correction remain covered by source tests and 24/24 old/new comparisons.
The first targeted Python command named a nonexistent test file and exited 4
before tests; retained as `round-4-regressions.log`. Corrected discovery returned
**104 passed**, zero attempts in its exact-process guard.

**Backend/performance evidence:** existing `profile_incremental_refresh` was run
with its literal pinned `940600638b1aeea1bf1a6098063865e6cabf90ed` DataEngine oracle,
actual synthetic SDK-boundary frames, existing spans and a preinstalled production/
network guard. Every lane emitted the same nonempty **650 rows**, exact FX and
same output digest; missing FX was refused. **6 → 6 SDK attempts, zero avoided
calls and zero outbound requests.** Oracle first-process/JIT sample 6167.584 ms
is not comparable to candidate's later warm 427.464 ms. Remaining legacy samples
423.618/427.214 ms versus candidate 437.685/445.190 ms show no backend speedup.
Shared current helpers and five sessions are not annual/economic certification.
Archived Polars deprecations are retained; strict resource warnings were not
suppressed. Registry scale warm reader 182.733 → 37.649 ms, with no fixture or
protected-byte change in the qualified round.

## QLoop 5 — paired transport, adversarial preservation, final aggregate

**Architecture critique (P2, resolved acceptance method):** early whole-route
before/after campaigns had environmental warmup differences much larger than the
small-fixture SQL work. Reject a blanket production speedup claim. Re-measure
baseline/candidate external readers interleaved **on the same final Next build,
same owned server and identical fixture**. The independent baseline reader is
archived pre-edit working source, not repeated calls to the candidate.

**Paired measured outcome (warm medians, six samples/lane):**

| Fixture/boundary | Baseline ms | Candidate ms | Interpretation |
|---|---:|---:|---|
| Small registry API | 80.297 | 82.992 | 3.36% slower; no current-sized gain certified |
| Small operations document | 162.413 | 164.798 | 1.47% slower; no current-sized gain certified |
| Synthetic scale registry API | 261.051 | 121.625 | 53.41% lower latency in this scale fixture |
| Synthetic scale operations document | 344.776 | 209.731 | 39.17% lower latency in this scale fixture |

Every paired API **and complete HTML document body is byte-identical**, respectively
16,527/138,242 bytes (small) and 22,860/177,189 bytes (scale). Payload reduction is
**not** the gain: less unnecessary SQL/Python materialization is. Direct scale
reader 178.142 → 37.390 ms; small 1.829 → 2.002 ms again gives no small-store win.
First samples, TTFB, bytes and all repetitions remain in raw files. Browser
navigation/render opportunities are separately captured; they are not GPU/layout
CPU timings and no LCP or tail-latency claim is made.

**Prior finding retest:** 24 oracle cases, real final-build SSE transport, exact
body parity, unchanged Unknown accounting/promotion, unchanged synthetic fixture
hashes, and owned-child/listener exit readback. Final acceptance then freezes
all source **and maintained docs**, runs canonical strict `tests/` discovery,
configured lint/type gates plus explicit changed-module typing, dashboard typing,
alert-loader and SSE/registry API regressions. Commands/exits, test totals and
coverage are in the final machine receipt, not guessed here. Source differences,
protected differences and guard attempts are independent predicates. A gate
failure, unexplained live drift or missing exact-process receipt prevents a
corresponding PASS; an observed worker is not writer attribution. No restoration,
repeated quiet-window laundering or production-worker stop is permitted.

## Separate verdict policy and residual limits

- **Architecture correctness:** scoped only to these corrections and existing
  ownership/read-model contracts; passing offline tests is not entire-system proof.
- **Performance:** measured benefit for explicit synthetic retention scale; no
  meaningful current-sized or provider-network improvement certified. Python
  process startup/isolated reader I/O remains dominant for the small API.
- **Preservation:** exact source/docs and protected byte manifests decide, separately
  for each run and for the final aggregate. The raw export is an intentional new
  evidence artifact, not an unexplained mutation of a pre-existing protected file.
- **Production health:** **UNKNOWN / NOT CERTIFIED**. No live database inspection,
  broker authentication, SDK/provider acquisition, production refresh, task trigger,
  alert activation, accounting repair, strategy comparison or promotion occurred.
  Expected missing-alert 503 is not healthy production. No commit/push.

No numeric architecture score is fabricated; five rounds are evidence/retest
iterations, not five independent reviewers or statistical confidence levels.

## Bounded follow-ups

1. Measure authorized, coherently frozen real registry retention distributions before
   tuning indexes/retention. Potential gain is avoiding scale regressions; do not
   query live WAL or extrapolate this synthetic gain to the current store.
2. Consider parallel independent registry/alert read requests only after cancellation/
   capacity tests and a paired baseline. Potential savings are one reader envelope,
   not proven here; avoid hiding new concurrency pressure behind faster medians.
3. Extend operator timing display through the existing telemetry contract if persistent
   phase history is required. Potential gain is diagnosis, not faster trading; keep
   fixed cardinality/redaction and do not build another observability platform.
