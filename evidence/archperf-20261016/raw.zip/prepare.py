from pathlib import Path
import os, sys, shutil, json, hashlib, subprocess
ROOT=Path('D:/Projets/BorgInvestor')
OUT=Path(__file__).parent
sys.path.insert(0,str(ROOT))
from scripts.verify_state_alert_refresh_integration import protected,sources

def save(name,value):
 (OUT/name).write_text(json.dumps(value,indent=2),encoding='utf8')
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
if not (OUT/'initial-protected.json').exists():
 save('initial-protected.json',protected());save('initial-sources.json',sources())
 save('initial-git.json',{'status':subprocess.check_output(['git','status','--porcelain=v1'],cwd=ROOT,text=True),'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()})
(OUT/'baseline').mkdir(exist_ok=True)
shutil.copy2(ROOT/'scripts/read_registry_dashboard.py',OUT/'baseline/read_registry_dashboard.py')
for folder in ['app','components','lib','tests']:
 shutil.copytree(ROOT/'dashboard'/folder,OUT/'dashboard'/folder,dirs_exist_ok=True)
for p in (ROOT/'dashboard').iterdir():
 if p.is_file() and p.suffix in {'.json','.ts','.js','.mjs'} and p.name not in {'tsconfig.tsbuildinfo'}:
  shutil.copy2(p,OUT/'dashboard'/p.name)
(OUT/'dashboard/public').mkdir(exist_ok=True)
for p in (ROOT/'dashboard/public').glob('*.svg'):shutil.copy2(p,OUT/'dashboard/public'/p.name)
for rel in ['scripts/read_registry_dashboard.py','simulator/operational_alerts.py']:
 p=OUT/rel;p.parent.mkdir(exist_ok=True,parents=True);shutil.copy2(ROOT/rel,p)
old=Path('C:/Users/johan/AppData/Local/hermes/cache/scratch/borg-desktop-20261016/dashboard/node_modules')
if not (OUT/'dashboard/node_modules').exists():shutil.copytree(old,OUT/'dashboard/node_modules')
os.environ.update(PYTHON_DOTENV_DISABLED='1',BORG_STATE_DIR=str(OUT/'state'),BORG_LOGS_DIR=str(OUT/'logs'),BORG_TELEMETRY_DIR=str(OUT/'telemetry'),BORG_QUOTE_CACHE_DIR=str(OUT/'quotes'))
for k in list(os.environ):
 if k.startswith(('BORG_RUN_','BORG_OPERATIONAL_ALERT')):os.environ.pop(k)
from simulator.run_registry import RunRegistry
fixtures={}
for name,n,heartbeats in [('small',36,2),('scale',50,508)]:
 p=OUT/(name+'.sqlite')
 if not p.exists():
  registry=RunRegistry(p)
  with registry._db() as db:
   for i in range(n):
    rid=f'00000000-0000-4000-8000-{i:012d}'
    status=['ok','partial','failed','interrupted','running','recovered_orphan'][i%6]
    db.execute('INSERT INTO runs VALUES(?,?,?,?,?,?,?,?,?)',(rid,None,'cli',0,'synthetic','2026-01-01T00:00:00+00:00','2026-01-01T00:01:00+00:00',None if status=='running' else '2026-01-01T00:02:00+00:00',status))
    receipts=[('start','{}'),('manifest',json.dumps({'required':[['listing','AAA.PA']]})),('input',json.dumps({'role':'listing','listing':'AAA.PA','rows':3,'source_sha256':'a'*64,'required_session':'2025-12-31T00:00:00Z','consumed_session':'2025-12-31T00:00:00Z'}))]
    receipts += [('heartbeat',json.dumps({'synthetic_padding':'x'*4000}))]*heartbeats
    db.executemany('INSERT INTO receipts(run_id,kind,at,body) VALUES(?,?,?,?)',[(rid,kind,'2026-01-01T00:01:00+00:00',body) for kind,body in receipts])
 fixtures[name]={'path':str(p),'runs':n,'receipts_per_run':3+heartbeats,'sha256':sha(p),'kind':'synthetic scratch rows using actual RunRegistry schema/indexes; not production inventory'}
save('fixtures.json',fixtures)
save('source-copy.json',{str(p.relative_to(OUT)):sha(p) for folder in ['app','components','lib'] for p in (OUT/'dashboard'/folder).rglob('*') if p.is_file()})
print(json.dumps({'out':str(OUT),'fixtures':fixtures},indent=2))
