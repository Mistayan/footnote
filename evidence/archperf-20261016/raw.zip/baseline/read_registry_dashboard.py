"""Finite read-only operational projection; stdlib SQLite, no application imports."""
import json
import os
import re
import sqlite3
import sys
import time
import uuid
from contextlib import closing
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

NAMES = {"cli", "monitor", "sentinel", "script", "cache_update", "news_feed", "unknown"}
STATES = {"running", "ok", "partial", "failed", "timeout", "interrupted", "recovered_orphan"}
DISPLAY = {"partial": "degraded", "failed": "degraded", "timeout": "degraded", "recovered_orphan": "recovered"}
RECEIPT_LIMIT = 512


def instant(value):
    parsed = datetime.fromisoformat(value.replace("Z", "+00:00"))
    if parsed.tzinfo is None:
        raise ValueError("aware timestamp required")
    return parsed.astimezone(timezone.utc).isoformat()


def identifier(value):
    if value is None:
        return None
    return value if isinstance(value, str) and str(uuid.UUID(value)) == value else None


def unknown(status="unavailable"):
    return {"status": status, "rows": [], "matching": None, "pages": None, "maintenance": None,
            "error": "Registry unavailable; operational counts and evidence are unknown."}


def projection(db, rid, asof):
    events = db.execute("SELECT kind,substr(body,1,4097) FROM receipts WHERE run_id=? AND at<=? ORDER BY sequence LIMIT ?",
                        (rid, asof, RECEIPT_LIMIT + 1)).fetchall()
    result = {"coverage_status": "unknown", "freshness_status": "unknown", "accounting_status": "unknown",
              "promotion_status": "unknown", "inputs_requested": None, "inputs_available": None,
              "evidence_bounded": len(events) > RECEIPT_LIMIT}
    if result["evidence_bounded"]:
        return result
    required, consumed = [], {}
    try:
        for kind, raw in events:
            if kind not in {"manifest", "input"}:
                continue
            if len(raw) > 4096:
                raise ValueError("receipt bound")
            body = json.loads(raw)
            if kind == "manifest":
                pairs = body["required"]
                if not isinstance(pairs, list) or not 1 <= len(pairs) <= 32:
                    raise ValueError("manifest")
                for role, listing in pairs:
                    if role not in {"listing", "benchmark", "fx"} or not re.fullmatch(r"[A-Z0-9^][A-Z0-9.^:/_-]{0,47}", listing):
                        raise ValueError("pair")
                    required.append((role, listing))
            else:
                consumed[(body["role"], body["listing"])] = body
        if not required or len(required) > 10000 or len(set(required)) != len(required):
            return result
        available, statuses = 0, set()
        for pair in required:
            body = consumed.get(pair, {})
            rows = body.get("rows")
            present = type(rows) is int and 0 < rows <= 10**12
            available += int(present)
            freshness = "unknown"
            digest = body.get("source_sha256")
            if present and isinstance(digest, str) and re.fullmatch(r"[a-f0-9]{64}", digest) and body.get("required_session") and body.get("consumed_session"):
                req, obs = instant(body["required_session"]), instant(body["consumed_session"])
                if obs <= asof and req <= asof:
                    freshness = "complete" if obs == req else "stale" if obs < req else "unknown"
            statuses.add(freshness)
        result.update(inputs_requested=len(required), inputs_available=available,
                      coverage_status="complete" if available == len(required) else "partial",
                      freshness_status="stale" if "stale" in statuses else "unknown" if "unknown" in statuses else "complete")
    except (ValueError, TypeError, KeyError):
        pass
    return result


def maintenance(db, asof):
    row = db.execute("SELECT substr(body,1,4097) FROM registry_maintenance_stats WHERE singleton=1").fetchone()
    if not row or len(row[0]) > 4096:
        return None
    try:
        body = json.loads(row[0])
        at = instant(body["at"])
        if at > asof:
            return None
        result = {"at": at}
        days = body["retention_days"]
        if days is not None and (type(days) is not int or not 1 <= days <= 36500):
            return None
        for key in ("probed", "recovered", "pruned", "database_bytes", "used_bytes", "keep_latest", "max_database_bytes", "retention_days"):
            value = body.get(key)
            result[key] = value if type(value) is int and 0 <= value <= 10**12 else None
        result["over_soft_cap"] = body.get("over_soft_cap") if type(body.get("over_soft_cap")) is bool else None
        return result
    except (ValueError, TypeError, KeyError):
        return None


def read_page(path: str | Path, query: dict[str, Any]) -> dict[str, Any]:
    if os.environ.get("BORG_RESTATEMENT_DIR"):
        return unknown("blocked")
    try:
        size, page = query.get("size", 25), query.get("page", 1)
        if type(size) is not int or not 1 <= size <= 50 or type(page) is not int or not 1 <= page <= 10000:
            raise ValueError("pagination")
        asof = instant(query.get("asof") or datetime.now(timezone.utc).isoformat())
        if asof > datetime.now(timezone.utc).isoformat():
            raise ValueError("future cutoff")
        name, status = query.get("name", "all"), query.get("status", "all")
        if name not in NAMES | {"all"} or status not in {"all", "running", "ok", "degraded", "interrupted", "recovered", "unknown"}:
            raise ValueError("filter")
        conditions, args = ["started_at<=?"], [asof]
        if name != "all":
            conditions.append("name=?")
            args.append(name)
        if query.get("runId"):
            rid = identifier(query["runId"])
            if rid is None:
                raise ValueError("identifier")
            conditions.append("run_id=?")
            args.append(rid)
        for key, op in (("from", ">="), ("to", "<=")):
            if query.get(key):
                date = query[key]
                if not re.fullmatch(r"\d{4}-\d{2}-\d{2}", date):
                    raise ValueError("date")
                datetime.strptime(date, "%Y-%m-%d")
                conditions.append(f"substr(started_at,1,10){op}?")
                args.append(date)
        path = Path(path).resolve()
        if any(Path(str(path) + suffix).exists() for suffix in ("-wal", "-shm")):
            return unknown()
        deadline = time.monotonic() + 1.5
        # Rollback journal registry only: never immutable=1 on a changing file.
        with closing(sqlite3.connect(Path(path).resolve().as_uri() + "?mode=ro", uri=True, timeout=0.25)) as db:
            db.row_factory = sqlite3.Row
            db.execute("PRAGMA query_only=ON")
            db.set_progress_handler(lambda: int(time.monotonic() > deadline), 1000)
            db.execute("BEGIN")
            if db.execute("PRAGMA user_version").fetchone()[0] != 1:
                raise ValueError("schema")
            stamp = db.execute("SELECT count(*),coalesce(max(sequence),0),coalesce(sum(sequence),0) FROM receipts WHERE at<=?", (asof,)).fetchone()
            inventory = db.execute("SELECT count(*) FROM runs WHERE started_at<=?", (asof,)).fetchone()[0]
            snapshot = ":".join(str(x) for x in (*stamp, inventory))
            if query.get("snapshot") and query["snapshot"] != snapshot:
                return {**unknown("changed"), "error": "Registry snapshot changed or retained history was removed. Refresh the snapshot."}
            lifecycle = "CASE WHEN ended_at IS NOT NULL AND ended_at<=? THEN status ELSE CASE WHEN status IN ('running','ok','partial','failed','timeout','interrupted','recovered_orphan') THEN 'running' ELSE 'unknown' END END"
            sql = "WITH selected AS (SELECT run_id,parent_run_id,name,started_at," + lifecycle + " AS lifecycle FROM runs WHERE " + " AND ".join(conditions) + ") "
            params = [asof, *args]
            display = "CASE lifecycle WHEN 'partial' THEN 'degraded' WHEN 'failed' THEN 'degraded' WHEN 'timeout' THEN 'degraded' WHEN 'recovered_orphan' THEN 'recovered' WHEN 'running' THEN 'running' WHEN 'ok' THEN 'ok' WHEN 'interrupted' THEN 'interrupted' ELSE 'unknown' END"
            where = " WHERE " + display + "=?" if status != "all" else ""
            if where:
                params.append(status)
            matching = db.execute(sql + "SELECT count(*) FROM selected" + where, params).fetchone()[0]
            pages = max(1, (matching + size - 1) // size)
            page = min(page, pages)
            rows = db.execute(sql + "SELECT * FROM selected" + where + " ORDER BY started_at DESC,run_id ASC LIMIT ? OFFSET ?", [*params, size, (page - 1) * size]).fetchall()
            safe = []
            for row in rows:
                rid = identifier(row["run_id"])
                if rid is None:
                    raise ValueError("source identifier")
                state = row["lifecycle"] if row["lifecycle"] in STATES else "unknown"
                beat = db.execute("SELECT max(at) FROM receipts WHERE run_id=? AND at<=? AND kind IN ('start','heartbeat')", (rid, asof)).fetchone()[0]
                safe.append({"run_id": rid, "parent_run_id": identifier(row["parent_run_id"]),
                             "name": row["name"] if row["name"] in NAMES else "unknown", "started_at": instant(row["started_at"]),
                             "heartbeat_at": instant(beat) if beat else None, "status": state,
                             "display_status": DISPLAY.get(state, state), "owner_status": "unknown",
                             "recovery_cause": "unknown", **projection(db, rid, asof)})
            return {"status": "ready", "rows": safe, "matching": matching, "pages": pages, "page": page,
                    "asof": asof, "snapshot": snapshot, "maintenance": maintenance(db, asof)}
    except (OSError, sqlite3.Error, ValueError, TypeError, KeyError, OverflowError):
        return unknown()


def main():
    try:
        payload = json.loads(sys.stdin.read(8193))
        result = read_page(Path(payload["path"]), payload["query"])
    except (ValueError, TypeError, KeyError):
        result = unknown()
    print(json.dumps(result, separators=(",", ":"), allow_nan=False))


if __name__ == "__main__":
    main()
