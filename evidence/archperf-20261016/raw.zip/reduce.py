from pathlib import Path
import json,statistics,hashlib
P=Path(__file__).parent
rounds=[json.loads((P/f'round-{i}/receipt.json').read_text()) for i in range(1,6)]
result={'round_count':len(rounds),'rounds':rounds,'paired_http':{},'stream':{},'browser':{},'profiler':{}}
for name in ['small','scale']:
 rows=json.loads((P/f'round-5/{name}-paired-http.json').read_text())
 for route in sorted({r['route'] for r in rows}):
  vals={lane:statistics.median(r['total_ms'] for r in rows if r['lane']==lane and r['route']==route and r['repetition']>0) for lane in ['baseline','candidate']}
  digests={lane:sorted({r['body_sha256'] for r in rows if r['lane']==lane and r['route']==route}) for lane in vals}
  result['paired_http'][name+route]={**vals,'reduction_percent':100*(1-vals['candidate']/vals['baseline']),'warm_n_per_lane':6,'bytes':sorted({r['bytes'] for r in rows if r['route']==route}),'exact_body_parity':digests['baseline']==digests['candidate']}
 for i in range(1,6):
  obj=json.loads((P/f'round-{i}/{name}-browser.json').read_text());rows=obj['samples']
  result['browser'][f'{i}-{name}']={'first_responseStart':rows[0]['responseStart'],'warm_median_responseStart':statistics.median(r['responseStart'] for r in rows[1:]),'warm_median_DCL':statistics.median(r['domContentLoaded'] for r in rows[1:]),'warm_median_load':statistics.median(r['load'] for r in rows[1:]),'pageerrors':len(obj['errors']),'aborted_requests':len(obj['failed']),'rendered_rows':sorted({r['renderedRows'] for r in rows}),'streamHttp':obj.get('streamHttp')}
obj=json.loads((P/'stream-benchmark.json').read_text())
for lane in ['baseline','candidate']:
 rows=[r for r in obj['samples'] if r['lane']==lane]
 result['stream'][lane]={'retained':sorted({r['retained_before_publication'] for r in rows}),'warm_broadcast_median_ms':statistics.median(r['broadcast_ms'] for r in rows[1:]),'warm_cancel_1000_median_ms':statistics.median(r['cancel_ms'] for r in rows[1:])}
obj=json.loads((P/'backend-profiler/replay/receipt.json').read_text())
result['profiler']={k:obj[k] for k in ['exact_economic_parity','missing_fx_refused','sdk_calls_avoided','network_requests','fixture_kind']}
result['profiler']['lanes']={k:v['samples'] for k,v in obj['lanes'].items()}
result['observability_samples']=sum(len(json.loads((P/f'round-{i}/spans.json').read_text())) for i in range(1,6))
(P/'summary.json').write_text(json.dumps(result,indent=2))
print(json.dumps({k:v for k,v in result.items() if k not in ['rounds','browser']},indent=2))
