from pathlib import Path
import sys,os,subprocess,json,logging
ROOT=Path('D:/Projets/BorgInvestor');OUT=Path(__file__).parent
sys.path.insert(0,str(ROOT));sys.path.insert(0,str(ROOT/'tests'))
lane=OUT/'backend-profiler';lane.mkdir(exist_ok=False)
base=lane/'data_engine_9406006.py'
base.write_bytes(subprocess.check_output(['git','show','940600638b1aeea1bf1a6098063865e6cabf90ed:simulator/Database/data_engine.py'],cwd=ROOT))
os.environ.update(BORG_TEST_REPO_ROOT=str(ROOT),BORG_TEST_GUARD_RECEIPT=str(lane/'guard.jsonl'),PYTHON_DOTENV_DISABLED='1',NUMBA_CACHE_DIR=str(lane/'numba'),BORG_STATE_DIR=str(lane/'state'),BORG_LOGS_DIR=str(lane/'logs'),BORG_TELEMETRY_DIR=str(lane/'telemetry'),BORG_QUOTE_CACHE_DIR=str(lane/'quotes'))
for key in tuple(os.environ):
 if key.startswith(('BORG_RUN_','BORG_OPERATIONAL_ALERT')):os.environ.pop(key)
from production_guard import install
install()
from scripts.profile_incremental_refresh import compare_offline
rows=[]
class Handler(logging.Handler):
 def emit(self,record):
  if record.msg=='operation.end':rows.append({k:record.__dict__[k] for k in ['operation','run_id','span_id','parent_span_id','duration_ms','status','coverage_status','freshness_status'] if k in record.__dict__})
logger=logging.getLogger('simulator.observability');logger.addHandler(Handler());logger.setLevel(logging.INFO)
result=compare_offline(base,lane/'replay')
(lane/'spans.json').write_text(json.dumps(rows,indent=2))
print(json.dumps({'receipt':str(lane/'replay/receipt.json'),'parity':result['exact_economic_parity'],'missing_fx_refused':result['missing_fx_refused'],'sdk_calls_avoided':result['sdk_calls_avoided'],'spans':len(rows),'guard_attempts':len((lane/'guard.jsonl').read_text().splitlines()) if (lane/'guard.jsonl').exists() else 0},indent=2))
assert result['exact_economic_parity'] and result['missing_fx_refused']
