from pathlib import Path
import json,sys,hashlib,statistics,subprocess,zipfile,shutil,os
from xml.etree import ElementTree
ROOT=Path('D:/Projets/BorgInvestor');OUT=Path(__file__).parent
DEST=ROOT/'reports/evidence/archperf-20261016'
if DEST.exists():raise RuntimeError('exclusive evidence export required')
sys.path.insert(0,str(ROOT))
from scripts.verify_state_alert_refresh_integration import sources,protected,differences,digest
summary=json.loads((OUT/'summary.json').read_text());aggregate=json.loads((OUT/'final-aggregate/receipt.json').read_text())
current_sources=sources();expected_sources=json.loads((OUT/'final-aggregate/sources-after.json').read_text())
assert current_sources==expected_sources, differences(expected_sources,current_sources)
current_protected=protected();initial=json.loads((OUT/'initial-protected.json').read_text());final_protected=json.loads((OUT/'final-aggregate/protected-after.json').read_text())
initial_diff=differences(initial,current_protected);final_diff=differences(final_protected,current_protected)
rounds=summary['rounds'];assert len(rounds)==5 and [r['round'] for r in rounds]==[1,2,3,4,5]
assert all(r['all_parity'] and r['fixture_preserved'] and not r['source_changed'] for r in rounds)
copy_diff=[]
for folder in ['app','components','lib']:
 for src in (ROOT/'dashboard'/folder).rglob('*'):
  if src.is_file():
   copy=OUT/'dashboard'/src.relative_to(ROOT/'dashboard')
   if not copy.exists() or digest(copy)!=digest(src):copy_diff.append(str(src))
assert not copy_diff
python_versions=json.loads(subprocess.check_output([str(ROOT/'.venv/Scripts/python.exe'),'-c',"import sys,sqlite3,importlib.metadata,json;print(json.dumps({'python':sys.version.split()[0],'sqlite':sqlite3.sqlite_version,'packages':{n:importlib.metadata.version(n) for n in ['polars','pandas','duckdb','yfinance','pytest']}}))"],text=True))
node_versions=json.loads(subprocess.check_output(['node','-e',"console.log(JSON.stringify({node:process.version,next:require('./dashboard/node_modules/next/package.json').version,react:require('./dashboard/node_modules/react/package.json').version,typescript:require('./dashboard/node_modules/typescript/package.json').version,playwright:require('./dashboard/node_modules/@playwright/test/package.json').version}))"],cwd=ROOT,text=True))
versions={**python_versions,**node_versions}
(OUT/'versions.json').write_text(json.dumps(versions,indent=2))
fixture_hashes=json.loads((OUT/'fixtures.json').read_text())
common={'repository':'BorgInvestor','evidence_root':'reports/evidence/archperf-20261016','raw_archive':'reports/evidence/archperf-20261016/raw.zip','measured_versions':versions,'source_revision_context':subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),'source_context':'dirty feature branch; working bytes, not a new commit','applicability':'Windows local Next production server with isolated Python SQLite reader; synthetic bounded fixtures; not live-health certification'}
candidates=[
 {**common,'id':'python-sqlite-suppress-non-evidence-receipt-bodies','technology':'Python/SQLite','promotion_status':'READY_CONFIRMED_SCOPED','root_cause_status':'PROVEN','root_cause':'SQL materialized substr(body,1,4097) for heartbeat/lifecycle receipts discarded by Python; real SQLite substr observer reproduced 21 unnecessary evaluations before fix.','remediation_actual':"CASE WHEN kind IN ('manifest','input') THEN substr(body,1,4097) END; keep all row kinds, order and 513th-receipt overflow detection",'source_sha256':{'baseline':digest(OUT/'baseline/read_registry_dashboard.py'),'candidate':digest(ROOT/'scripts/read_registry_dashboard.py'),'regression':digest(ROOT/'tests/test_registry_operator_reader.py')},'measurements':{'paired_production_http':summary['paired_http'],'round_5_direct_reader':rounds[-1]['backend'],'fixture_manifest':fixture_hashes},'evidence_members':['round-2-red.log','round-2-green.log','round-5/small-paired-http.json','round-5/scale-paired-http.json','round-5/parity.json','final-aggregate/receipt.json'],'regressions':['SQL/Python materialization boundary','513 heartbeat overflow remains Unknown','malformed/oversized/missing/frozen/WAL refusal','24 old/new filter/page cases per round','paired complete API and HTML bytes equal'],'caveats':['No meaningful small-store latency gain; small paired API +3.36%, document +1.47%','Scale contains padded synthetic heartbeat bodies; not measured live distribution','Read/hash/fingerprint/filtered counts and other SQL still linear; no O(1) claim','Six warm samples not tail latency; first samples retained']},
 {**common,'id':'node-readable-stream-owned-controller-cancellation','technology':'JavaScript/Node.js/Web Streams/Next.js','promotion_status':'READY_CONFIRMED_SCOPED','root_cause_status':'PROVEN','root_cause':'UnderlyingSource.cancel argument is cancellation reason, not controller; deleting it retained closed subscriber controllers until the next publication sweep. POST-count-only test hid the leak.','remediation_actual':'Capture owning controller in GET closure; remove it in cancel and clear owned reference; preserve surviving streams and exact event text.','source_sha256':{'baseline':digest(OUT/'baseline/stream-route.ts'),'candidate':digest(ROOT/'dashboard/app/api/stream/route.ts'),'regression':digest(ROOT/'dashboard/tests/stream-lifecycle.spec.ts')},'measurements':summary['stream'],'evidence_members':['round-3-insufficient-first-test.log','round-3-red.log','round-3-green.log','stream-benchmark.json','round-4/small-browser.json','round-5/scale-browser.json','build-after.log','final-stream.log'],'regressions':['Cancellation deletes real owned controller before compensating POST','50 open/cancel and latest message parity','real production HTTP SSE marker/event/disconnect','fresh production build/type/lint'],'caveats':['1000 synthetic direct-source connections in VM with observed Set; not browser RSS or OS memory measurement','Cancellation median 4.600 to 4.897 ms/1000; cleanup trade-off','Next POST dead-controller cleanup masked pre-fix retention; zero post-publication subscribers alone is insufficient']},
 {**common,'id':'next-independent-readers-concurrency-opportunity','technology':'Next.js/Node.js','promotion_status':'HYPOTHESIS_NOT_PROVEN','root_cause_status':'SOURCE_PROVEN_COST_HYPOTHESIS','root_cause':'operations page sequentially awaits independent registry and alert readers; small endpoint costs exceed in-process SQL cost. Causal savings and capacity effects not measured.','remediation_actual':'NONE; deferred. Require cancellation/capacity regressions and paired concurrent-vs-sequential campaign before implementation.','evidence_members':['round-5/http.json','round-5/small-paired-http.json'],'caveats':['Do not propose a persistent Python daemon to save startup without ownership/isolation trade-off evidence','No predicted numeric speedup certified']},
 {**common,'id':'market-refresh-request-avoidance-requires-lineage','technology':'Python/yfinance/Polars/DuckDB','promotion_status':'READY_LIMITATION_NOT_OPTIMIZATION','root_cause_status':'PROVEN_LIMITATION','root_cause':'Existing processed cache lacks executable listing/calendar/adjustment/retrieval/FX provenance adapter; complete rows and timestamps cannot authorize skipping.','remediation_actual':'No activation. Preserve conservative refusal and legacy default. Existing full-caller profiler independently reexecuted.','measurements':summary['profiler'],'evidence_members':['backend-profiler/replay/receipt.json','backend-profiler/spans.json','backend-profiler/guard.jsonl'],'caveats':['6 to 6 SDK attempts; zero avoided calls and zero outbound requests','650 synthetic rows exact parity is not annual warmup, financial certification, or public latency','First legacy sample includes JIT; shared helpers current; candidate later samples slightly slower']}
]
DEST.mkdir(parents=True)
(DEST/'optimization-candidates.json').write_text(json.dumps({'schema':'optimization-candidates-v1','sorted_by':'technology','registry_write_performed':False,'candidates':sorted(candidates,key=lambda r:(r['technology'],r['id']))},indent=2),encoding='utf8')
(DEST/'summary.json').write_bytes((OUT/'summary.json').read_bytes())
# Archive bounded raw evidence and exact executed sources, never dependencies or live state.
selected={}
for p in OUT.iterdir():
 if p.is_file() and p.suffix in {'.py','.cjs','.json','.log','.xml','.sqlite'}:selected[p.relative_to(OUT).as_posix()]=p
for folder in [*['round-'+str(i) for i in range(1,6)],'round-1-bootstrap-failed','round-1-predicate-failed','baseline','final-aggregate']:
 for p in (OUT/folder).iterdir():
  if p.is_file():selected[p.relative_to(OUT).as_posix()]=p
for p in (OUT/'backend-profiler').rglob('*'):
 if p.is_file() and not any(x in p.parts for x in ['numba','__pycache__']):selected[p.relative_to(OUT).as_posix()]=p
for folder in ['app','components','lib']:
 for p in (OUT/'dashboard'/folder).rglob('*'):
  if p.is_file():selected[p.relative_to(OUT).as_posix()]=p
for rel in ['scripts/read_registry_dashboard.py','tests/test_registry_operator_reader.py','dashboard/tests/stream-lifecycle.spec.ts','dashboard/playwright.archperf.config.ts','scripts/profile_incremental_refresh.py','scripts/profile_provider_phases.py','scripts/verify_state_alert_refresh_integration.py','simulator/run_registry.py','simulator/observability.py','simulator/Database/data_engine.py','simulator/Database/incremental_refresh.py','simulator/Relay/provider_phases.py','simulator/provider_resilience.py','simulator/provider_limits.py','simulator/Engine/volatility_engine.py','simulator/TradingPlatform/UNIMATRIX/numba_utils.py','simulator/cache_coordination.py','simulator/pathing.py','doc/ARCHITECTURE_PERFORMANCE_QLOOP_2026-10-16.md']:
 selected['current-source/'+rel]=ROOT/rel
member_hashes={k:digest(v) for k,v in selected.items()}
with zipfile.ZipFile(DEST/'raw.zip','w',compression=zipfile.ZIP_DEFLATED,compresslevel=7) as archive:
 for name,p in sorted(selected.items()):archive.write(p,name)
with zipfile.ZipFile(DEST/'raw.zip') as archive:
 assert archive.testzip() is None
 assert set(archive.namelist())==set(member_hashes)
 assert all(hashlib.sha256(archive.read(k)).hexdigest()==v for k,v in member_hashes.items())
node_gates=json.loads((OUT/'final-node-receipt.json').read_text())
tree=ElementTree.parse(OUT/'final-aggregate/junit.xml').getroot()
totals={key:sum(int(s.get(key,'0')) for s in tree.iter('testsuite')) for key in ['tests','errors','failures','skipped']}
assert totals==aggregate['junit_totals']
source_stable=sources()==current_sources
now=protected();changed_old=sorted(k for k,v in current_protected.items() if now.get(k)!=v);added=sorted(set(now)-set(current_protected))
receipt={'schema':'architecture-performance-five-qloop-acceptance-v1','round_count':len(rounds),'verdicts':{'architecture_correctness':'PASS_SCOPED' if aggregate['accepted'] and not any(g['returncode'] for g in node_gates.values()) and not copy_diff and source_stable else 'BLOCKED','performance':'PASS_SYNTHETIC_SCALE_ONLY_NO_CURRENT_SMALL_OR_NETWORK_GAIN','preservation':'PASS_CURRENT_CAMPAIGN' if not initial_diff and not final_diff and not changed_old else 'NOT_CERTIFIED','production_health':'UNKNOWN_NOT_CERTIFIED'},'aggregate_receipt_sha256':digest(OUT/'final-aggregate/receipt.json'),'aggregate_accepted':aggregate['accepted'],'full_suite_console':{'passed':2070,'skipped':2,'xfailed':8,'successful_subtests':47,'coverage_percent':62.34},'independently_parsed_junit':totals,'exact_process_guard_attempts':aggregate['guard_attempts'],'node_gates':node_gates,'source_doc_count':len(current_sources),'source_docs_stable_after_aggregate':source_stable,'dashboard_copy_mismatches':copy_diff,'initial_protected_files':len(initial),'initial_to_final_protected_differences':initial_diff,'post_aggregate_protected_differences':final_diff,'preexisting_protected_changes_during_export':changed_old,'intentional_evidence_additions':added,'qualified_span_samples':summary['observability_samples'],'provider_span_samples':len(json.loads((OUT/'backend-profiler/spans.json').read_text())),'measurement_versions':versions,'knowledge_candidates':'optimization-candidates.json','raw_archive':'raw.zip','limits':['No vault registry edits; parent integrates candidates','No broker/provider calls, live SQLite opens, production jobs/stops or commit/push','Initial failed harness attempts retained, not counted as extra rounds or qualified measurements','Synthetic fixtures and source-bound production-mode build are not installed production health','Final source/docs unchanged after frozen gates; evidence export is intentional new reports content']}
(DEST/'acceptance.json').write_text(json.dumps(receipt,indent=2),encoding='utf8')
manifest={'schema':'archperf-evidence-manifest-v1','files':{p.name:digest(p) for p in DEST.iterdir() if p.is_file()},'archive_members':member_hashes,'source_hashes':current_sources}
(DEST/'manifest.json').write_text(json.dumps(manifest,indent=2),encoding='utf8')
# Verify the final exact exported targets and freeze once more; no source writes.
loaded=json.loads((DEST/'acceptance.json').read_text());assert loaded==receipt
assert sources()==current_sources
assert all(digest(DEST/name)==value for name,value in manifest['files'].items())
print(json.dumps({'dest':str(DEST),'verdicts':receipt['verdicts'],'acceptance_sha256':digest(DEST/'acceptance.json'),'raw_zip_bytes':(DEST/'raw.zip').stat().st_size,'archive_members':len(member_hashes),'source_doc_count':len(current_sources),'initial_protected_count':len(initial),'initial_differences':initial_diff,'knowledge_records':len(candidates)},indent=2))
