import { loadJson } from "@/lib/feeds";
import type { EtfAllocationFeed } from "@/lib/feeds";
import RuntimePerformance from "@/components/RuntimePerformance";
import { PageHeader } from "@/components/ui-patterns";

export const revalidate = 60;

export default async function PerformancePage() {
  const feed = await loadJson<EtfAllocationFeed>("etf_allocation.json");
  return (
    <main className="px-4 py-6 md:px-8 md:py-8">
      <PageHeader
        title="Performance Observatory"
        subtitle="Backend data-generation telemetry plus browser-side navigation and rendering metrics."
      />
      <RuntimePerformance backend={feed?.performance ?? null} generatedAt={feed?.generated_at} />
    </main>
  );
}
