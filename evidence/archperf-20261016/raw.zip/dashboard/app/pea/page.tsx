import fs from "node:fs/promises";
import path from "node:path";
import PeaEquityChart from "@/components/PeaEquityChart";
import { PageHeader } from "@/components/ui-patterns";

export const revalidate = 300;

interface BacktestRow {
  date: string;
  bh: number; cto: number; pea: number;
  bh_net?: number; cto_net?: number; pea_net?: number;
}

const INITIAL = 10_000;
const MONTHLY = 1_000;

async function loadBacktest(): Promise<BacktestRow[]> {
  try {
    const p = path.join(process.cwd(), "..", "reports", "borg_telemetry", "pea_backtest.jsonl");
    const txt = await fs.readFile(p, "utf8");
    return txt.trim().split("\n").map((l) => {
      try { return JSON.parse(l) as BacktestRow; } catch { return null; }
    }).filter(Boolean) as BacktestRow[];
  } catch {
    return [];
  }
}

export default async function PeaPage() {
  const rows = await loadBacktest();
  const step = Math.max(1, Math.floor(rows.length / 300));
  const chartData = rows.filter((_, i) => i % step === 0 || i === rows.length - 1);
  const months = rows.length > 0 ? new Set(rows.map((r) => r.date.slice(0, 7))).size : 0;
  const deposited = INITIAL + Math.max(0, months - 1) * MONTHLY;

  return (
    <main className="px-4 py-6 md:px-8 md:py-8">
      <PageHeader
        title="PEA vs CTO vs Buy & Hold"
        subtitle={`5-year backtest · €${INITIAL.toLocaleString("fr-FR")} + €${MONTHLY.toLocaleString("fr-FR")}/mo DCA · net after exit tax at terminal date`}
      />
      {rows.length === 0 ? (
        <p style={{ color: "var(--text-muted)" }}>
          No backtest data yet. Run{" "}
          <code className="font-mono">uv run python -m simulator.Benchmark.pea_backtest</code>
        </p>
      ) : (
        <PeaEquityChart data={chartData} initialDeposited={deposited} />
      )}
    </main>
  );
}
