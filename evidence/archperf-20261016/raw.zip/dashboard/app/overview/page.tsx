/**
 * Overview cockpit tab (REQ-2 / REQ-8) — server shell.
 * Reads blended + per-strategy KPIs and shadow positions server-side, renders the
 * headline cockpit: blended P&L, per-strategy contribution, capital deployed vs idle,
 * signal pressure, the combined equity curve, and per-strategy KPI cards.
 *
 * Render-only: all math already happened in tested Python (kpis.json, 19-02).
 * Static kpis.json is primary; the page never blocks on the FastAPI shim.
 * Null/partial feeds degrade gracefully (T-19-09 / T-19-13 / T-19-15).
 */
import { loadJson, type KpiFeed, type EtfAllocationFeed } from "@/lib/feeds";
import { RUNTIME_STRATEGY_ORDER } from "@/lib/strategies";
import EtfStrategyMethodology from "@/components/EtfStrategyMethodology";
import OverviewCards from "@/components/OverviewCards";
import OverviewEquityCurve from "@/components/OverviewEquityCurve";
import PerformanceEvidence from "@/components/PerformanceEvidence";
import StrategyKpiBar from "@/components/StrategyKpiBar";
import { PageHeader } from "@/components/ui-patterns";
import type { EquityFeed } from "@/lib/feeds";
import Link from "next/link";
import SectionNavigation from "@/components/SectionNavigation";
import styles from './overview.module.css';

export const revalidate = 30;

const STRATEGIES = RUNTIME_STRATEGY_ORDER;

function trimEquityFeed(feed: EquityFeed | null, targetPoints = 300): EquityFeed | null {
  if (!feed || feed.rows.length <= targetPoints) return feed;
  const step = Math.max(1, Math.floor(feed.rows.length / targetPoints));
  return {
    ...feed,
    rows: feed.rows.filter((_, index) => index % step === 0 || index === feed.rows.length - 1),
  };
}

export default async function OverviewPage() {
  const [kpis, rawEquity, etf] = await Promise.all([
    loadJson<KpiFeed>("kpis.json"),
    loadJson<EquityFeed>("equity.json"),
    loadJson<EtfAllocationFeed>("etf_allocation.json"),
  ]);
  const equity = trimEquityFeed(rawEquity);

  return (
    <main className={`${styles.page} px-4 py-6 md:px-8 md:py-8 max-w-[1280px] mx-auto`}>
      <PageHeader
        title="Overview"
        subtitle="Read the evidence first, then inspect the portfolio snapshot."
      />

      <section aria-labelledby="cockpit-reading-heading" className="mb-8 rounded-[6px] p-6" style={{background:"var(--surface-raised)",border:"1px solid var(--border-default)"}}>
        <div className={styles.readingHeader}>
          <h2 id="cockpit-reading-heading" className="text-lg font-semibold">Reading this cockpit</h2>
          <Link href="/operations" prefetch={false} className="text-sm underline underline-offset-4" style={{color:"var(--borg-accent)"}}>Inspect operational evidence</Link>
        </div>
        <dl className={styles.readingGrid}>
          <div><dt className="font-semibold">Snapshot availability</dt><dd className="mt-2" style={{color:"var(--text-secondary)"}}>{kpis ? 'KPI input loaded. Presence does not certify freshness or accounting.' : 'KPI input unavailable. Values remain unknown, not zero.'}</dd></div>
          <div><dt className="font-semibold">Decision gate</dt><dd className="mt-2" style={{color:"var(--text-secondary)"}}>Comparison and promotion require independent evidence. See the methodology and accounting boundaries below.</dd></div>
          <div><dt className="font-semibold">Next check</dt><dd className="mt-2" style={{color:"var(--text-secondary)"}}>Inspect lifecycle receipts and alert history in Run Registry. Neither certifies strategy health.</dd></div>
        </dl>
      </section>

      <SectionNavigation label="Overview sections" items={[
        {href:'#overview-snapshot',label:'Snapshot'},
        {href:'#overview-evidence',label:'Performance evidence'},
        {href:'#overview-curve',label:'Equity curve'},
        {href:'#overview-strategies',label:'Strategy KPIs'},
      ]}/>
      <div id="overview-snapshot" tabIndex={-1} className="scroll-mt-8"><OverviewCards kpis={kpis} /></div>

      <div id="overview-evidence" tabIndex={-1} className="scroll-mt-8"><PerformanceEvidence kpis={kpis} equity={equity} /></div>

      <div id="overview-curve" tabIndex={-1} className="scroll-mt-8"><OverviewEquityCurve equityCurve={kpis?.equity_curve} /></div>
      <EtfStrategyMethodology feed={etf} />

      <section id="overview-strategies" tabIndex={-1} className="mb-8 scroll-mt-8">
        <h2
          className="text-sm font-semibold mb-3 uppercase tracking-wide"
          style={{ color: "var(--text-secondary)" }}
        >
          Per-Strategy KPIs
        </h2>
        <div className={styles.strategies}>
          {STRATEGIES.map((s) => (
            <StrategyKpiBar key={s} strategy={s} kpi={kpis?.per_strategy?.[s] ?? null} />
          ))}
        </div>
      </section>
    </main>
  );
}
