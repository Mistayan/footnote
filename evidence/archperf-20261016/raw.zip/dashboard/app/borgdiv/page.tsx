/**
 * BorgDiv cockpit tab — server shell (Wave 2, 19-05).
 * Reads price history + dividends + shadow positions; renders the event-annotated
 * StrategyChart (price line + ex-div ReferenceLines) above the strategy-filtered
 * StrategyHoldingsTable. Graceful on null feeds (T-19-11).
 */
import {
  loadJson,
  type PriceHistory,
  type DividendFeed,
  type ForwardDividendFeed,
  type KpiFeed,
  type TradesFeed,
  type ShadowPayload,
} from "@/lib/feeds";
import BorgDivPriceEvents from "@/components/BorgDivPriceEvents";
import StrategyHoldingsTable from "@/components/StrategyHoldingsTable";
import StrategyKpiBar from "@/components/StrategyKpiBar";
import DividendCalendar from "@/components/DividendCalendar";
import { PageHeader } from "@/components/ui-patterns";
import BorgDivAttribution from "@/components/BorgDivAttribution";
import { loadBorgDivAttribution } from "@/lib/borgdivAttributionLoader";

export const revalidate = 30;

const STRATEGY = "borgdiv";

export default async function BorgDivPage() {
  const attribution = await loadBorgDivAttribution();
  const [prices, dividends, forwardCandidates, tradesFeed, shadow, kpis] = await Promise.all([
    loadJson<PriceHistory>("price_history.json"),
    loadJson<DividendFeed>("dividends.json"),
    loadJson<ForwardDividendFeed>("borgdiv_forward_candidates.json"),
    loadJson<TradesFeed>("trades.json"),
    loadJson<ShadowPayload>("shadow_positions.json"),
    loadJson<KpiFeed>("kpis.json"),
  ]);

  const positions = shadow?.positions ?? [];
  const strategyPositions = positions.filter((p) => p.strategy === STRATEGY);


  return (
    <main className="px-4 py-6 md:px-8 md:py-8">
      <PageHeader title="BorgDiv" subtitle="Variant Q pre-ex run-up — price, candidate calendar estimates, holdings; paid income unknown." />

      <StrategyKpiBar strategy={STRATEGY} kpi={kpis?.per_strategy?.[STRATEGY] ?? null} />

      <BorgDivAttribution model={attribution} />

      <section className="mb-8">
        <h2
          className="text-sm font-semibold mb-3 uppercase tracking-wide"
          style={{ color: "var(--text-secondary)" }}
        >
          Price &amp; Events
        </h2>
        {/* Selected listing only; global ranked candidates remain separate below. */}
        <BorgDivPriceEvents prices={prices} events={tradesFeed?.by_strategy?.[STRATEGY] ?? []} dividends={dividends} preferredTickers={strategyPositions.map(p=>p.ticker)} />
      </section>

      <section className="mb-8">
        <h2
          className="text-sm font-semibold mb-3 uppercase tracking-wide"
          style={{ color: "var(--text-secondary)" }}
        >
          Forward Candidate Calendar (14d; estimates, not income)
        </h2>
        <DividendCalendar feed={forwardCandidates} />
      </section>

      <section>
        <h2
          className="text-sm font-semibold mb-3 uppercase tracking-wide"
          style={{ color: "var(--text-secondary)" }}
        >
          Open Holdings
        </h2>
        <StrategyHoldingsTable strategy={STRATEGY} positions={positions} />
      </section>
    </main>
  );
}
