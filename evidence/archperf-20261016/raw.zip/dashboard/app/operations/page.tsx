import { Activity, ShieldCheck, Database, AlertTriangle } from 'lucide-react';
import { loadRegistryPage } from '@/lib/registryLoader';
import { parseRegistryQuery, registryHref, REGISTRY_NAMES, REGISTRY_STATES, type RegistryQuery, type RegistryResult } from '@/lib/registryQuery';
import styles from './registry.module.css';
import { loadOperationalAlerts } from '@/lib/operationalAlertsLoader';
import { OperationalAlertView } from './OperationalAlertView';
import SectionNavigation from '@/components/SectionNavigation';
export const dynamic='force-dynamic';
export const runtime='nodejs';
const shown=(value:string|number|null|undefined)=>value??'unknown';
export default async function OperationsPage({searchParams}:{searchParams:Promise<Record<string,string|string[]|undefined>>}) {
  const params=new URLSearchParams();for(const [key,value] of Object.entries(await searchParams))if(typeof value==='string')params.set(key,value);
  let query:RegistryQuery,result:RegistryResult;
  try {query=parseRegistryQuery(params);result=await loadRegistryPage(query);}
  catch {query=parseRegistryQuery(new URLSearchParams());result={status:'invalid',query,rows:[],matching:null,pages:null,maintenance:null,error:'Invalid filters. Use valid UTC dates, a canonical run UUID and positive page size.'};}
  const pinned={...query,asof:result.asof??query.asof,snapshot:result.snapshot??query.snapshot,page:result.page??query.page};
  const maintenance=result.maintenance;
  const alerts=await loadOperationalAlerts();
  return <main className={styles.page}>
    <header className={styles.header}><div><p className={styles.eyebrow}><Activity size={16} aria-hidden="true"/> OPERATIONS · READ ONLY</p><h1>Run registry</h1><p>Durable lifecycle receipts, not strategy health or financial certification.</p></div><a href={registryHref(query,{asof:undefined,snapshot:undefined,page:1})} className={styles.primary} title="Keep filters, request a new cutoff and return to page 1">Refresh snapshot</a></header>
    <SectionNavigation label="Operations sections" items={[
      {href:'#registry-filters',label:'Filter runs'},
      {href:'#registry-results',label:'Registry results'},
      {href:'#operations-history',label:'Alert history'},
    ]}/>
    <section className={styles.summary} aria-label="Operational boundaries">
      <div className={styles.panel}><h2><Database size={20} aria-hidden="true"/> Registry snapshot</h2><strong>{result.status==='ready'?`${result.matching} matching runs`:'Counts unknown'}</strong><p>As of <time>{result.asof??query.asof}</time></p><p>Each request reads one coherent transaction. Paging retains the cutoff and detects removed history.</p></div>
      <div className={styles.panel}><h2><AlertTriangle size={20} aria-hidden="true"/> Recovery & retention</h2><strong>{maintenance?.over_soft_cap===true?'Retention pressure':maintenance?.over_soft_cap===false?'Below soft cap':'Pressure unknown'}</strong><p>Last maintenance: <time>{shown(maintenance?.at)}</time></p><p>Recovered {shown(maintenance?.recovered)} · Pruned {shown(maintenance?.pruned)}</p><p>Allocated {shown(maintenance?.database_bytes)} bytes / cap {shown(maintenance?.max_database_bytes)} bytes</p><p>{maintenance?maintenance.retention_days===null?'Deletion disabled':`Retention ${maintenance.retention_days} days · Keep latest ${shown(maintenance.keep_latest)}`:'Retention policy unknown'}</p></div>
      <div className={styles.panel}><h2><ShieldCheck size={20} aria-hidden="true"/> Evidence boundaries</h2><strong>Accounting & promotion: unknown</strong><p>Coverage measures declared inputs consumed. Freshness requires explicit completed-session evidence.</p><p>Running is a receipt state, not proof of a live owner. Recovery cause remains unknown. This view never probes, recovers, prunes or ranks investments.</p></div>
    </section>
    <div id="operations-history" tabIndex={-1} className="scroll-mt-8"><OperationalAlertView result={alerts} refreshHref={`${registryHref(pinned,{})}#operational-alerts-heading`}/></div>
    <form id="registry-filters" tabIndex={-1} key={JSON.stringify(query)} action="/operations" method="get" className={`${styles.filters} scroll-mt-8`} aria-label="Filter registry runs">
      <label>Lifecycle<select name="status" defaultValue={query.status}>{REGISTRY_STATES.map(s=><option key={s} value={s}>{s==='all'?'All lifecycle states':s}</option>)}</select></label>
      <label>Invocation<select name="name" defaultValue={query.name}>{REGISTRY_NAMES.map(n=><option key={n} value={n}>{n==='all'?'All invocations':n}</option>)}</select></label>
      <label>Started from (UTC)<input name="from" type="date" defaultValue={query.from}/></label>
      <label>Started through (UTC)<input name="to" type="date" defaultValue={query.to}/></label>
      <label>Run UUID<input name="runId" defaultValue={query.runId} maxLength={36} placeholder="Optional exact run ID"/></label>
      <label>Page size<select name="size" defaultValue={query.size}>{[10,25,50].map(n=><option value={n} key={n}>{n} runs</option>)}</select></label>
      <label className={styles.cutoff}>As-of cutoff (aware ISO timestamp)<input name="asof" defaultValue={pinned.asof} maxLength={40}/></label>
      {pinned.snapshot&&<input type="hidden" name="snapshot" value={pinned.snapshot}/>}
      <button type="submit" className={styles.secondary}>Apply filters</button><a href="/operations" className={styles.secondary}>Clear filters</a>
    </form>
    <div id="registry-results" tabIndex={-1} className="scroll-mt-8">
    {result.status!=='ready'?<section className={styles.notice} role="status"><h2>{result.status==='blocked'?'Frozen lane blocked':result.status==='changed'?'Snapshot changed':result.status==='invalid'?'Invalid filters':'Registry unavailable'}</h2><p>{result.error}</p><p>Counts unknown. This is not evidence of an empty registry.</p><a className={styles.secondary} href="/operations">Retry registry</a></section>:<section aria-labelledby="runs-heading">
      <div className={styles.listHeader}><h2 id="runs-heading">Lifecycle receipts</h2><p>{result.rows.length} displayed of {result.matching} matching · newest starts first</p></div>
      {result.rows.length===0?<div className={styles.notice}><h3>No matching runs</h3><p>The registry was read successfully. No retained runs match these filters and cutoff; this does not prove no historical activity.</p><a href="/operations" className={styles.secondary}>Reset view</a></div>:<ul className={styles.runs}>{result.rows.map(row=><li key={row.run_id} className={styles.run}>
        <div className={styles.runHeader}><h3>{row.name}</h3><span className={styles.badge} data-state={row.display_status}>{row.display_status} {row.display_status==='degraded'?`(${row.status})`:''}</span></div>
        <a href={registryHref(pinned,{runId:row.run_id,page:1})} className={styles.identifier}>{row.run_id}</a>
        <p>Started <time>{row.started_at}</time> · Heartbeat <time>{shown(row.heartbeat_at)}</time></p>
        {row.parent_run_id&&<p>Parent <a href={registryHref(pinned,{runId:row.parent_run_id,name:'all',status:'all',from:undefined,to:undefined,page:1})} className={styles.identifier}>{row.parent_run_id}</a></p>}
        <dl className={styles.evidence}><div><dt>Owner health</dt><dd>{row.owner_status}</dd></div><div><dt>Coverage</dt><dd>{row.coverage_status}{row.inputs_requested!==null?` · ${row.inputs_available}/${row.inputs_requested}`:''}</dd></div><div><dt>Input freshness</dt><dd>{row.freshness_status}</dd></div><div><dt>Accounting</dt><dd>{row.accounting_status}</dd></div><div><dt>Promotion</dt><dd>{row.promotion_status}</dd></div></dl>
        {row.display_status==='recovered'&&<p>Orphan recovery recorded · cause {row.recovery_cause}. No timeout or crash inferred.</p>}
        {row.evidence_bounded&&<p>Receipt projection limit reached. Coverage and freshness withheld as unknown.</p>}
      </li>)}</ul>}
      <nav aria-label="Registry pagination" className={styles.pagination}>
        {(result.page??1)>1?<a href={registryHref(pinned,{page:(result.page??1)-1})} className={styles.secondary}>Previous page</a>:<span>First page</span>}
        <span>Page {result.page} of {result.pages}</span>
        {(result.page??1)<(result.pages??1)&&<a href={registryHref(pinned,{page:(result.page??1)+1})} className={styles.secondary}>Next page</a>}
      </nav>
    </section>}
    </div>
  </main>;
}
