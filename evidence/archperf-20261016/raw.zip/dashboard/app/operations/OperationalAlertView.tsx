import type {OperationalAlert, OperationalAlertsResult} from '@/lib/operationalAlertsLoader';
import styles from './registry.module.css';
function AlertTransition({row}:{row:OperationalAlert}){
  return <li className={styles.run}>
    <div className={styles.runHeader}><h3>{row.scope}</h3><span className={styles.badge} data-state={row.state}>{row.state}</span></div>
    <p><time dateTime={row.at}>{row.at}</time> · In-app · Severity: {row.severity??'unknown'} · Input coverage: {row.coverage_status??'unknown'}</p>
    {row.run_id&&<p>Run <a className={styles.identifier} href={`/operations?runId=${encodeURIComponent(row.run_id)}`}>{row.run_id}</a></p>}
    <p>{row.state==='recovered'?'Successful receipts persisted through recovery confirmation; accounting, promotion and input coverage remain independent.':row.state==='interrupted'?'Explicit interruption or orphan recovery persisted. Death cause remains unknown; no timeout or crash inferred.':'Explicit partial coverage, partial lifecycle, failed or timeout receipts persisted. This is an operational condition, not an investment recommendation.'}</p>
  </li>;
}
export function OperationalAlertView({result,refreshHref='/operations#operational-alerts-heading'}:{result:OperationalAlertsResult;refreshHref?:string}){
  const latest=result.status==='ready'?result.rows[0]:undefined;
  return <section aria-labelledby="operational-alerts-heading" className={styles.notice}>
    <div className={styles.alertHeader}><div><h2 id="operational-alerts-heading">Operational alerts</h2><p>Retained transitions · not current process health</p></div><a className={styles.secondary} href={refreshHref}>Refresh alert history</a></div>
    <p>In-app only · Lifecycle transitions, never trade signals or accounting health. No external notifications.</p>
    <details className={styles.disclosure}><summary>Alert policy & evidence limits</summary><p>Persistence 15 minutes · Cooldown 60 minutes · Recovery confirmation 1 minute by default. Operator configuration may override these thresholds. Running and missing coverage remain unknown, not proof of recovery. A retained transition is not an active incident count. Refresh reads history only; it does not evaluate or maintain alerts.</p></details>
    {result.status!=='ready'?<div role="status"><h3>{result.status==='blocked'?'Alert history blocked in frozen lane':'Alert history unknown'}</h3><p>{result.error}</p></div>:<>
      <p>Last evaluation: <time>{result.evaluated_at??'unknown'}</time>. History is bounded to the latest 50 retained transitions; this GET does not evaluate or maintain alerts.</p>
      {latest&&<p className={styles.latest}>Latest retained transition: <strong>{latest.scope} · {latest.state}</strong>. Inspect its receipt before taking action; current health remains unknown.</p>}
      {result.rows.length===0?<p>No retained alert transitions. This is not evidence of healthy processes or complete input coverage.</p>:<>
        <ul aria-label="Operational alert transitions" className={styles.runs}>{result.rows.slice(0,3).map((row,index)=><AlertTransition key={`${row.at}-${row.scope}-${index}`} row={row}/>)}</ul>
        {result.rows.length>3&&<details className={styles.disclosure}><summary>Show {result.rows.length-3} older retained transitions</summary><ul aria-label="Older operational alert transitions" className={styles.runs}>{result.rows.slice(3).map((row,index)=><AlertTransition key={`${row.at}-${row.scope}-${index}`} row={row}/>)}</ul></details>}
      </>}
    </>}
  </section>;
}
