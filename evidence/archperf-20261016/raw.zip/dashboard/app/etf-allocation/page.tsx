import { loadJson } from "@/lib/feeds";
import type { EtfAllocationFeed } from "@/lib/feeds";
import EtfAllocationChart from "@/components/EtfAllocationChart";
import EtfStrategyMethodology from "@/components/EtfStrategyMethodology";
import { PageHeader } from "@/components/ui-patterns";

export const revalidate = 300;

export default async function EtfAllocationPage() {
  const feed = await loadJson<EtfAllocationFeed>("etf_allocation.json");

  return (
    <main className="px-4 py-6 md:px-8 md:py-8">
      <PageHeader
        title="Set & Forget ETF Allocation"
        subtitle="Six-bucket monthly DCA research replay from the supplied €1,000 allocation."
      />
      <EtfStrategyMethodology feed={feed} />
      {feed ? (
        <EtfAllocationChart feed={feed} />
      ) : (
        <section
          className="rounded-[6px] p-6"
          style={{ background: "var(--surface-raised)", border: "1px solid var(--border-subtle)" }}
        >
          <p className="text-sm font-medium" style={{ color: "var(--text-primary)" }}>
            No ETF allocation feed yet
          </p>
          <p className="mt-2 text-sm" style={{ color: "var(--text-secondary)" }}>
            Run the reproducible backtest from the repository root to refresh this view.
          </p>
          <code
            className="mt-3 inline-block rounded-[3px] px-2 py-1 font-mono text-[13px]"
            style={{ background: "var(--surface-base)", color: "var(--text-primary)", border: "1px solid var(--border-subtle)" }}
          >
            uv run python -m simulator.main etf-allocation-backtest
          </code>
        </section>
      )}
    </main>
  );
}
