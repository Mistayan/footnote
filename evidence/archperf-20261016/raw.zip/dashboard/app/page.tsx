import Link from "next/link";
import { STRATEGY_REGISTRY } from "@/lib/strategies";
import { PageHeader } from "@/components/ui-patterns";

/** Source-backed navigation, not an invented live execution trace. */
export default function PlatformPage() {
  return <main className="px-4 py-6 md:px-8 md:py-8 max-w-7xl mx-auto space-y-8">
    <PageHeader title="BorgInvestor platform" subtitle="Strategy research, shadow diagnostics and investor evidence." />
    <section className="rounded p-4 bg-[var(--surface-raised)] space-y-3" aria-label="Evidence boundaries">
      <h2 className="text-base font-semibold">Evidence before action</h2>
      <p className="text-sm text-[var(--text-secondary)]">Dashboard files are observations, not broker confirmations. Freshness, accounting certification and promotion are separate gates. Unknown evidence remains unknown; normalized cross-strategy comparisons remain blocked until their gates pass.</p>
      <Link href="/overview" className="inline-flex min-h-12 items-center underline text-[var(--borg-accent)]">Open portfolio evidence</Link>
    </section>
    <section><h2 className="text-base font-semibold mb-4">Strategy roster</h2>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">{STRATEGY_REGISTRY.map(strategy=><article key={strategy.key} className="rounded p-4 bg-[var(--surface-raised)]">
        <h3 className="font-semibold">{strategy.label}</h3>
        <p className="text-sm mt-2 text-[var(--text-secondary)]">{strategy.href === "/etf-allocation" ? "Research replay only; excluded from runtime holdings, blended totals and journal activity." : "Shadow diagnostic evidence. Historical fills do not establish current-policy parity, paid income or promotion readiness."}</p>
        <Link prefetch={false} href={strategy.href} className="inline-flex min-h-12 items-center underline text-sm text-[var(--borg-accent)]">Open {strategy.label} evidence</Link>
      </article>)}</div>
    </section>
    <section className="space-y-3"><h2 className="text-base font-semibold">Observability boundaries</h2>
      <p className="text-sm text-[var(--text-secondary)]">No live execution trace is connected to this page. No broker handshake, feed refresh or trade is triggered here. Browser timing and historical producer telemetry are labelled separately.</p>
      <Link prefetch={false} href="/performance" className="inline-flex min-h-12 items-center underline text-[var(--borg-accent)]">Open performance observatory</Link>
    </section>
  </main>;
}
