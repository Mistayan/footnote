/**
 * BorgPEA cockpit tab — server shell (Wave 2, 19-05).
 * Reads price history + shadow positions; renders the event-annotated StrategyChart
 * (price line; no ex-div markers for PEA) above the strategy-filtered
 * StrategyHoldingsTable. Graceful on null feeds (T-19-11).
 */
import {
  loadJson,
  toStrategyTrades,
  type KpiFeed,
  type PriceHistory,
  type TradesFeed,
  type ShadowPayload,
  type ShadowPosition,
} from "@/lib/feeds";
import StrategyChart from "@/components/StrategyChart";
import StrategyHoldingsTable from "@/components/StrategyHoldingsTable";
import StrategyKpiBar from "@/components/StrategyKpiBar";
import { PageHeader } from "@/components/ui-patterns";

export const revalidate = 30;

const STRATEGY = "borgpea";

/**
 * Pick the close series for the strategy's held tickers. The chart draws one line;
 * we select the first held ticker that has price history (deterministic). Returns
 * an empty series when no held ticker has a cached price history -> empty-state.
 */
function selectSeries(
  prices: PriceHistory | null,
  positions: ShadowPosition[],
): { date: string; close: number }[] {
  if (!prices) return [];
  const held = positions.map((p) => p.ticker);
  for (const ticker of held) {
    const s = prices.series[ticker];
    if (s && s.length) return s;
  }
  const keys = Object.keys(prices.series);
  if (keys.length > 0) return prices.series[keys[0]];
  return [];
}

export default async function BorgPeaPage() {
  const [prices, tradesFeed, shadow, kpis] = await Promise.all([
    loadJson<PriceHistory>("price_history.json"),
    loadJson<TradesFeed>("trades.json"),
    loadJson<ShadowPayload>("shadow_positions.json"),
    loadJson<KpiFeed>("kpis.json"),
  ]);

  const positions = shadow?.positions ?? [];
  const strategyPositions = positions.filter((p) => p.strategy === STRATEGY);
  const ticker = strategyPositions.map(p => p.ticker).find(t => prices?.series[t]?.length) ?? Object.keys(prices?.series ?? {}).find(t => prices?.series[t]?.length) ?? "";
  const series = prices?.series[ticker] ?? [];
  // Real buy/sell markers from trades.json (entry/exit dates per strategy);
  // null-feed-safe → empty markers. (REQ-4 / AC#4)
  const trades = toStrategyTrades(tradesFeed?.by_strategy?.[STRATEGY]);

  return (
    <main className="px-4 py-6 md:px-8 md:py-8">
      <PageHeader title="BorgPEA" subtitle="PEA-eligible strategy — price, events, open holdings." />

      <StrategyKpiBar strategy={STRATEGY} kpi={kpis?.per_strategy?.[STRATEGY] ?? null} />

      <section className="mb-8">
        <h2
          className="text-sm font-semibold mb-3 uppercase tracking-wide"
          style={{ color: "var(--text-secondary)" }}
        >
          Price &amp; Events
        </h2>
        <p className="text-sm mb-3" style={{ color: "var(--text-secondary)" }}>Selected ticker: {ticker || "unknown"} · Other listings excluded. Close currency / FX provenance unknown; prices are not EUR execution fills. Exact-date events only; unmatched dates remain unplotted.</p>
        <StrategyChart series={series} trades={trades} selectedTicker={ticker} quoteCurrencyUnknown />
      </section>

      <section>
        <h2
          className="text-sm font-semibold mb-3 uppercase tracking-wide"
          style={{ color: "var(--text-secondary)" }}
        >
          Open Holdings
        </h2>
        <StrategyHoldingsTable strategy={STRATEGY} positions={positions} />
      </section>
    </main>
  );
}
