import fs from "node:fs/promises";
import path from "node:path";
import {
  type PanelSeries,
  type PanelRow,
} from "@/components/EquityPanel";
import { Suspense } from "react";
import StrategyPerformanceSelector from "@/components/StrategyPerformanceSelector";
import { loadJson, type EtfAllocationFeed } from "@/lib/feeds";

export const revalidate = 300;

/** equity.json schema (Plan 02 — dashboard/public/equity.json). */
type PanelKey = "pea" | "cto";

interface EquityFeed {
  generated_at: string;
  basis: { initial: number; monthly: number; currency: string };
  tax: { pea_pct: number; cto_pct: number };
  panels: Record<PanelKey, { title: string; tax_label: string; series: PanelSeries[] }>;
  rows: FeedRow[];
}

interface FeedRow {
  date: string;
  deposited: number;
  pea: Record<string, number>;
  cto: Record<string, number>;
  pea_net: Record<string, number>;
  cto_net: Record<string, number>;
}

const PANEL_ORDER: PanelKey[] = ["pea", "cto"];

/** Read + parse the feed; null on any failure (missing/malformed → empty state). */
async function loadFeed(): Promise<EquityFeed | null> {
  try {
    const p = path.join(process.cwd(), "public", "equity.json");
    const txt = await fs.readFile(p, "utf8");
    const feed = JSON.parse(txt) as EquityFeed;
    if (!feed?.panels || !Array.isArray(feed.rows) || feed.rows.length === 0) {
      return null;
    }
    const targetPoints = 300;
    const step = Math.max(1, Math.floor(feed.rows.length / targetPoints));
    return {
      ...feed,
      rows: feed.rows.filter((_, index) => index % step === 0 || index === feed.rows.length - 1),
    };
  } catch {
    return null;
  }
}

/** Even-stride downsample to ~targetPoints, always keeping the terminal row. */
function downsample<T>(rows: T[], targetPoints = 300): T[] {
  const step = Math.max(1, Math.floor(rows.length / targetPoints));
  if (step === 1) return rows;
  return rows.filter((_, i) => i % step === 0 || i === rows.length - 1);
}

/** Flatten a feed row into the EquityPanel shape for one panel. */
function toPanelRows(
  rows: FeedRow[],
  panel: PanelKey,
): PanelRow[] {
  const netKey = `${panel}_net` as const;
  return rows.map((r) => ({
    date: r.date,
    deposited: r.deposited,
    values: r[panel],
    net: r[netKey],
  }));
}

export default async function EquityPage() {
  const [feed, etf] = await Promise.all([loadFeed(), loadJson<EtfAllocationFeed>("etf_allocation.json")]);

  return (
    <main className="px-4 py-6 md:px-8 md:py-8">
      <header className="mb-8">
        <h1
          className="text-xl font-semibold tracking-tight"
          style={{ color: "var(--text-primary)" }}
        >
          Equity Comparison
        </h1>
        <p
          className="mt-1.5 text-sm"
          style={{ color: "var(--text-secondary)" }}
        >
          Select a strategy to inspect its own evidence. Existing PEA/CTO panels use
          {feed ? ` ${feed.basis.currency} ${feed.basis.initial.toLocaleString("en-IE")} initial + ${feed.basis.monthly.toLocaleString("en-IE")}/month.` : " their published contribution basis."}
          {" "}ETF Allocation has a separate contribution path and is never overlaid or summed with them.
          Net panel values apply exit tax; shared axes do not certify standardized comparison eligibility.
        </p>
      </header>

      <Suspense fallback={<p>Loading strategy performance…</p>}>
        <StrategyPerformanceSelector etf={etf} panels={feed ? PANEL_ORDER.map(key => ({ key, title: feed.panels[key].title, taxLabel: feed.panels[key].tax_label, series: feed.panels[key].series, rows: toPanelRows(downsample(feed.rows), key) })) : []} />
      </Suspense>
      {feed === null ? (
        <div
          className="rounded-[6px] p-6"
          style={{
            background: "var(--surface-raised)",
            border: "1px solid var(--border-subtle)",
          }}
        >
          <p
            className="text-sm font-medium"
            style={{ color: "var(--text-primary)" }}
          >
            No equity feed yet
          </p>
          <p className="mt-2 text-sm" style={{ color: "var(--text-secondary)" }}>
            The two-panel feed has not been generated. Run the equity update to populate it:
          </p>
          <code
            className="mt-3 inline-block rounded-[3px] px-2 py-1 font-mono text-[13px]"
            style={{
              background: "var(--surface-base)",
              color: "var(--text-primary)",
              border: "1px solid var(--border-subtle)",
            }}
          >
            uv run python -m simulator.main equity-update
          </code>
        </div>
      ) : (
        <p className="mt-6 text-xs" style={{ color: "var(--text-muted)" }}>Equity feed generated {feed.generated_at}. ETF research is never blended into these panels.</p>
      )}
    </main>
  );
}
