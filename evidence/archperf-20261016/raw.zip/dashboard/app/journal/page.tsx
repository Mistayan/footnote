import JournalTabs from "@/components/JournalTabs";
import { PageHeader } from "@/components/ui-patterns";
import { parseJournalQuery } from "@/lib/journalQuery";
import { loadJournalPage } from "@/lib/journalLoader";
export type { JournalFeedRow } from "@/lib/journalQuery";
export const dynamic = "force-dynamic";
export default async function JournalPage({ searchParams }: { searchParams?: Promise<Record<string, string | string[] | undefined>> }) {
  const params = await searchParams ?? {};
  const search = new URLSearchParams(Object.entries(params).filter((entry): entry is [string, string] => typeof entry[1] === "string"));
  const result = await loadJournalPage(parseJournalQuery(search));
  return <main className="px-4 py-6 md:px-8 md:py-8">
    <PageHeader title="Trade Journal" subtitle="Realized + open trades across all strategies." />
    <JournalTabs result={result} />
  </main>;
}
