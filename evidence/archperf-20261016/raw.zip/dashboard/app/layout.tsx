import type { Metadata } from "next";
import { Geist, Geist_Mono } from "next/font/google";
import "./globals.css";
import { cn } from "@/lib/utils";
import Sidebar from "@/components/Sidebar";
import fs from "node:fs/promises";
import path from "node:path";
import RestatementLane from "@/components/RestatementLane";
import { loadRestatementKpis } from "@/lib/restatementAdapter";
import type { KpiFeed } from "@/lib/feeds";
import { connection } from "next/server";
import { loadBorgDivAttribution } from "@/lib/borgdivAttributionLoader";

const geist = Geist({ subsets: ["latin"], variable: "--font-sans" });
const geistMono = Geist_Mono({ subsets: ["latin"], variable: "--font-mono" });

export const metadata: Metadata = {
  title: "BorgInvestor",
  description: "Live signals dashboard",
};

async function loadSignalsMeta(): Promise<{ vix?: number; hasData: boolean }> {
  try {
    const file = path.join(process.cwd(), "public", "live_signals.json");
    const raw = await fs.readFile(file, "utf8");
    const data = JSON.parse(raw) as { vix?: number };
    return { vix: data.vix, hasData: true };
  } catch {
    return { hasData: false };
  }
}

export const revalidate = 30;

export default async function RootLayout({ children }: { children: React.ReactNode }) {
  const diagnostic = Boolean(process.env.BORG_RESTATEMENT_DIR);
  // Retry must re-read evidence, not serve a cached acceptance result.
  if (diagnostic) await connection();
  const { vix, hasData } = diagnostic ? { vix: undefined, hasData: false } : await loadSignalsMeta();
  let feed: KpiFeed | null = null;
  let evidenceError: string | null = null;
  if (diagnostic) {
    try {
      if (!process.env.BORG_RESTATEMENT_LEGACY_KPIS) throw new Error("Exact frozen legacy KPI input not configured.");
      feed = await loadRestatementKpis(process.env.BORG_RESTATEMENT_DIR!, process.env.BORG_RESTATEMENT_LEGACY_KPIS);
    } catch {
      evidenceError = "Frozen evidence is unreadable or failed integrity, lineage or profile validation. Check the bundle and exact legacy input configuration.";
    }
  }

  const attribution = diagnostic && !evidenceError ? await loadBorgDivAttribution() : null;

  return (
    <html lang="en" className={cn("dark", geist.variable, geistMono.variable)}>
      <body
        className="min-h-screen flex"
        style={{ background: "var(--surface-base)", color: "var(--text-primary)" }}
      >
        <a href="#main-content" className="skip-link">Skip to content</a>
        <Sidebar vix={vix} live={hasData} />
        <div id="main-content" tabIndex={-1} className="flex-1 min-w-0 overflow-y-auto">
          {diagnostic ? <RestatementLane feed={feed} error={evidenceError} attribution={attribution} /> : children}
        </div>
      </body>
    </html>
  );
}
