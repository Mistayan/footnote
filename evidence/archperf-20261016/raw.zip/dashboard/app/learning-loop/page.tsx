"use client";

import { PageHeader, Card, KpiTile, type KpiTone } from "@/components/ui-patterns";
import { Database, AlertTriangle, Cpu, Layers, CheckCircle2 } from "lucide-react";

interface LearningLoopStatus {
  lookback_days: number;
  recorded_runs: number;
  recorded_signals: number;
  buy_signals: number;
  outcomes_recorded: number;
  win_rate_pct: number | null;
  avg_pnl_pct: number | null;
  pricing_failure_count: number;
  pricing_alert_active: boolean;
  freeze_active: boolean;
  freeze_reason: string | null;
  events_file: string;
  as_of: string;
}

function pnlTone(pnl: number | null): KpiTone {
  if (pnl == null) return "neutral";
  return pnl >= 0 ? "gain" : "loss";
}

import { useFetch } from "@/lib/useFetch";

export default function LearningLoopPage() {
  const { data, error } = useFetch<LearningLoopStatus>("/learning-loop");

  return (
    <main className="px-4 py-6 md:px-8 md:py-8 space-y-8 max-w-5xl">
      <PageHeader
        title="Learning Loop"
        subtitle={
          data?.as_of != null
            ? `As of ${data.as_of}`
            : "Signal outcomes & adaptive freeze status"
        }
      />

      {error != null ? (
        <Card aria-label="Learning loop error" className="border-red-900 bg-red-950/20">
          <div className="flex items-center gap-3 text-red-400">
            <AlertTriangle className="w-5 h-5 shrink-0" />
            <p className="text-sm font-mono">API connection failed: {error}</p>
          </div>
        </Card>
      ) : data === null ? (
        <Card aria-label="Learning loop loading">
          <p className="text-sm font-mono text-zinc-500 animate-pulse">Querying learning loop telemetry...</p>
        </Card>
      ) : (
        <div className="space-y-6">
          {/* Freeze / caution banner */}
          {data.freeze_active ? (
            <div
              className="rounded-[6px] p-4 flex items-start gap-3 border"
              style={{
                background: "var(--warn-bg)",
                borderColor: "var(--warn-border)",
                color: "var(--warn)",
              }}
              role="status"
            >
              <AlertTriangle className="w-4 h-4 mt-0.5 shrink-0" />
              <div className="text-xs">
                <span className="font-bold uppercase tracking-wider block mb-1">
                  Model Freeze In Force
                </span>
                {data.freeze_reason ?? "The learning loop model has suspended execution due to anomaly detection."}
              </div>
            </div>
          ) : (
            <div
              className="rounded-[6px] p-4 flex items-start gap-3 border bg-emerald-950/20 border-emerald-900/60 text-emerald-400"
              role="status"
            >
              <CheckCircle2 className="w-4 h-4 mt-0.5 shrink-0" />
              <div className="text-xs">
                <span className="font-bold uppercase tracking-wider block mb-1">
                  Model Health Nominal
                </span>
                Adaptive learning loop is active and executing live signal monitoring cycles.
              </div>
            </div>
          )}

          {data.pricing_alert_active ? (
            <div
              className="rounded-[6px] p-4 flex items-start gap-3 border"
              style={{
                background: "var(--warn-bg)",
                borderColor: "var(--warn-border)",
                color: "var(--warn)",
              }}
              role="status"
            >
              <AlertTriangle className="w-4 h-4 mt-0.5 shrink-0" />
              <div className="text-xs">
                <span className="font-bold uppercase tracking-wider block mb-1">
                  Pricing Probe Active
                </span>
                {data.pricing_failure_count} open-position pricing failures in the telemetry window.
              </div>
            </div>
          ) : null}

          {/* Metrics grid in card chrome */}
          <Card aria-label="Learning loop metrics" className="!p-6">
            <div className="flex items-center gap-2 mb-6 border-b pb-4" style={{ borderColor: "var(--border-subtle)" }}>
              <Cpu className="w-4 h-4 text-zinc-400" />
              <h3 className="text-sm font-bold text-white uppercase tracking-wider">Metrics Engine</h3>
            </div>
            
            <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-6">
              <KpiTile label="Lookback" value={`${data.lookback_days} days`} />
              <KpiTile label="Runs" value={data.recorded_runs} />
              <KpiTile label="Signals" value={data.recorded_signals} />
              <KpiTile label="Buy Signals" value={data.buy_signals} />
              <KpiTile label="Outcomes" value={data.outcomes_recorded} />
              <KpiTile
                label="Win Rate"
                value={
                  data.win_rate_pct == null
                    ? "—"
                    : `${data.win_rate_pct.toFixed(1)}%`
                }
              />
              <KpiTile
                label="Avg P&L"
                tone={pnlTone(data.avg_pnl_pct)}
                value={
                  data.avg_pnl_pct == null
                    ? "—"
                    : `${data.avg_pnl_pct.toFixed(2)}%`
                }
              />
              <KpiTile label="Pricing Probes" value={data.pricing_failure_count} />
            </div>
          </Card>

          {/* Data Path Diagnostics */}
          <Card aria-label="Learning loop telemetry path" className="!p-5 flex items-center justify-between">
            <div className="space-y-1">
              <span className="text-[10px] font-mono text-zinc-500 uppercase tracking-wider block">Telemetry Store</span>
              <span className="text-xs font-mono text-white select-all">{data.events_file}</span>
            </div>
            <div className="flex items-center gap-1.5 text-[10px] font-mono text-zinc-500 bg-zinc-900 px-2.5 py-1 rounded border border-zinc-800 shrink-0">
              <Database className="w-3.5 h-3.5 text-zinc-500" />
              JSONL LOG FILE
            </div>
          </Card>
        </div>
      )}
    </main>
  );
}
