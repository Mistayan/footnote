import { NextResponse } from "next/server";
import fs from "node:fs/promises";
import path from "node:path";

export async function GET() {
  try {
    const primary = path.join(process.cwd(), "public/live_signals.json");
    const fallback = path.resolve(process.cwd(), "../state/live_signals.json");

    try {
      const raw = await fs.readFile(primary, "utf8");
      return NextResponse.json(JSON.parse(raw));
    } catch {
      try {
        const raw = await fs.readFile(fallback, "utf8");
        return NextResponse.json(JSON.parse(raw));
      } catch {
        return NextResponse.json(
          { status: "unavailable", reason: "live_signals.json not found" },
          { status: 503 }
        );
      }
    }
  } catch (err: any) {
    return NextResponse.json(
      { status: "error", reason: err.message || "Failed to query signals" },
      { status: 500 }
    );
  }
}
