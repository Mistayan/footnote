/**
 * SSE endpoint — live_monitor POSTs here; clients subscribe via GET.
 *
 * GET  /api/stream  — EventSource stream, sends "signal" events
 * POST /api/stream  — live_monitor pushes new payload (body = live_signals JSON)
 */
import { NextRequest } from "next/server";

// In-process broadcast via ReadableStream controller set.
// If BORG_VINCULUM_REDIS_ENABLED is true, live_monitor also publishes to Redis
// channels named vinculum.dashboard.live_signals / vinculum.signals.*.
const controllers = new Set<ReadableStreamDefaultController<Uint8Array>>();
let latestPayload = "";

export async function GET() {
  const encoder = new TextEncoder();
  let ownedController: ReadableStreamDefaultController<Uint8Array> | undefined;

  const stream = new ReadableStream<Uint8Array>({
    start(controller) {
      ownedController = controller;
      controllers.add(controller);
      // Send cached latest immediately so new subscribers catch up
      if (latestPayload) {
        controller.enqueue(
          encoder.encode(`event: signal\ndata: ${latestPayload}\n\n`)
        );
      }
      controller.enqueue(encoder.encode(": connected\n\n"));
    },
    cancel() {
      // UnderlyingSource.cancel receives the cancellation reason, not controller.
      if (ownedController) controllers.delete(ownedController);
      ownedController = undefined;
    },
  });

  return new Response(stream, {
    headers: {
      "Content-Type": "text/event-stream",
      "Cache-Control": "no-cache",
      Connection: "keep-alive",
    },
  });
}

export async function POST(req: NextRequest) {
  try {
    const body = await req.text();
    JSON.parse(body); // validate
    latestPayload = body;
    const encoder = new TextEncoder();
    const msg = encoder.encode(`event: signal\ndata: ${body}\n\n`);
    const dead: ReadableStreamDefaultController<Uint8Array>[] = [];
    for (const ctrl of controllers) {
      try {
        ctrl.enqueue(msg);
      } catch {
        dead.push(ctrl);
      }
    }
    dead.forEach((c) => controllers.delete(c));
    return Response.json({ ok: true, subscribers: controllers.size });
  } catch (e) {
    return Response.json({ ok: false, error: String(e) }, { status: 400 });
  }
}
