import { NextRequest, NextResponse } from "next/server";
import path from "node:path";
import { tailJsonl } from "@/lib/telemetry";

export async function GET(request: NextRequest) {
  try {
    const searchParams = request.nextUrl.searchParams;
    const limitStr = searchParams.get("limit") || "100";
    let limit = parseInt(limitStr, 10);
    if (isNaN(limit) || limit <= 0) {
      limit = 100;
    }

    const eventsPath = path.resolve(process.cwd(), "../reports/borg_telemetry/events.jsonl");
    const events = await tailJsonl(eventsPath, limit);
    
    // Slice only the last `limit` events
    const slicedEvents = events.slice(-limit);
    return NextResponse.json(slicedEvents);
  } catch (err: any) {
    return NextResponse.json(
      { status: "error", reason: err.message || "Failed to query audit logs" },
      { status: 500 }
    );
  }
}
