import { NextRequest, NextResponse } from "next/server";
import { runPythonHelper } from "@/lib/pythonRunner";

export async function GET(request: NextRequest) {
  try {
    const searchParams = request.nextUrl.searchParams;
    const tickers = searchParams.get("tickers") || "";
    
    if (!tickers) {
      return NextResponse.json(
        { status: "error", reason: "Missing tickers query parameter" },
        { status: 400 }
      );
    }

    const history = await runPythonHelper<any>("price-history", [tickers]);
    return NextResponse.json(history);
  } catch (err: any) {
    return NextResponse.json(
      { status: "error", reason: err.message || "Failed to query price history" },
      { status: 500 }
    );
  }
}
