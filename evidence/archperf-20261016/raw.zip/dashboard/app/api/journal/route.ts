import { loadJournalPage } from '@/lib/journalLoader';
import { parseJournalQuery } from '@/lib/journalQuery';
export const dynamic='force-dynamic';
export async function GET(request:Request) {
  const result=await loadJournalPage(parseJournalQuery(new URL(request.url).searchParams));
  return Response.json(result,{status:result.status==='ready'?200:result.status==='blocked'?403:503,headers:{'Cache-Control':'no-store'}});
}
