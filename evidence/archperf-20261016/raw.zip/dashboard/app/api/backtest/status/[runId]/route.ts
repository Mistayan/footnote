import { NextRequest, NextResponse } from "next/server";
import fs from "node:fs/promises";
import path from "node:path";

export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ runId: string }> }
) {
  try {
    const { runId } = await params;
    if (!/^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test(runId)) {
      return NextResponse.json({ status: "error", reason: "Invalid run ID" }, { status: 400 });
    }
    const repoRoot = path.resolve(process.cwd(), "..");
    const backtestRunsDir = path.join(repoRoot, "state/backtest_runs");
    
    const metaPath = path.join(backtestRunsDir, `${runId}.json`);
    const logPath = path.join(backtestRunsDir, `${runId}.log`);

    let meta: any;
    try {
      const metaContent = await fs.readFile(metaPath, "utf8");
      meta = JSON.parse(metaContent);
    } catch {
      return NextResponse.json(
        { status: "error", reason: "Run ID not found" },
        { status: 404 }
      );
    }

    // If marked as running, check if process is actually alive
    if (meta.status === "running" && meta.pid) {
      try {
        process.kill(meta.pid, 0); // Check if alive
      } catch {
        // Process is dead. Update status to failed since it didn't exit cleanly
        meta.status = "failed";
        await fs.writeFile(metaPath, JSON.stringify(meta), "utf8");
        // Clean up lockfile if it matches this pid
        const lockPath = path.join(repoRoot, "state/backtest.lock");
        try {
          const currentLock = await fs.readFile(lockPath, "utf8");
          if (currentLock.trim() === meta.pid.toString()) {
            await fs.unlink(lockPath);
          }
        } catch {}
      }
    }

    // Read trailing logs
    let logs: string[] = [];
    try {
      const logContent = await fs.readFile(logPath, "utf8");
      logs = logContent.split(/\r?\n/).filter(line => line.trim().length > 0);
    } catch {}

    return NextResponse.json({
      run_id: runId,
      status: meta.status,
      started_at: meta.started_at,
      logs: logs,
    });
  } catch (err: any) {
    return NextResponse.json(
      { status: "error", reason: err.message || "Failed to query backtest status" },
      { status: 500 }
    );
  }
}
