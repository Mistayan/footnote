import { NextResponse } from "next/server";
import { spawn } from "node:child_process";
import fs from "node:fs/promises";
import path from "node:path";
import crypto from "node:crypto";
import { getPythonExecutable } from "@/lib/pythonRunner";

export async function POST() {
  let ownedLock: string | undefined;
  let childProcess: ReturnType<typeof spawn> | undefined;
  try {
    const runId = crypto.randomUUID();
    const repoRoot = path.resolve(process.cwd(), "..");
    const backtestRunsDir = path.join(repoRoot, "state/backtest_runs");
    
    // Ensure backtest runs directory exists
    await fs.mkdir(backtestRunsDir, { recursive: true });

    // Guard: Only allow one active backtest run at a time
    const lockPath = path.join(repoRoot, "state/backtest.lock");
    try {
      await fs.writeFile(lockPath, runId, { encoding: "utf8", flag: "wx" });
      ownedLock = lockPath;
    } catch (err) {
      if ((err as NodeJS.ErrnoException).code !== "EEXIST") throw err;
      return NextResponse.json(
        { status: "error", reason: "A backtest lock exists. Wait for completion; after a server crash, verify the process has stopped before removing state/backtest.lock." },
        { status: 409 },
      );
    }

    const logPath = path.join(backtestRunsDir, `${runId}.log`);
    const metaPath = path.join(backtestRunsDir, `${runId}.json`);

    const pythonPath = getPythonExecutable(repoRoot);
    const pythonEnv = { ...process.env };
    delete pythonEnv.PYTHONPATH;
    
    // Spawn python main_institutional.py
    const child = spawn(pythonPath, ["main_institutional.py"], {
      cwd: repoRoot,
      env: pythonEnv,
    });
    childProcess = child;
    await new Promise<void>((resolve, reject) => {
      child.once("spawn", resolve);
      child.once("error", reject);
    });

    const pid = child.pid;
    if (!pid) {
      throw new Error("Failed to spawn backtest process");
    }

    // Write lockfile containing PID
    await fs.writeFile(lockPath, pid.toString(), "utf8");

    const meta = {
      run_id: runId,
      status: "running",
      pid: pid,
      started_at: new Date().toISOString(),
    };
    await fs.writeFile(metaPath, JSON.stringify(meta), "utf8");

    // Open write stream for logs
    const logFile = await fs.open(logPath, "w");
    const writeStream = logFile.createWriteStream();
    child.stdout.pipe(writeStream, { end: false });
    child.stderr.pipe(writeStream, { end: false });
    writeStream.on("error", (error) => {
      console.error("Backtest log write failed:", error);
      child.kill();
    });

    // Watch process exit
    let finalized = false;
    const finalize = async (code: number | null) => {
      if (finalized) return;
      finalized = true;
      writeStream.end();
      try {
        meta.status = code === 0 ? "completed" : "failed";
        await fs.writeFile(metaPath, JSON.stringify(meta), "utf8");
        // Remove lockfile if this is the active process
        try {
          const currentLock = await fs.readFile(lockPath, "utf8");
          if (currentLock.trim() === pid.toString()) {
            await fs.unlink(lockPath);
          }
        } catch {}
      } catch (err) {
        console.error("Failed to write backtest exit status:", err);
      }
    };
    child.once("close", finalize);
    if (child.exitCode !== null || child.signalCode !== null) {
      await finalize(child.exitCode);
    }

    return NextResponse.json({ status: "started", run_id: runId });
  } catch (err: any) {
    // Keep the lock until termination is confirmed. A failed kill must never
    // allow a second run to overlap a still-running child.
    if (childProcess?.pid && childProcess.exitCode === null && childProcess.signalCode === null) {
      const lockToRelease = ownedLock;
      childProcess.once("close", () => {
        if (lockToRelease) void fs.unlink(lockToRelease).catch(() => {});
      });
      childProcess.kill();
    } else if (ownedLock) {
      await fs.unlink(ownedLock).catch(() => {});
    }
    return NextResponse.json(
      { status: "error", reason: err.message || "Failed to start backtest" },
      { status: 500 }
    );
  }
}
