import {loadOperationalAlerts} from '@/lib/operationalAlertsLoader';
export const dynamic='force-dynamic';
export const runtime='nodejs';
export async function GET(request:Request){
  const result=await loadOperationalAlerts(request.signal);
  return Response.json(result,{status:result.status==='ready'?200:result.status==='blocked'?403:503,headers:{'Cache-Control':'no-store'}});
}
