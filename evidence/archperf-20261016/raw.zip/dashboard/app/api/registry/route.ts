import { loadRegistryPage } from '@/lib/registryLoader';
import { parseRegistryQuery } from '@/lib/registryQuery';
export const dynamic='force-dynamic';
export const runtime='nodejs';
export async function GET(request:Request) {
  const headers={'Cache-Control':'no-store'};
  try {
    const result=await loadRegistryPage(parseRegistryQuery(new URL(request.url).searchParams),request.signal);
    return Response.json(result,{status:result.status==='ready'?200:result.status==='blocked'?403:result.status==='changed'?409:503,headers});
  }catch{return Response.json({status:'invalid',rows:[],matching:null,pages:null,maintenance:null,error:'Invalid registry filters. Use a canonical run UUID, valid dates and bounded pagination.'},{status:400,headers});}
}
