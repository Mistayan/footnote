import { NextRequest, NextResponse } from "next/server";
import fs from "node:fs/promises";
import path from "node:path";
import { runPythonHelper } from "@/lib/pythonRunner";

export async function POST(request: NextRequest) {
  try {
    const formData = await request.formData();
    const file = formData.get("file") as File;
    
    if (!file) {
      return NextResponse.json(
        { status: "error", reason: "No file provided" },
        { status: 400 }
      );
    }

    if (!file.name.endsWith(".csv")) {
      return NextResponse.json(
        { status: "error", reason: "Only CSV files are supported" },
        { status: 400 }
      );
    }

    const repoRoot = path.resolve(process.cwd(), "..");
    const csvPath = path.join(repoRoot, "Transaction export.csv");

    const buffer = Buffer.from(await file.arrayBuffer());
    await fs.writeFile(csvPath, buffer);

    const updatedHoldings = await runPythonHelper<any[]>("reconcile-csv", [csvPath]);
    return NextResponse.json(updatedHoldings);
  } catch (err: any) {
    return NextResponse.json(
      { status: "error", reason: err.message || "Failed to upload and reconcile CSV" },
      { status: 500 }
    );
  }
}
