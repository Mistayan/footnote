import { NextResponse } from "next/server";
import { runPythonHelper } from "@/lib/pythonRunner";

export async function GET() {
  try {
    const holdings = await runPythonHelper<any[]>("resolve-holdings");
    return NextResponse.json(holdings);
  } catch (err: any) {
    return NextResponse.json(
      { status: "error", reason: err.message || "Failed to resolve holdings" },
      { status: 500 }
    );
  }
}
