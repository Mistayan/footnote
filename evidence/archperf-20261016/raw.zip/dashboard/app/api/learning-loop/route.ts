import { NextResponse } from "next/server";
import path from "node:path";
import { tailJsonl } from "@/lib/telemetry";

export async function GET() {
  try {
    const eventsPath = path.resolve(process.cwd(), "../reports/borg_telemetry/events.jsonl");
    const events = await tailJsonl(eventsPath);

    const cutoff = new Date(Date.now() - 14 * 24 * 60 * 60 * 1000);
    const recent: any[] = [];

    for (const ev of events) {
      const tsRaw = ev.ts || ev.timestamp || "";
      try {
        const ts = new Date(tsRaw);
        if (isNaN(ts.getTime()) || ts >= cutoff) {
          recent.push(ev);
        }
      } catch {
        recent.push(ev);
      }
    }

    const runs = recent.filter((e) => e.event_type === "run_completed");
    const signalsEv = recent.filter((e) => e.event_type === "signal_evaluated");
    const buySignals = signalsEv.filter((e) => e.action === "BUY");
    const outcomes = recent.filter(
      (e) =>
        e.event_type === "trade_outcome" &&
        (e.payload?.outcome_type === "forward" || !e.payload)
    );
    const pricingFailures = recent.filter(
      (e) =>
        e.event_type === "system_probe" &&
        e.payload?.name === "probe_pricing_failure"
    );

    const getPnl = (o: any) =>
      o.payload && typeof o.payload === "object" ? o.payload.pnl_pct : o.pnl_pct;

    const pnlValues = outcomes
      .map(getPnl)
      .filter((v) => v !== undefined && v !== null);

    const wins = pnlValues.filter((p) => p > 0);
    const winRate =
      outcomes.length > 0
        ? Math.round((wins.length / outcomes.length) * 100 * 10) / 10
        : null;

    const avgPnl =
      pnlValues.length > 0
        ? Math.round(
            (pnlValues.reduce((a, b) => a + b, 0) / pnlValues.length) * 100
          ) / 100
        : null;

    const freezeActive = outcomes.length < 200;
    const freezeReason = freezeActive
      ? `only ${outcomes.length} outcomes recorded (need 200)`
      : null;

    const relativeEventsPath = path.relative(path.resolve(process.cwd(), ".."), eventsPath);

    return NextResponse.json({
      lookback_days: 14,
      recorded_runs: runs.length,
      recorded_signals: signalsEv.length,
      buy_signals: buySignals.length,
      outcomes_recorded: outcomes.length,
      win_rate_pct: winRate,
      avg_pnl_pct: avgPnl,
      pricing_failure_count: pricingFailures.length,
      pricing_alert_active: pricingFailures.length >= 2,
      freeze_active: freezeActive,
      freeze_reason: freezeReason,
      events_file: relativeEventsPath,
      as_of: new Date().toISOString(),
    });
  } catch (err: any) {
    return NextResponse.json(
      { status: "unavailable", reason: err.message || "Failed to query telemetry" },
      { status: 503 }
    );
  }
}
