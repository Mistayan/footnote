import { NextResponse } from "next/server";
import { runPythonHelper } from "@/lib/pythonRunner";

export async function GET() {
  try {
    const meta = await runPythonHelper("holdings-meta");
    return NextResponse.json(meta);
  } catch (err: any) {
    return NextResponse.json(
      { status: "error", reason: err.message || "Failed to resolve holdings metadata" },
      { status: 500 }
    );
  }
}
