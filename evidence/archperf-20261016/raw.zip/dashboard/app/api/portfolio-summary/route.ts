import { NextResponse } from "next/server";
import { runPythonHelper } from "@/lib/pythonRunner";

export async function GET() {
  try {
    const summary = await runPythonHelper<any>("portfolio-summary");
    return NextResponse.json(summary);
  } catch (err: any) {
    return NextResponse.json(
      { status: "error", reason: err.message || "Failed to compile portfolio summary" },
      { status: 500 }
    );
  }
}
