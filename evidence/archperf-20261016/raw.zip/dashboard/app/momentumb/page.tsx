/**
 * MomentumB cockpit tab (REQ-3/6/7) — server shell.
 *
 * MomentumB has sparse shadow fills, not a continuous strategy equity feed. The
 * chart uses journal BUY/SELL events plus a live net-P&L anchor; holdings come
 * from shadow_positions.json, KPIs from kpis.json, news from news.json, and the
 * intent log remains a same-day diagnostic panel.
 *
 * Feeds load server-side and the tab renders gracefully on any null (T-19-14/15).
 * `revalidate = 30` preserved. An optional `?window=YYYY-MM-DD` searchParam is
 * accepted for the intent log (the picker also filters client-side; the feed
 * carries today's window by default, matching "today's SELL intents appear").
 */
import {
  loadJson,
  toStrategyTrades,
  type IntentFeed,
  type NewsFeed,
  type KpiFeed,
  type PriceHistory,
  type ShadowPayload,
  type ShadowPosition,
  type TradesFeed,
  type JournalFeed,
} from "@/lib/feeds";
import StrategyKpiBar from "@/components/StrategyKpiBar";
import MomentumEventChart from "@/components/MomentumEventChart";
import IntentLogTable from "@/components/IntentLogTable";
import NewsPanel from "@/components/NewsPanel";
import StrategyHoldingsTable from "@/components/StrategyHoldingsTable";
import StrategyChart from "@/components/StrategyChart";
import { PageHeader } from "@/components/ui-patterns";

export const revalidate = 30;

const STRATEGY = "momentumb";

function selectSeries(
  prices: PriceHistory | null,
  positions: ShadowPosition[],
): { ticker: string; series: { date: string; close: number }[] } {
  if (!prices) return { ticker: "", series: [] };
  for (const ticker of positions.map((p) => p.ticker)) {
    const series = prices.series[ticker];
    if (series?.length) return { ticker, series };
  }
  const keys = Object.keys(prices.series);
  if (keys.length > 0) return { ticker: keys[0], series: prices.series[keys[0]] };
    return { ticker: "", series: [] };
}

function Panel({
  title,
  children,
}: {
  title: string;
  children: React.ReactNode;
}) {
  return (
    <section className="mb-8">
      <h2
        className="text-sm font-semibold mb-3 uppercase tracking-wide"
        style={{ color: "var(--text-secondary)" }}
      >
        {title}
      </h2>
      {children}
    </section>
  );
}

export default async function MomentumBPage({
  searchParams,
}: {
  searchParams?: Promise<{ window?: string }>;
}) {
  // searchParam is accepted but the single-window feed + client picker already
  // cover look-back; we resolve it so the contract is wired for a future
  // multi-window server re-request without changing the component API.
  await searchParams;

  const [intents, news, shadow, kpis, journal, prices, tradesFeed] = await Promise.all([
    loadJson<IntentFeed>("intents.json"),
    loadJson<NewsFeed>("news.json"),
    loadJson<ShadowPayload>("shadow_positions.json"),
    loadJson<KpiFeed>("kpis.json"),
    loadJson<JournalFeed>("journal.json"),
    loadJson<PriceHistory>("price_history.json"),
    loadJson<TradesFeed>("trades.json"),
  ]);

  const momentumKpi = kpis?.per_strategy?.[STRATEGY] ?? null;
  const momentumNetPnlEur = momentumKpi?.net_pnl_eur ?? null;
  const historicalRestatement = kpis?.protocol === "ORIGINAL_FILLS_RESTATEMENT_V1";
  const momentumJournalRows = journal?.by_strategy?.[STRATEGY] ?? [];
  const positions = shadow?.positions ?? [];
  const momentumPositions = positions.filter((p) => p.strategy === STRATEGY);
  const { ticker, series: priceSeries } = selectSeries(prices, momentumPositions);
  const trades = toStrategyTrades(tradesFeed?.by_strategy?.[STRATEGY]);

  return (
    <main className="px-4 py-6 md:px-8 md:py-8">
      <PageHeader
        title="MomentumB"
        subtitle="Shadow-fill cockpit — trade events, snapshot book evidence, holdings, intent diagnostics, and CTO news."
      />

      <StrategyKpiBar strategy={STRATEGY} kpi={momentumKpi} />

      <Panel title="Price & Events">
        <p className="text-sm mb-3" style={{ color: "var(--text-secondary)" }}>Selected ticker: {ticker || "unknown"} · Other listings excluded. Close currency / FX provenance unknown; not EUR execution fills. Exact-date events only; unmatched dates remain unplotted.</p>
        <StrategyChart series={priceSeries} trades={trades} selectedTicker={ticker} quoteCurrencyUnknown />
      </Panel>

      <Panel title="Event / P&L">
        {historicalRestatement ? <p className="text-sm" style={{ color: "var(--text-secondary)" }}>Historical restatement input as of {kpis?.input_as_of} — not combined with a different-date journal or a current net P&amp;L anchor. Daily NAV and freshness unknown.</p> :
        <MomentumEventChart
          feed={intents}
          shadowNetPnlEur={momentumNetPnlEur}
          journalRows={momentumJournalRows}
        />}
      </Panel>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2">
          <Panel title="Intent Log">
            <IntentLogTable feed={intents} />
          </Panel>
        </div>
        <div>
          <Panel title="CTO News">
            <NewsPanel feed={news} />
          </Panel>
        </div>
      </div>

      <Panel title="Holdings (shadow store)">
        <StrategyHoldingsTable strategy={STRATEGY} positions={positions} />
      </Panel>
    </main>
  );
}
