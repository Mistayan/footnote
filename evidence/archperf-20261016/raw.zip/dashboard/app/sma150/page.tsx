import { loadJson, type Sma150WatchlistFeed } from "@/lib/feeds";
import { Card, EmptyState, PageHeader } from "@/components/ui-patterns";

export const revalidate = 30;

export default async function Sma150Page() {
  const feed = await loadJson<Sma150WatchlistFeed>("sma150_watchlist.json");
  const candidates = feed?.candidates ?? [];

  return (
    <main className="px-4 py-6 md:px-8 md:py-8 max-w-7xl">
      <PageHeader title="SMA150 Research" subtitle="TradingView candidates retained for 30 days; no capital or shadow positions yet." />
      <Card className="mb-6 !p-4">
        <div className="flex flex-wrap gap-5 text-xs text-zinc-400">
          <span><b className="text-amber-400">RESEARCH ONLY</b> · promotion gate not passed</span>
          <span>Scan: <b className="text-white">{feed?.generated_at ?? "not generated"}</b></span>
          <span>Active now: <b className="text-white">{candidates.filter((row) => row.active).length}</b></span>
          <span>Tracked: <b className="text-white">{candidates.length}</b></span>
        </div>
      </Card>

      {candidates.length === 0 ? <EmptyState message="Run the SMA150 screen to populate the research watchlist." /> : (
        <Card className="!p-0 overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="text-[10px] uppercase tracking-wider border-b border-zinc-800 text-zinc-500">
              <tr>
                <th className="px-4 py-3">Ticker</th><th className="px-4 py-3">State</th>
                <th className="px-4 py-3">Setup</th><th className="px-4 py-3 text-right">Close</th>
                <th className="px-4 py-3 text-right">vs SMA150</th><th className="px-4 py-3 text-right">Volume</th>
                <th className="px-4 py-3">Observed</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-zinc-800">
              {candidates.map((row) => (
                <tr key={row.exchange_symbol}>
                  <td className="px-4 py-3"><b className="text-white">{row.ticker}</b><div className="text-[10px] text-zinc-500">{row.description}</div></td>
                  <td className="px-4 py-3"><span className={row.entry_status === "accepted" ? "text-emerald-400" : row.active ? "text-amber-400" : "text-zinc-500"}>{row.entry_status.replaceAll("_", " ").toUpperCase()}</span></td>
                  <td className="px-4 py-3 text-zinc-300">{row.setup.replaceAll("_", " ")}</td>
                  <td className="px-4 py-3 text-right font-mono text-white">${row.close.toFixed(2)}</td>
                  <td className="px-4 py-3 text-right font-mono">{((row.close / row.sma150 - 1) * 100).toFixed(2)}%</td>
                  <td className="px-4 py-3 text-right font-mono">{row.volume_ratio.toFixed(2)}×</td>
                  <td className="px-4 py-3 text-zinc-400">{row.first_seen} → {row.last_seen}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </Card>
      )}
    </main>
  );
}
