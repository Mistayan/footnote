"use client";

import { getTickerName } from "@/lib/tickerHelper";
import { PageHeader, Card, EmptyState } from "@/components/ui-patterns";
import { Terminal, Shield, AlertTriangle, Calendar, Percent } from "lucide-react";

interface Signal {
  ticker: string;
  action?: string;
  score?: number;
  price?: number;
  sector?: string;
  name?: string;
}

interface SignalsPayload {
  timestamp?: string;
  market_date?: string;
  vix?: number;
  threshold?: number;
  alpha_signals?: Signal[];
  risky_signals?: Signal[];
}

function ActionBadge({ action }: { action?: string }) {
  if (action === "BUY") {
    return (
      <span className="inline-flex items-center gap-1 text-[10px] font-bold px-2 py-0.5 rounded bg-emerald-950 text-emerald-400 border border-emerald-900">
        BUY
      </span>
    );
  }
  if (action === "SELL" || action === "SELL_HALF") {
    return (
      <span className="inline-flex items-center gap-1 text-[10px] font-bold px-2 py-0.5 rounded bg-red-950 text-red-400 border border-red-900">
        {action}
      </span>
    );
  }
  return (
    <span className="inline-flex items-center gap-1 text-[10px] font-bold px-2 py-0.5 rounded bg-zinc-900 text-zinc-500 border border-zinc-800">
      {action ?? "HOLD"}
    </span>
  );
}

function scoreColor(score: number | undefined): string {
  if (score == null) return "var(--text-muted)";
  if (score >= 70) return "var(--gain)";
  if (score >= 40) return "var(--warn)";
  return "var(--text-muted)";
}

function SignalTable({ signals }: { signals: Signal[] }) {
  if (signals.length === 0) {
    return <EmptyState message="No signals generated for this regime." />;
  }
  return (
    <div className="overflow-x-auto">
      <table className="w-full text-left text-xs">
        <thead
          className="text-[10px] uppercase tracking-wider font-semibold border-b"
          style={{ color: "var(--text-muted)", borderColor: "var(--border-subtle)" }}
        >
          <tr>
            <th className="py-2.5 px-4">Ticker</th>
            <th className="py-2.5 px-4">Action</th>
            <th className="py-2.5 px-4 text-right">Score</th>
            <th className="py-2.5 px-4 text-right">Price</th>
            <th className="py-2.5 px-4">Sector</th>
            <th className="py-2.5 px-4">Company Name</th>
          </tr>
        </thead>
        <tbody className="divide-y divide-zinc-800">
          {signals.map((sig, i) => (
            <tr
              key={i}
              className="transition-colors duration-100"
              onMouseEnter={(e) => {
                e.currentTarget.style.background = "var(--surface-hover)";
              }}
              onMouseLeave={(e) => {
                e.currentTarget.style.background = "transparent";
              }}
            >
              <td className="py-2.5 px-4" style={{ color: "var(--text-primary)" }}>
                <div className="flex flex-col py-0.5">
                  <span className="font-semibold text-[13px] leading-tight">{getTickerName(sig.ticker, sig.name)}</span>
                  <span className="text-[10px] font-mono tracking-wider opacity-60 mt-0.5" style={{ color: "var(--text-muted)" }}>{sig.ticker}</span>
                </div>
              </td>
              <td className="py-2.5 px-4">
                <ActionBadge action={sig.action} />
              </td>
              <td
                className="py-2.5 px-4 text-right font-mono font-semibold"
                style={{ color: scoreColor(sig.score) }}
              >
                {sig.score != null ? sig.score.toFixed(0) : "—"}
              </td>
              <td
                className="py-2.5 px-4 text-right font-mono font-semibold"
                style={{ color: "var(--text-primary)" }}
              >
                {sig.price != null ? `€${sig.price.toFixed(2)}` : "—"}
              </td>
              <td className="py-2.5 px-4 text-zinc-400">
                {sig.sector ?? "—"}
              </td>
              <td className="py-2.5 px-4 text-zinc-400">
                {sig.name ?? "—"}
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

import { useFetch } from "@/lib/useFetch";

export default function SignalsPage() {
  const { data, error } = useFetch<SignalsPayload>("/signals");

  return (
    <main className="px-4 py-6 md:px-8 md:py-8 space-y-8 max-w-6xl">
      <PageHeader
        title="Signals"
        subtitle={
          data?.market_date != null
            ? `Market date ${data.market_date}`
            : "Daily alpha & risk screen"
        }
      />

      {error != null ? (
        <Card aria-label="Signals error" className="border-red-900 bg-red-950/20">
          <div className="flex items-center gap-3 text-red-400">
            <AlertTriangle className="w-5 h-5 shrink-0" />
            <p className="text-sm font-mono font-semibold">API Server Offline: {error}</p>
          </div>
        </Card>
      ) : data === null ? (
        <Card aria-label="Signals loading">
          <p className="text-sm font-mono text-zinc-500 animate-pulse">Intaking alpha screen signals...</p>
        </Card>
      ) : (
        <div className="space-y-8">
          {/* Market regime meta */}
          <Card aria-label="Market regime" className="!p-5">
            <div className="flex flex-wrap gap-x-12 gap-y-4 text-xs">
              <div className="flex items-center gap-2">
                <Calendar className="w-4 h-4 text-zinc-500" />
                <span className="text-zinc-500 uppercase font-mono">Date:</span>
                <span className="font-mono font-bold text-white">{data.market_date ?? "—"}</span>
              </div>
              <div className="flex items-center gap-2">
                <Shield className="w-4 h-4 text-zinc-500" />
                <span className="text-zinc-500 uppercase font-mono">Volatility (VIX):</span>
                <span className="font-mono font-bold text-white">{data.vix != null ? data.vix.toFixed(1) : "—"}</span>
              </div>
              <div className="flex items-center gap-2">
                <Percent className="w-4 h-4 text-zinc-500" />
                <span className="text-zinc-500 uppercase font-mono">Decay Threshold:</span>
                <span className="font-mono font-bold text-white">{data.threshold != null ? data.threshold.toFixed(2) : "—"}</span>
              </div>
            </div>
          </Card>

          {/* Alpha signals */}
          <Card aria-label="Alpha signals" className="!p-0 overflow-hidden">
            <div className="px-6 py-4 border-b flex items-center gap-2" style={{ borderColor: "var(--border-subtle)" }}>
              <Terminal className="w-4 h-4 text-zinc-400" />
              <h2
                className="text-xs uppercase tracking-wider font-extrabold text-white"
              >
                Alpha Signal Pipeline
              </h2>
            </div>
            <div className="p-2">
              <SignalTable signals={data.alpha_signals ?? []} />
            </div>
          </Card>

          {/* Risky signals */}
          <Card aria-label="Risky signals" className="!p-0 overflow-hidden">
            <div className="px-6 py-4 border-b flex items-center gap-2 bg-[rgba(255,200,0,0.01)]" style={{ borderColor: "var(--border-subtle)" }}>
              <AlertTriangle className="w-4 h-4 text-amber-500" />
              <h2
                className="text-xs uppercase tracking-wider font-extrabold text-white"
              >
                High Beta / Risky Signals
              </h2>
            </div>
            <div className="p-2">
              <SignalTable signals={data.risky_signals ?? []} />
            </div>
          </Card>
        </div>
      )}
    </main>
  );
}
