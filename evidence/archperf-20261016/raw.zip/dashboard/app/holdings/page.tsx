"use client";

import { useEffect, useState, useCallback, useRef } from "react";
import type { CanonicalHolding } from "@/components/HoldingsTable";
import HoldingsTable from "@/components/HoldingsTable";
import HoldingsFreshness from "@/components/HoldingsFreshness";
import KpiBar from "@/components/KpiBar";
import { PageHeader, EmptyState } from "@/components/ui-patterns";
import { Upload, RefreshCw, X } from "lucide-react";

interface PortfolioSummary {
  total_value_eur: number | null;
  unrealized_pnl_net_eur: number | null;
  positions_count: number | null;
  win_rate_90d: number | null;
}

function ImportButton({ onUploadSuccess }: { onUploadSuccess: (newHoldings: CanonicalHolding[]) => void }) {
  const [uploading, setUploading] = useState(false);
  const fileInput = useRef<HTMLInputElement>(null);
  const apiUrl = process.env.NEXT_PUBLIC_API_URL ?? "http://localhost:8000";

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setUploading(true);
    const formData = new FormData();
    formData.append("file", file);

    try {
      const res = await fetch(`${apiUrl}/holdings/upload-csv`, {
        method: "POST",
        body: formData,
      });
      if (!res.ok) {
        const err = await res.json();
        throw new Error(err?.detail || "Upload failed");
      }
      const newHoldings = await res.json() as CanonicalHolding[];
      onUploadSuccess(newHoldings);
      alert("Successfully imported Trade Republic CSV and reconciled holdings!");
    } catch (err: any) {
      alert(`Import failed: ${err.message}`);
    } finally {
      setUploading(false);
    }
  };

  return (
    <div className="flex items-center gap-2 text-xs font-semibold px-3 py-1.5 rounded-[4px] transition-colors"
      style={{
        background: "rgba(255, 255, 255, 0.03)",
        border: "1px solid var(--border-subtle)",
        color: "var(--text-secondary)",
      }}
      onMouseEnter={(e) => {
        e.currentTarget.style.background = "rgba(255, 255, 255, 0.08)";
        e.currentTarget.style.color = "var(--text-primary)";
      }}
      onMouseLeave={(e) => {
        e.currentTarget.style.background = "rgba(255, 255, 255, 0.03)";
        e.currentTarget.style.color = "var(--text-secondary)";
      }}
    >
      <Upload size={14} className={uploading ? "animate-pulse" : ""} />
      <button type="button" className="min-h-12" disabled={uploading} onClick={() => fileInput.current?.click()}>{uploading ? "Syncing..." : "Sync TR CSV"}</button>
      <input ref={fileInput} aria-label="Trade Republic CSV" type="file" accept=".csv" className="hidden" onChange={handleFileChange} disabled={uploading} />
    </div>
  );
}

function LiveSyncModal({ isOpen, onClose }: { isOpen: boolean; onClose: () => void }) {
  const dialog = useRef<HTMLDialogElement>(null);
  const [copied, setCopied] = useState(false);
  useEffect(() => {
    const node = dialog.current;
    if (!isOpen || !node) return;
    const trigger = document.activeElement as HTMLElement | null;
    node.showModal();
    return () => { node.close(); trigger?.focus(); };
  }, [isOpen]);
  return <dialog ref={dialog} aria-labelledby="manual-sync-title" onCancel={onClose}
    onKeyDown={e => {
      if (e.key !== "Tab") return;
      const controls = Array.from(e.currentTarget.querySelectorAll<HTMLButtonElement>('button:not(:disabled)'));
      const index = controls.indexOf(document.activeElement as HTMLButtonElement);
      if (e.shiftKey && index <= 0) { e.preventDefault(); controls.at(-1)?.focus(); }
      else if (!e.shiftKey && (index === controls.length - 1 || index < 0)) { e.preventDefault(); controls[0]?.focus(); }
    }}
    className="manual-sync-dialog rounded-lg p-6" style={{background:"var(--surface-raised)", color:"var(--text-primary)",border:"1px solid var(--border-default)"}}>
    <div className="flex items-start justify-between gap-4">
      <h2 id="manual-sync-title" className="text-lg font-semibold">Manual sync required</h2>
      <button autoFocus type="button" aria-label="Close manual sync" className="min-h-12 min-w-12" onClick={onClose}><X size={20}/></button>
    </div>
    <p className="text-sm my-4">Web sync is suspended. Authenticate from your own terminal using the maintained application command. This dialog does not collect credentials or start a broker operation.</p>
    <code className="block break-words text-sm p-3" style={{background:"var(--surface-overlay)"}}>uv run python -m simulator.main sync-tr</code>
    <button className="min-h-12 underline mt-3" type="button" onClick={async () => {
      try { await navigator.clipboard.writeText("uv run python -m simulator.main sync-tr"); setCopied(true); }
      catch { setCopied(false); }
    }}>{copied ? "Command copied" : "Copy sync command"}</button>
    <p role="status" className="text-sm">{copied ? "Copied only; nothing executed." : "Select the command to copy manually if clipboard access is unavailable."}</p>
    <button type="button" disabled className="min-h-12 mt-3 text-sm" style={{color:"var(--text-muted)"}}>Sync via Web Client Suspended</button>
  </dialog>;
}

export default function HoldingsPage() {
  const [data, setData] = useState<CanonicalHolding[] | null>(null);
  const [summary, setSummary] = useState<PortfolioSummary | null>(null);
  const [priceHistory, setPriceHistory] = useState<Record<string, number[]>>({});
  const [error, setError] = useState<string | null>(null);
  const [isSyncModalOpen, setIsSyncModalOpen] = useState(false);
  const [retry, setRetry] = useState(0);

  const apiUrl = process.env.NEXT_PUBLIC_API_URL ?? "http://localhost:8000";

  const fetchSummaryAndPrices = useCallback((holdings: CanonicalHolding[]) => {
    fetch(`${apiUrl}/portfolio-summary`)
      .then((r) => r.ok ? r.json() as Promise<PortfolioSummary> : null)
      .then((summ) => { if (summ) setSummary(summ); })
      .catch(() => {});

    const tickers = holdings
      .filter((h) => h.market_value_eur != null)
      .map((h) => h.ticker)
      .join(",");
    if (tickers) {
      fetch(`${apiUrl}/price-history?tickers=${encodeURIComponent(tickers)}`)
        .then((r) => r.ok ? r.json() as Promise<Record<string, number[]>> : {})
        .then(setPriceHistory)
        .catch(() => {});
    }
  }, [apiUrl]);

  useEffect(() => {
    setError(null);
    fetch(`${apiUrl}/holdings`)
      .then((r) => {
        if (!r.ok) throw new Error("API " + r.status);
        return r.json() as Promise<CanonicalHolding[]>;
      })
      .then((holdings) => {
        setData(holdings);
        fetchSummaryAndPrices(holdings);
      })
      .catch(() => setError("Holdings could not be loaded."));
  }, [apiUrl, fetchSummaryAndPrices, retry]);

  const handleUploadSuccess = (newHoldings: CanonicalHolding[]) => {
    setData(newHoldings);
    fetchSummaryAndPrices(newHoldings);
  };

  return (
    <main className="px-4 py-6 md:px-8 md:py-8">
      <KpiBar
        portfolioEur={summary?.total_value_eur}
        dailyPnlEur={summary?.unrealized_pnl_net_eur}
        positionsCount={summary?.positions_count}
        winRate={summary?.win_rate_90d}
      />
      <div className="flex flex-col md:flex-row items-start justify-between gap-4">
        <PageHeader
          title="Holdings"
          subtitle="Consolidated open positions across CTO + PEA accounts."
        />
        <div className="pt-1 flex flex-wrap items-center gap-3 mb-6 min-w-0">
          <button
            onClick={() => setIsSyncModalOpen(true)}
            className="min-h-12 flex items-center gap-2 text-xs font-semibold px-3 py-1.5 rounded-[4px] cursor-pointer transition-colors"
            style={{
              background: "rgba(255, 255, 255, 0.03)",
              border: "1px solid var(--border-subtle)",
              color: "var(--text-secondary)",
            }}
            onMouseEnter={(e) => {
              e.currentTarget.style.background = "rgba(255, 255, 255, 0.08)";
              e.currentTarget.style.color = "var(--text-primary)";
            }}
            onMouseLeave={(e) => {
              e.currentTarget.style.background = "rgba(255, 255, 255, 0.03)";
              e.currentTarget.style.color = "var(--text-secondary)";
            }}
          >
            <RefreshCw size={14} />
            <span>Live TR Sync</span>
          </button>
          <ImportButton onUploadSuccess={handleUploadSuccess} />
          <HoldingsFreshness />
        </div>
      </div>
      {error != null ? (
        <div role="alert"><EmptyState label="API unavailable" message={error} /><button type="button" className="min-h-12 underline" onClick={() => setRetry(r => r + 1)}>Retry holdings</button></div>
      ) : data === null ? (
        <EmptyState label="Loading" message="Fetching holdings…" />
      ) : data.length === 0 ? (
        <EmptyState label="Empty" message="No holdings found." />
      ) : (
        <HoldingsTable rows={data} priceHistory={priceHistory} />
      )}
      
      <LiveSyncModal
        isOpen={isSyncModalOpen}
        onClose={() => setIsSyncModalOpen(false)}
      />
    </main>
  );
}
