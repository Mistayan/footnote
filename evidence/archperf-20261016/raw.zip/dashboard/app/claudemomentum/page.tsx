import {
  loadJson,
  toStrategyTrades,
  type KpiFeed,
  type PriceHistory,
  type ShadowPayload,
  type ShadowPosition,
  type TradesFeed,
} from "@/lib/feeds";
import StrategyChart from "@/components/StrategyChart";
import StrategyHoldingsTable from "@/components/StrategyHoldingsTable";
import StrategyKpiBar from "@/components/StrategyKpiBar";
import { PageHeader } from "@/components/ui-patterns";

export const revalidate = 30;

const STRATEGY = "claudemomentum";

function selectSeries(prices: PriceHistory | null, positions: ShadowPosition[]) {
  if (!prices) return [];
  for (const ticker of positions.map((p) => p.ticker)) {
    const series = prices.series[ticker];
    if (series?.length) return series;
  }
  const keys = Object.keys(prices.series);
  if (keys.length > 0) return prices.series[keys[0]];
  return [];
}

export default async function ClaudeMomentumPage() {
  const [prices, tradesFeed, shadow, kpis] = await Promise.all([
    loadJson<PriceHistory>("price_history.json"),
    loadJson<TradesFeed>("trades.json"),
    loadJson<ShadowPayload>("shadow_positions.json"),
    loadJson<KpiFeed>("kpis.json"),
  ]);

  const positions = shadow?.positions ?? [];
  const strategyPositions = positions.filter((p) => p.strategy === STRATEGY);
  const ticker = strategyPositions.map(p => p.ticker).find(t => prices?.series[t]?.length) ?? Object.keys(prices?.series ?? {}).find(t => prices?.series[t]?.length) ?? "";
  const series = prices?.series[ticker] ?? [];
  const trades = toStrategyTrades(tradesFeed?.by_strategy?.[STRATEGY]);

  return (
    <main className="px-4 py-6 md:px-8 md:py-8">
      <PageHeader title="Claude Momentum" subtitle="Claude-authored momentum strategy — price, events, open holdings." />
      <StrategyKpiBar strategy={STRATEGY} kpi={kpis?.per_strategy?.[STRATEGY] ?? null} />
      <section className="mb-8">
        <h2 className="text-sm font-semibold mb-3 uppercase tracking-wide" style={{ color: "var(--text-secondary)" }}>
          Price &amp; Events
        </h2>
        <p className="text-sm mb-3" style={{ color: "var(--text-secondary)" }}>Selected ticker: {ticker || "unknown"} · Other listings excluded. Close currency / FX provenance unknown; prices are not EUR execution fills. Exact-date events only; unmatched dates remain unplotted.</p>
        <StrategyChart series={series} trades={trades} selectedTicker={ticker} quoteCurrencyUnknown />
      </section>
      <section>
        <h2 className="text-sm font-semibold mb-3 uppercase tracking-wide" style={{ color: "var(--text-secondary)" }}>
          Open Holdings
        </h2>
        <StrategyHoldingsTable strategy={STRATEGY} positions={positions} />
      </section>
    </main>
  );
}
