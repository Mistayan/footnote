"use client";
import {
  LineChart, Line, XAxis, YAxis, CartesianGrid,
  Tooltip, ResponsiveContainer, ReferenceLine,
} from "recharts";

interface Row {
  date: string;
  bh: number;
  cto: number;
  pea: number;
  bh_net?: number;
  cto_net?: number;
  pea_net?: number;
}

interface Props {
  data: Row[];
  initialDeposited: number;
}

export default function PeaEquityChart({ data, initialDeposited }: Props) {
  const last = data[data.length - 1];
  const fmt = (v: number) =>
    `€${v.toLocaleString("fr-FR", { maximumFractionDigits: 0 })}`;

  // Strategy palette → resolved --strat-* hex (25-01) — Recharts strokes need literals.
  const cards = last ? [
    { label: "Buy & Hold", gross: last.bh,  net: last.bh_net,  color: "#8A93A8", tax: "30% PFU" },
    { label: "CTO Bot",    gross: last.cto, net: last.cto_net, color: "#B59A6B", tax: "30% PFU" },
    { label: "PEA Bot",    gross: last.pea, net: last.pea_net, color: "#7C9FC2", tax: "17.2% PS only" },
  ] : [];

  return (
    <div>
      {/* Terminal value cards */}
      <div className="grid grid-cols-3 gap-4 mb-6">
        {cards.map((c) => (
          <div key={c.label} className="rounded-[6px] p-4"
               style={{ background: "var(--surface-raised)", border: `1px solid ${c.color}33` }}>
            <p className="text-xs uppercase tracking-wide mb-2"
               style={{ color: "var(--text-muted)" }}>{c.label}</p>
            <p className="text-xl font-mono font-semibold" style={{ color: c.color }}>
              {c.net != null ? fmt(c.net) : "—"}
            </p>
            <p className="text-xs mt-1" style={{ color: "var(--text-muted)" }}>
              gross {c.gross != null ? fmt(c.gross) : "—"} · tax {c.tax}
            </p>
          </div>
        ))}
      </div>

      {/* Chart */}
      <ResponsiveContainer width="100%" height={360}>
        <LineChart data={data} margin={{ top: 8, right: 16, bottom: 0, left: 0 }}>
          <CartesianGrid strokeDasharray="3 3" stroke="#27272a" />
          <XAxis dataKey="date" tick={{ fontSize: 11, fill: "#71717a" }} tickLine={false}
                 interval={Math.floor(data.length / 8)} />
          <YAxis tick={{ fontSize: 11, fill: "#71717a" }} tickLine={false} axisLine={false}
                 tickFormatter={(v) => `€${((v as number) / 1000).toFixed(0)}k`} />
          <Tooltip
            contentStyle={{ background: "#18181b", border: "1px solid #3f3f46", fontSize: 12 }}
            formatter={(v, name) => [typeof v === "number" ? fmt(v) : String(v), String(name)]}
          />
          <ReferenceLine y={initialDeposited} stroke="#71717a" strokeDasharray="4 4" />
          <Line type="monotone" dataKey="bh"  name="Buy & Hold" stroke="#8A93A8"
                strokeWidth={1.5} dot={false} isAnimationActive={false} />
          <Line type="monotone" dataKey="cto" name="CTO Bot"    stroke="#B59A6B"
                strokeWidth={2}   dot={false} isAnimationActive={false} />
          <Line type="monotone" dataKey="pea" name="PEA Bot"    stroke="#7C9FC2"
                strokeWidth={2}   dot={false} isAnimationActive={false} />
        </LineChart>
      </ResponsiveContainer>

      {/* Legend */}
      <div className="mt-6 grid grid-cols-1 gap-3 sm:grid-cols-3 text-xs"
           style={{ color: "var(--text-muted)" }}>
        <div className="flex gap-2">
          <span className="w-3 h-3 mt-0.5 rounded-sm shrink-0" style={{ background: "var(--strat-borgpea)" }} />
          <div><b style={{ color: "var(--text-primary)" }}>Buy &amp; Hold</b> — SP5.PA S&amp;P500 ETF,
          same DCA, no trading. Tax: 30% PFU on gains at exit.</div>
        </div>
        <div className="flex gap-2">
          <span className="w-3 h-3 mt-0.5 rounded-sm shrink-0" style={{ background: "var(--strat-momentumb)" }} />
          <div><b style={{ color: "var(--text-primary)" }}>CTO Bot</b> — MomentumB v15,
          664 US tickers. Tax: 30% PFU on each realized gain.</div>
        </div>
        <div className="flex gap-2">
          <span className="w-3 h-3 mt-0.5 rounded-sm shrink-0" style={{ background: "var(--strat-borgpea)" }} />
          <div><b style={{ color: "var(--text-primary)" }}>PEA Bot</b> — same algo, UCITS ETFs only.
          Tax after 5y: 17.2% PS only (no income tax). €150k deposit cap.</div>
        </div>
      </div>
      <p className="mt-3 text-xs" style={{ color: "var(--text-muted)" }}>
        Net values apply exit tax on total unrealised gains at terminal date.
        PEA tax advantage assumes account opened ≥5 years ago.
        Gross pre-fee, pre-slippage. Past backtest ≠ future results.
      </p>
    </div>
  );
}
