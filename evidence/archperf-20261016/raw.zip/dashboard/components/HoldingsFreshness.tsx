"use client";

import { useEffect, useState } from "react";

interface HoldingsMeta {
  updated_at: string | null;
  age_days: number | null;
  stale: boolean;
}

/**
 * Freshness indicator for the holdings snapshot.
 *
 * Holdings are refreshed manually from the Trade Republic "Net Worth" export —
 * there is no auto-scheduler — so this badge surfaces the snapshot age and flags
 * drift: under 1 week pulses green (fresh), over 1 week pulses red (stale).
 *
 * Accessibility: color is paired with a text label, role="status" + aria-live
 * announce updates, and the pulse animation is gated on prefers-reduced-motion.
 */
export default function HoldingsFreshness() {
  const [meta, setMeta] = useState<HoldingsMeta | null>(null);
  const [offline, setOffline] = useState(false);
  const apiUrl = process.env.NEXT_PUBLIC_API_URL ?? "http://localhost:8000";

  useEffect(() => {
    fetch(`${apiUrl}/holdings-meta`)
      .then((r) => {
        if (!r.ok) throw new Error();
        return r.json() as Promise<HoldingsMeta>;
      })
      .then((m) => {
        if (m) {
          setMeta(m);
          setOffline(false);
        }
      })
      .catch(() => {
        setOffline(true);
      });
  }, [apiUrl]);

  if (offline) {
    const color = "var(--loss)";
    return (
      <>
        <div
          role="status"
          aria-live="polite"
          aria-label="Holdings status: API offline"
          className="inline-flex items-center gap-2 rounded-md px-2.5 py-1"
          style={{
            background: "var(--surface-raised, rgba(255,255,255,0.03))",
            border: "1px solid var(--border-subtle)",
          }}
          title="The dashboard API server is offline. Run 'uv run python -m simulator.main dashboard-api' to start it."
        >
          <span
            className="holdings-freshness-dot inline-block rounded-full"
            style={{ width: 8, height: 8, background: color }}
          />
          <span
            className="text-[11px] uppercase tracking-widest"
            style={{ color: "var(--text-muted)" }}
          >
            Holdings
          </span>
          <span
            className="text-[12px] font-semibold"
            style={{
              fontFamily: "var(--font-mono, monospace)",
              color,
            }}
          >
            OFFLINE · API UNREACHABLE
          </span>
        </div>
        <style jsx>{`
          @media (prefers-reduced-motion: no-preference) {
            .holdings-freshness-dot {
              animation: holdings-freshness-pulse-offline 1.6s ease-in-out infinite;
            }
          }
          @keyframes holdings-freshness-pulse-offline {
            0%,
            100% {
              opacity: 1;
              box-shadow: 0 0 0 0 var(--loss);
            }
            50% {
              opacity: 0.55;
              box-shadow: 0 0 6px 1px var(--loss);
            }
          }
        `}</style>
      </>
    );
  }

  if (meta == null || meta.age_days == null) return null;

  const stale = meta.stale;
  const color = stale ? "var(--loss)" : "var(--gain)";
  const days = Math.floor(meta.age_days);
  const ageLabel =
    days <= 0 ? "today" : days === 1 ? "1 day ago" : `${days} days ago`;
  const statusLabel = stale ? "Stale" : "Fresh";

  return (
    <>
      <div
        role="status"
        aria-live="polite"
        aria-label={`Holdings ${statusLabel.toLowerCase()}, updated ${ageLabel}`}
        className="inline-flex items-center gap-2 rounded-md px-2.5 py-1"
        style={{
          background: "var(--surface-raised, rgba(255,255,255,0.03))",
          border: "1px solid var(--border-subtle)",
        }}
        title={
          meta.updated_at
            ? `Last updated ${new Date(meta.updated_at).toLocaleString("fr-FR")}`
            : undefined
        }
      >
        <span
          className="holdings-freshness-dot inline-block rounded-full"
          style={{ width: 8, height: 8, background: color }}
        />
        <span
          className="text-[11px] uppercase tracking-widest"
          style={{ color: "var(--text-muted)" }}
        >
          Holdings
        </span>
        <span
          className="text-[12px] font-semibold tabular-nums"
          style={{
            fontFamily: "var(--font-mono, monospace)",
            color,
          }}
        >
          {statusLabel} · {ageLabel}
        </span>
      </div>
      <style jsx>{`
        @media (prefers-reduced-motion: no-preference) {
          .holdings-freshness-dot {
            animation: holdings-freshness-pulse 1.6s ease-in-out infinite;
          }
        }
        @keyframes holdings-freshness-pulse {
          0%,
          100% {
            opacity: 1;
            box-shadow: 0 0 0 0 ${stale ? "var(--loss)" : "var(--gain)"};
          }
          50% {
            opacity: 0.55;
            box-shadow: 0 0 6px 1px ${stale ? "var(--loss)" : "var(--gain)"};
          }
        }
      `}</style>
    </>
  );
}
