"use client";

import { usePathname } from "next/navigation";
import type { KpiFeed } from "@/lib/feeds";
import OverviewCards from "./OverviewCards";
import StrategyKpiBar from "./StrategyKpiBar";
import { STRAT_LABEL } from "@/lib/strategies";
import BorgDivAttribution from "./BorgDivAttribution";
import type { BorgDivAttributionModel } from "@/lib/borgdivAttribution";

/** The layout boundary excludes every current/public panel, including API holdings. */
export default function RestatementLane({ feed, error, attribution }: { feed: KpiFeed | null; error: string | null; attribution?: BorgDivAttributionModel | null }) {
  const pathname = usePathname();
  const key = pathname.split("/")[1];
  const strategy = feed?.per_strategy[key] ? key : null;
  const title = STRAT_LABEL[key] ?? ({ overview: "Overview", journal: "Trade Journal", holdings: "Holdings", performance: "Performance", equity: "Equity", signals: "Signals" } as Record<string, string>)[key] ?? "Evidence bundle";
  return <main className="px-4 py-6 md:px-8 md:py-8 space-y-6 break-words">
    <h1 className="text-2xl font-semibold">{title}</h1>
    <section className="rounded p-4 space-y-2" style={{ background: "var(--surface-raised)", border: "1px solid var(--border-subtle)" }}>
      <h2 className="font-semibold">Original-fills current-policy diagnostic</h2>
      <p>Original fixed €20,000 per sleeve · no monthly deposits · not a normalized replay.</p>
      <p>Parent cohort: SHADOW_COHORT_20260802_ORIGINAL (2026-08-02); historical profile identity and recorded funding unverified.</p>
      <p>Input as of {feed?.input_as_of ?? "unknown"} · freshness unknown · run {feed?.run_id ?? "unavailable"}.</p>
      <p>BorgDiv Q is pre-ex run-up: candidates are not executed fills; calendar estimates are not earned income. Paid dividends unknown.</p>
    </section>
    {error ? <section role="alert" className="rounded p-4 space-y-2" style={{ border: "1px solid var(--loss)" }}>
      <h2 className="font-semibold">Evidence error — bundle rejected</h2>
      <p>{error}</p><p>No fallback to public KPI, position, price or trade data. This is invalid evidence, not an absent feed.</p>
      <button type="button" className="min-h-12 underline" onClick={() => window.location.reload()}>Retry evidence read</button>
    </section> : <>
      {!strategy && <OverviewCards kpis={feed} />}
      <div className={strategy ? "grid grid-cols-1 max-w-3xl gap-4" : "grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-4"}>
        {(strategy ? [strategy] : Object.keys(feed?.per_strategy ?? {})).map(s => <StrategyKpiBar key={s} strategy={s} kpi={feed?.per_strategy[s] ?? null} />)}
      </div>
    </>}
    {!error && key === "borgdiv" && attribution && <BorgDivAttribution model={attribution} />}
    <section className="rounded p-4 space-y-2" style={{ background: "var(--surface-raised)", border: "1px solid var(--border-subtle)" }}>
      <h2 className="font-semibold">Normalized €20,000 + €1,000 monthly — BLOCKED</h2>
      <p>COMPARISON_V1 requires matched deposit dates (including the first month), common strategy/benchmark/FX window, point-in-time fills, costs and account/tax lane. No certified full-roster replay supplied.</p>
      <p>Normalized cohort and replay start/end dates: unknown. No invented deposits, performance, ranking or promotion.</p>
    </section>
    <section className="space-y-2 text-sm" style={{ color: "var(--text-secondary)" }}>
      <h2 className="font-semibold">Unavailable evidence panels</h2>
      <p>Holdings — unknown/blocked: no compatible frozen holdings renderer; public positions excluded.</p>
      <p>Price &amp; events — unknown/blocked: no hash-bound daily price series; public prices and trade markers excluded.</p>
      <p>Journal — unknown/blocked: frozen trade sidecar retained as evidence, not combined with a different-date journal or a current net P&amp;L anchor.</p>
      <p>Calendar, intents and news — unknown/blocked: no compatible frozen panel evidence; incoming calendar estimates are not income.</p>
      <p>No dated daily marked NAV evidence. Daily NAV, Sharpe and drawdown unknown; historical backtest curves excluded.</p>
    </section>
  </main>;
}
