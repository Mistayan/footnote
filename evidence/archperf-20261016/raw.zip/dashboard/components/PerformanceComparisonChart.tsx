"use client";
import {
  CartesianGrid,
  Line,
  LineChart,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";

type ChartSeries = {
  key: string;
  label: string;
  color: string;
  dashed?: boolean;
};

type ChartRow = {
  date: string;
  [key: string]: string | number | null;
};

function fmtEur(value: unknown): string {
  return typeof value === "number"
    ? `€${value.toLocaleString("en-EU", { maximumFractionDigits: 0 })}`
    : "—";
}

export default function PerformanceComparisonChart({
  rows,
  series,
}: {
  rows: ChartRow[];
  series: ChartSeries[];
}) {
  if (rows.length === 0 || series.length === 0) {
    return (
      <div
        className="flex h-[280px] items-center justify-center rounded-[6px] text-sm"
        style={{ border: "1px solid var(--border-subtle)", color: "var(--text-muted)" }}
      >
        No comparison curve available.
      </div>
    );
  }

  return (
    <div>
      <ResponsiveContainer width="100%" height={280}>
        <LineChart data={rows} margin={{ top: 8, right: 18, bottom: 0, left: 0 }}>
          <CartesianGrid strokeDasharray="3 3" stroke="#27272a" />
          <XAxis dataKey="date" tick={{ fontSize: 11, fill: "#71717a" }} tickLine={false} />
          <YAxis
            tick={{ fontSize: 11, fill: "#71717a" }}
            tickLine={false}
            axisLine={false}
            tickFormatter={(v) => `€${Number(v).toLocaleString("en-EU", { notation: "compact" })}`}
          />
          <Tooltip
            contentStyle={{ background: "#18181b", border: "1px solid #3f3f46", fontSize: 12 }}
            labelStyle={{ color: "#a1a1aa" }}
            formatter={(value, name) => [fmtEur(value), String(name)]}
          />
          {series.map((s) => (
            <Line
              key={s.key}
              type="monotone"
              dataKey={s.key}
              name={s.label}
              stroke={s.color}
              strokeDasharray={s.dashed ? "5 4" : undefined}
              strokeWidth={s.dashed ? 1.5 : 2.25}
              dot={false}
              isAnimationActive={false}
            />
          ))}
        </LineChart>
      </ResponsiveContainer>
      <div className="mt-3 flex flex-wrap gap-x-4 gap-y-2 text-xs" style={{ color: "var(--text-secondary)" }}>
        {series.map((s) => (
          <span key={s.key} className="inline-flex items-center gap-2">
            <span
              className="h-2 w-4 rounded-sm"
              style={{ background: s.dashed ? "transparent" : s.color, border: `1px solid ${s.color}` }}
            />
            {s.label}
          </span>
        ))}
      </div>
    </div>
  );
}
