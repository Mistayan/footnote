"use client";

/**
 * IntentLogTable — MomentumB shadow_intent log (REQ-3 / DASH-V2-03).
 *
 * TELEMETRY-ONLY (RESEARCH Pitfall 1): rows come straight from intents.json's
 * `intents[]` (shadow_intent events) — NOT a sqlite holdings filter and NOT a
 * price series. The feed carries a single window (`window` = the day it was
 * generated, typically today). The date picker defaults to today and lets the
 * user look back: it filters the loaded intents client-side by `date`, and when
 * the page wires a `?window=` searchParam the picker also re-points the URL so a
 * wider/earlier payload can be re-requested server-side.
 *
 * Columns (tanstack convention, mirrors HoldingsTable): date, ticker, action,
 * score, price. Actions are color-coded (BUY vs SELL/SELL_HALF/HOLD). An empty
 * window renders an explicit empty-state row — never a crash (T-19-15).
 */
import {
  useReactTable,
  getCoreRowModel,
  getSortedRowModel,
  flexRender,
  type ColumnDef,
  type SortingState,
} from "@tanstack/react-table";
import { useMemo, useState } from "react";
import {
  Table,
  TableHeader,
  TableBody,
  TableHead,
  TableRow,
  TableCell,
} from "@/components/ui/table";
import type { IntentFeed } from "@/lib/feeds";

/** A single shadow_intent row as rendered in the table. */
type IntentRow = IntentFeed["intents"][number];

const fmtScore = (v: number): string => v.toFixed(2);
const fmtPrice = (v: number): string =>
  v.toLocaleString("fr-FR", { minimumFractionDigits: 2, maximumFractionDigits: 4 });

/** Color-code the action: BUY = gain, any SELL variant = loss, HOLD/other = muted. */
function actionColor(action: string): string {
  const a = action.toUpperCase();
  if (a.startsWith("BUY")) return "var(--gain)";
  if (a.startsWith("SELL")) return "var(--loss)";
  return "var(--text-muted)";
}

const COLUMNS: ColumnDef<IntentRow>[] = [
  {
    accessorKey: "date",
    header: "Date",
    cell: ({ getValue }) => (
      <span className="font-mono text-xs" style={{ color: "var(--text-secondary)" }}>
        {getValue() as string}
      </span>
    ),
  },
  {
    accessorKey: "ticker",
    header: "Ticker",
    cell: ({ getValue }) => (
      <span className="font-mono font-semibold" style={{ color: "var(--text-primary)" }}>
        {getValue() as string}
      </span>
    ),
  },
  {
    accessorKey: "action",
    header: "Action",
    cell: ({ getValue }) => {
      const action = getValue() as string;
      return (
        <span
          className="font-mono font-semibold text-xs uppercase tracking-wide"
          style={{ color: actionColor(action) }}
        >
          {action}
        </span>
      );
    },
  },
  {
    accessorKey: "score",
    header: () => <span className="w-full text-right block">Score</span>,
    cell: ({ getValue }) => (
      <span className="tabular-nums font-mono block text-right">
        {fmtScore(getValue() as number)}
      </span>
    ),
  },
  {
    accessorKey: "price",
    header: () => <span className="w-full text-right block">Price</span>,
    cell: ({ getValue }) => (
      <span className="tabular-nums font-mono block text-right">
        {fmtPrice(getValue() as number)}
      </span>
    ),
  },
];

interface IntentLogTableProps {
  feed: IntentFeed | null;
  /**
   * Optional callback wired by the page so a date change can also re-point a
   * `?window=` searchParam (server re-request). When absent, the picker filters
   * the loaded intents client-side only.
   */
  onWindowChange?: (date: string) => void;
}

/** Local YYYY-MM-DD for the date-input default (today). */
function todayIso(): string {
  const d = new Date();
  const tz = d.getTimezoneOffset() * 60_000;
  return new Date(d.getTime() - tz).toISOString().slice(0, 10);
}

export default function IntentLogTable({ feed, onWindowChange }: IntentLogTableProps) {
  const allIntents = useMemo(() => feed?.intents ?? [], [feed]);

  // Default the picker to the feed's window if present (the day it was generated,
  // typically today), else fall back to the local "today". This keeps "today's
  // SELL intents appear" as the default view (acceptance criterion).
  const [selectedDate, setSelectedDate] = useState<string>(feed?.window ?? todayIso());
  const [sorting, setSorting] = useState<SortingState>([]);

  // Look-back: filter the loaded intents by the chosen date.
  const rows = useMemo(
    () => allIntents.filter((i) => i.date === selectedDate),
    [allIntents, selectedDate],
  );

  const table = useReactTable({
    data: rows,
    columns: COLUMNS,
    state: { sorting },
    onSortingChange: setSorting,
    getCoreRowModel: getCoreRowModel(),
    getSortedRowModel: getSortedRowModel(),
  });

  function handleDateChange(e: React.ChangeEvent<HTMLInputElement>) {
    const next = e.target.value || todayIso();
    setSelectedDate(next);
    onWindowChange?.(next);
  }

  return (
    <div>
      <div className="flex items-center gap-3 mb-4">
        <label
          htmlFor="intent-window-date"
          className="text-xs uppercase tracking-wide"
          style={{ color: "var(--text-muted)" }}
        >
          Window
        </label>
        <input
          id="intent-window-date"
          type="date"
          value={selectedDate}
          max={todayIso()}
          onChange={handleDateChange}
          aria-label="Intent log window date"
          className="px-3 py-1.5 rounded text-sm font-mono"
          style={{
            background: "var(--surface-raised)",
            border: "1px solid var(--border-default)",
            color: "var(--text-primary)",
          }}
        />
        <span className="text-xs font-mono ml-auto" style={{ color: "var(--text-muted)" }}>
          {rows.length} intent{rows.length === 1 ? "" : "s"}
        </span>
      </div>

      <div
        className="overflow-x-auto rounded-[6px]"
        style={{ border: "1px solid var(--border-subtle)" }}
      >
        <Table>
          <TableHeader>
            {table.getHeaderGroups().map((hg) => (
              <TableRow
                key={hg.id}
                style={{
                  background: "var(--surface-raised)",
                  borderBottom: "1px solid var(--border-subtle)",
                }}
              >
                {hg.headers.map((h) => (
                  <TableHead
                    key={h.id}
                    onClick={h.column.getToggleSortingHandler()}
                    className="cursor-pointer select-none text-xs uppercase tracking-wide"
                    style={{ color: "var(--text-muted)" }}
                  >
                    {flexRender(h.column.columnDef.header, h.getContext())}
                    {h.column.getIsSorted() === "asc"
                      ? " ▲"
                      : h.column.getIsSorted() === "desc"
                      ? " ▼"
                      : ""}
                  </TableHead>
                ))}
              </TableRow>
            ))}
          </TableHeader>
          <TableBody>
            {rows.length === 0 ? (
              <TableRow>
                <TableCell
                  colSpan={COLUMNS.length}
                  className="text-center text-sm py-8"
                  style={{ color: "var(--text-muted)" }}
                >
                  No shadow intents for {selectedDate}.
                </TableCell>
              </TableRow>
            ) : (
              table.getRowModel().rows.map((row) => (
                <TableRow
                  key={row.id}
                  className="transition-colors"
                  style={{ borderBottom: "1px solid var(--border-subtle)" }}
                  onMouseEnter={(e) =>
                    (e.currentTarget.style.background = "var(--surface-hover)")
                  }
                  onMouseLeave={(e) => (e.currentTarget.style.background = "")}
                >
                  {row.getVisibleCells().map((cell) => (
                    <TableCell key={cell.id} style={{ color: "var(--text-secondary)" }}>
                      {flexRender(cell.column.columnDef.cell, cell.getContext())}
                    </TableCell>
                  ))}
                </TableRow>
              ))
            )}
          </TableBody>
        </Table>
      </div>
    </div>
  );
}
