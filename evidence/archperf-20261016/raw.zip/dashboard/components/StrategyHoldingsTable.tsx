"use client";

/**
 * StrategyHoldingsTable — Phase-19 per-strategy open holdings (REQ-3 / DASH-V2-03).
 *
 * A strategy-filtered sortable table over `shadow_positions.json` open positions,
 * reusing the tanstack-table convention from `HoldingsTable.tsx` (useReactTable,
 * sorting, CSS-var theme).
 *
 * Position semantics (RESEARCH Pitfall 3): `shadow_positions.json` already contains
 * ONLY live open positions (the writer excludes `void`/phantom rows). We additionally
 * filter by `strategy` so each tab shows just its own book. Empty -> explicit
 * empty-state row, no crash (T-19-11 mitigation).
 */
import {
  useReactTable,
  getCoreRowModel,
  getSortedRowModel,
  flexRender,
  type ColumnDef,
  type SortingState,
} from "@tanstack/react-table";
import { useMemo, useState } from "react";
import {
  Table,
  TableHeader,
  TableBody,
  TableHead,
  TableRow,
  TableCell,
} from "@/components/ui/table";
import type { ShadowPosition } from "@/lib/feeds";

const fmtEur = (v: number | null): string =>
  v == null ? "—" : `€${v.toLocaleString("fr-FR", { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;

const fmtPct = (v: number | null): string =>
  v == null ? "—" : `${v > 0 ? "+" : ""}${v.toFixed(2)}%`;

const fmtShares = (v: number): string => v.toFixed(4);

const pnlColor = (v: number | null): string =>
  v == null ? "var(--text-muted)" : v > 0 ? "var(--gain)" : v < 0 ? "var(--loss)" : "var(--text-muted)";

function buildColumns(): ColumnDef<ShadowPosition>[] {
  return [
    {
      accessorKey: "ticker",
      header: "Ticker",
      cell: ({ getValue }) => (
        <span className="font-mono font-semibold" style={{ color: "var(--text-primary)" }}>
          {getValue() as string}
        </span>
      ),
    },
    {
      accessorKey: "entry_eur",
      header: () => <span className="w-full text-right block">Entry (€)</span>,
      cell: ({ getValue }) => (
        <span className="tabular-nums font-mono block text-right">
          {fmtEur(getValue() as number)}
        </span>
      ),
    },
    {
      accessorKey: "current_eur",
      header: () => <span className="w-full text-right block">Current (€)</span>,
      cell: ({ getValue }) => (
        <span className="tabular-nums font-mono block text-right">
          {fmtEur(getValue() as number | null)}
        </span>
      ),
    },
    {
      accessorKey: "shares",
      header: () => <span className="w-full text-right block">Shares</span>,
      cell: ({ getValue }) => (
        <span className="tabular-nums font-mono block text-right">
          {fmtShares(getValue() as number)}
        </span>
      ),
    },
    {
      accessorKey: "unrealized_eur",
      header: () => <span className="w-full text-right block">Unrealized (€)</span>,
      cell: ({ getValue }) => {
        const v = getValue() as number | null;
        return (
          <span className="tabular-nums font-mono block text-right" style={{ color: pnlColor(v) }}>
            {fmtEur(v)}
          </span>
        );
      },
    },
    {
      accessorKey: "unrealized_pct",
      header: () => <span className="w-full text-right block">Unrealized %</span>,
      cell: ({ getValue }) => {
        const v = getValue() as number | null;
        return (
          <span className="tabular-nums font-mono block text-right" style={{ color: pnlColor(v) }}>
            {fmtPct(v)}
          </span>
        );
      },
    },
  ];
}

export type StrategyHoldingsTableProps = {
  /** Strategy key, e.g. "borgdiv" | "borgpea" | "momentumb". */
  strategy: string;
  /** All shadow positions (already open-only); filtered to `strategy` here. */
  positions: ShadowPosition[];
};

export default function StrategyHoldingsTable({ strategy, positions }: StrategyHoldingsTableProps) {
  const [sorting, setSorting] = useState<SortingState>([]);

  const rows = useMemo(
    () => positions.filter((p) => p.strategy === strategy),
    [positions, strategy],
  );

  const columns = useMemo(() => buildColumns(), []);

  const table = useReactTable({
    data: rows,
    columns,
    state: { sorting },
    onSortingChange: setSorting,
    getCoreRowModel: getCoreRowModel(),
    getSortedRowModel: getSortedRowModel(),
  });

  return (
    <div
      className="overflow-x-auto rounded-[6px]"
      style={{ border: "1px solid var(--border-subtle)" }}
    >
      <Table>
        <TableHeader>
          {table.getHeaderGroups().map((hg) => (
            <TableRow
              key={hg.id}
              style={{ background: "var(--surface-raised)", borderBottom: "1px solid var(--border-subtle)" }}
            >
              {hg.headers.map((h) => (
                <TableHead
                  key={h.id}
                  onClick={h.column.getToggleSortingHandler()}
                  className="cursor-pointer select-none text-xs uppercase tracking-wide"
                  style={{ color: "var(--text-muted)" }}
                >
                  {flexRender(h.column.columnDef.header, h.getContext())}
                  {h.column.getIsSorted() === "asc"
                    ? " ▲"
                    : h.column.getIsSorted() === "desc"
                    ? " ▼"
                    : ""}
                </TableHead>
              ))}
            </TableRow>
          ))}
        </TableHeader>
        <TableBody>
          {rows.length === 0 ? (
            <TableRow>
              <TableCell
                colSpan={columns.length}
                className="text-center text-sm py-6"
                style={{ color: "var(--text-muted)" }}
              >
                No open positions for {strategy}.
              </TableCell>
            </TableRow>
          ) : (
            table.getRowModel().rows.map((row) => (
              <TableRow
                key={row.id}
                className="transition-colors"
                style={{ borderBottom: "1px solid var(--border-subtle)" }}
                onMouseEnter={(e) => (e.currentTarget.style.background = "var(--surface-hover)")}
                onMouseLeave={(e) => (e.currentTarget.style.background = "")}
              >
                {row.getVisibleCells().map((cell) => (
                  <TableCell key={cell.id} style={{ color: "var(--text-secondary)" }}>
                    {flexRender(cell.column.columnDef.cell, cell.getContext())}
                  </TableCell>
                ))}
              </TableRow>
            ))
          )}
        </TableBody>
      </Table>
    </div>
  );
}
