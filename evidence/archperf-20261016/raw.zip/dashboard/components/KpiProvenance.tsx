import type { KpiEvidence } from "@/lib/feeds";

/** File/render time is never a market observation or a freshness receipt. */
export default function KpiProvenance({ evidence }: { evidence: KpiEvidence }) {
  const historical = evidence.provenance_status === "frozen_input_hash_bound_profile_identity_unverified";
  return (
    <div className="text-sm break-words space-y-2" style={{ color: "var(--text-secondary)" }}>
      <p>{historical ? "Historical restatement" : "Shadow book diagnostic"} · input as of {evidence.input_as_of ?? "unknown"} · valuation {evidence.valuation_status ?? "unknown"} · freshness unknown · profile identity unverified · not COMPARISON_V1</p>
      <p>FX {evidence.fx_status ?? "unknown"} · missing marks {evidence.missing_marks_count ?? "unknown"}{Boolean((evidence.valuation_unknown_reasons ?? evidence.valuation_missing_reasons)?.length) && <> · blockers: {(evidence.valuation_unknown_reasons ?? evidence.valuation_missing_reasons)!.join(", ").replaceAll("_", " ")}</>}</p>
      <details><summary className="min-h-12 flex items-center cursor-pointer underline">Source, cost and tax evidence</summary><p className="text-xs">
      {historical ? "Historical restatement" : "Shadow book diagnostic"}
      {" · input as of "}{evidence.input_as_of ?? "unknown"}
      {" · file generated "}{evidence.input_generated_at ?? "unknown"}{" (not market observation date)"}
      {" · freshness unknown · profile identity unverified · not COMPARISON_V1"}
      {historical && " · SHA-256 integrity only, not signed accounting certification"}
      {" · FX "}{evidence.fx_status ?? "unknown"}
      {" · fees "}{evidence.fees_eur == null ? "unknown" : `€${evidence.fees_eur}`}
      {" · spread/slippage "}{evidence.spread_slippage_eur == null ? "unknown" : `€${evidence.spread_slippage_eur}`}
      {" · tax policy "}{evidence.tax_policy ?? "unknown"}
      {" · valuation "}{evidence.valuation_status ?? "unknown"}
      {" · priced positions "}{evidence.priced_positions_count ?? "unknown"}
      {" · missing marks "}{evidence.missing_marks_count ?? "unknown"}
      {Boolean((evidence.valuation_unknown_reasons ?? evidence.valuation_missing_reasons)?.length) && <> · missing evidence: {(evidence.valuation_unknown_reasons ?? evidence.valuation_missing_reasons)!.join(", ").replaceAll("_", " ")}</>}
      </p></details>
    </div>
  );
}
