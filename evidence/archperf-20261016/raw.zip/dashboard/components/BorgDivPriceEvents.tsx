"use client";

import { useState } from "react";
import type { PriceHistory, DividendFeed, TradeEvent } from "@/lib/feeds";
import StrategyChart from "./StrategyChart";

/** A selected listing owns both the price series and every event overlay. */
export default function BorgDivPriceEvents({ prices, events, dividends, preferredTickers }: {
  prices: PriceHistory | null; events: TradeEvent[]; dividends: DividendFeed | null; preferredTickers: string[];
}) {
  const tickers = Object.keys(prices?.series ?? {}).filter(t => prices!.series[t].length > 0);
  const [ticker, setTicker] = useState(preferredTickers.find(t => tickers.includes(t)) ?? tickers[0] ?? "");
  const series = prices?.series[ticker] ?? [];
  const selected = events.filter(e => e.ticker === ticker);
  const dates = new Set(series.map(p => p.date));
  const missing = selected.filter(e => !dates.has(e.date));
  const selectedDividends = (dividends?.upcoming ?? []).filter(e => e.ticker === ticker);
  const exDates = [...new Set(selectedDividends.map(e => e.ex_date))];
  const unplottedEx = exDates.filter(d => !dates.has(d));
  return <div className="space-y-3">
    <label className="text-sm flex flex-wrap items-center gap-3">Chart ticker
      <select className="rounded p-2 min-h-12" style={{background:"var(--surface-raised)",color:"var(--text-primary)",border:"1px solid var(--border-default)"}} value={ticker} onChange={e=>setTicker(e.target.value)} disabled={!tickers.length}>
        {!tickers.length && <option value="">Price evidence unavailable</option>}
        {tickers.map(t=><option key={t} value={t}>{t}</option>)}
      </select>
    </label>
    <p className="text-xs" style={{color:"var(--text-secondary)"}}>Selected ticker: {ticker || "unknown"} · {selected.length} matching trade events · {exDates.length} matching ex-dates. Other tickers excluded. Close currency / FX provenance unknown; do not read the price line as EUR or execution fills. Day-level event timestamps do not establish intraday fill timing.</p>
    <StrategyChart series={series} selectedTicker={ticker} trades={selected.map(e=>e.action === "BUY" ? {ticker:e.ticker,entry_date:e.date,entry_price_eur:e.price} : {ticker:e.ticker,entry_date:"",exit_date:e.date,exit_price_eur:e.price})} exDivDates={exDates.filter(d=>dates.has(d))} quoteCurrencyUnknown />
    <p className="text-xs" style={{color:"var(--text-secondary)"}}>Unplotted boundaries (no matching session close): {missing.length ? missing.map(e=>`${e.ticker} ${e.action} ${e.date}`).join("; ") : "none among supplied trade events"}. No synthetic closes or nearest-session remapping. {unplottedEx.length ? `Ex-dates outside price evidence: ${unplottedEx.join(", ")}.` : ""} Exchange-session boundaries unknown without a listing calendar receipt.</p>
  </div>;
}
