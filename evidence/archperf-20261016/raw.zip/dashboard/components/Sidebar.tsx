"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import React from "react";
import { STRATEGY_REGISTRY } from "@/lib/strategies";
import { 
  Play, 
  Layers, 
  LineChart, 
  BookOpen, 
  Cpu, 
  LayoutDashboard, 
  Activity,
  Percent,
  TrendingUp,
  Zap,
  BarChart,
  ScanSearch,
  PieChart,
  Gauge,
} from "lucide-react";

// Cockpit: cross-strategy views (the live dashboard, audit + research surfaces).
const COCKPIT_LINKS = [
  { href: "/overview",      label: "Overview",      icon: LayoutDashboard },
  { href: "/operations", label: "Run Registry", icon: Activity },
  { href: "/",              label: "Platform UI",   icon: Activity },
  { href: "/signals",       label: "Signals",       icon: Play },
  { href: "/holdings",      label: "Holdings",      icon: Layers },
  { href: "/equity",        label: "Equity",        icon: LineChart },

  { href: "/performance", label: "Performance", icon: Gauge },
  { href: "/journal",       label: "Journal",       icon: BookOpen },
  { href: "/learning-loop", label: "Learning Loop", icon: Cpu },
];

// Per-strategy: runtime sleeves and explicitly separate research strategies.
const STRATEGY_ICONS = { borgdiv: Percent, borgpea: TrendingUp, momentumb: Zap, claudemomentum: BarChart, "etf-allocation": PieChart };
const STRATEGY_LINKS = [
  ...STRATEGY_REGISTRY.map(({ key, href, label }) => ({ href, label, icon: STRATEGY_ICONS[key] })),
  { href: "/sma150",        label: "SMA150 Research", icon: ScanSearch },
];

interface SidebarProps {
  vix?: number | null;
  live?: boolean;
}

function NavLink({
  href,
  label,
  active,
  icon: Icon,
}: {
  href: string;
  label: string;
  active: boolean;
  icon: React.ComponentType<{ className?: string }>;
}) {
  return (
    <Link
      key={href}
      href={href}
      prefetch={href === "/overview" || href === "/journal"}
      aria-current={active ? "page" : undefined}
      aria-label={label}
      title={label}
      className="sidebar-link min-h-12 md:min-h-0 flex items-center justify-center md:justify-start gap-0 md:gap-2.5 text-sm px-2 md:px-3 py-2 rounded-[4px] transition-colors duration-150"
      style={
        active
          ? {
              color: "var(--borg-accent)",
              background: "var(--borg-accent-subtle)",
              borderLeft: "2px solid var(--borg-accent)",
            }
          : {
              color: "var(--text-muted)",
              borderLeft: "2px solid transparent",
            }
      }
      onMouseEnter={(e) => {
        if (!active) {
          e.currentTarget.style.color = "var(--text-primary)";
          e.currentTarget.style.background = "var(--surface-hover)";
        }
      }}
      onMouseLeave={(e) => {
        if (!active) {
          e.currentTarget.style.color = "var(--text-muted)";
          e.currentTarget.style.background = "";
        }
      }}
    >
      <Icon className="w-4 h-4 shrink-0" />
      <span className="hidden md:inline min-w-0 [overflow-wrap:anywhere]">{label}</span>
    </Link>
  );
}

export default function Sidebar({ vix, live }: SidebarProps) {
  const pathname = usePathname();

  return (
    <aside
      className="w-16 md:w-60 shrink-0 flex flex-col h-dvh sticky top-0"
      style={{
        background: "var(--surface-raised)",
        borderRight: "1px solid var(--border-subtle)",
      }}
    >
      {/* Logo */}
      <div className="px-2 md:px-5 py-5 flex items-center justify-center md:justify-start gap-2">
        <Activity className="w-5 h-5" style={{ color: "var(--borg-accent)" }} />
        <span className="hidden md:inline text-xs font-bold tracking-widest uppercase text-white">
          BorgInvestor
        </span>
      </div>

      {/* Nav links */}
      <div className="flex-1 px-3 flex flex-col gap-0.5 overflow-y-auto">
        <nav aria-label="Cockpit" className="flex flex-col gap-0.5">
        {COCKPIT_LINKS.map(({ href, label, icon }) => (
          <NavLink
            key={href}
            href={href}
            label={label}
            icon={icon}
            active={pathname === href}
          />
        ))}

        </nav>
        {/* Section divider between cockpit and per-strategy nav */}
        <div
          className="hidden md:block px-3 pt-4 pb-1 text-[11px] font-semibold tracking-wider uppercase"
          style={{ color: "var(--text-muted)" }}
        >
          Strategies
        </div>

        <nav aria-label="Strategies" className="flex flex-col gap-0.5">
        {STRATEGY_LINKS.map(({ href, label, icon }) => (
          <NavLink
            key={href}
            href={href}
            label={label}
            icon={icon}
            active={pathname === href}
          />
        ))}
      </nav>

      {/* Footer */}
      </div>
      <div
        className="px-2 md:px-5 py-4 flex items-center justify-center md:justify-start gap-2 text-xs"
        style={{
          borderTop: "1px solid var(--border-subtle)",
          color: "var(--text-muted)",
        }}
      >
        {live ? (
          <>
            <span
              className="w-1.5 h-1.5 rounded-full"
              style={{ background: "var(--gain)" }}
            />
            <span className="hidden md:inline" title="Signal file present; market freshness unknown" style={{ color: "var(--gain)", fontWeight: 600 }}>feed present</span>
          </>
        ) : (
          <>
            <span
              className="w-1.5 h-1.5 rounded-full"
              style={{ background: "var(--text-muted)" }}
            />
            <span className="hidden md:inline" title="Signal input unavailable; process health unknown">feed unknown</span>
          </>
        )}
        {vix != null && (
          <span className="hidden md:inline ml-auto font-mono">VIX {vix.toFixed(1)}</span>
        )}
      </div>
    </aside>
  );
}
