"use client";
import {
  LineChart, Line, XAxis, YAxis, CartesianGrid,
  Tooltip, ResponsiveContainer,
} from "recharts";

/** One series descriptor as written by the equity feed (Plan 02 schema). */
export interface PanelSeries {
  key: string;
  label: string;
  role: "benchmark" | "strategy";
}

/** A single row, flattened to a value map for this panel. */
export interface PanelRow {
  date: string;
  deposited: number;
  /** gross terminal-curve values, keyed by series.key */
  values: Record<string, number>;
  /** net-of-tax values, keyed by series.key (terminal cards) */
  net: Record<string, number>;
}

export interface EquityPanelProps {
  title: string;
  taxLabel: string;
  series: PanelSeries[];
  rows: PanelRow[];
}

/**
 * Per-panel Y domain: scale to THIS panel's own data so each chart fills its
 * frame. A shared domain squashed the lower-valued panel (PEA ~€176k) against a
 * CTO ~€490k ceiling. Within-panel comparison (mine vs Claude vs benchmark) is
 * what matters; cross-panel absolute scale isn't meaningful (different markets +
 * tax), so each panel owns its axis.
 */
function panelYDomain(rows: PanelRow[]): [number, number] {
  let max = 0;
  for (const r of rows) {
    if (r.deposited > max) max = r.deposited;
    for (const v of Object.values(r.values)) if (v > max) max = v;
  }
  const padded = max * 1.05; // headroom so the top curve never kisses the frame
  const tick = 5_000;
  const top = Math.ceil(padded / tick) * tick;
  return [0, top || tick];
}

// EUR formatter lives client-side — functions can't cross the RSC boundary.
const eurFmt = new Intl.NumberFormat("fr-FR", {
  style: "currency",
  currency: "EUR",
  maximumFractionDigits: 0,
});
const fmt = (v: number) => eurFmt.format(v);

/**
 * Role-based stroke palette (Recharts needs literal colors, not CSS vars).
 * Derived from the dashboard theme tokens in app/globals.css:
 *   benchmark -> muted grey-blue, thin  (a reference, not the hero)
 *   strategy  -> accent violet + gain green, full weight (the comparison)
 * All chosen for >=4.5:1 contrast on the #0F0F0F base surface.
 */
const BENCHMARK_STROKE = "#8A93A8"; // muted slate — the "beat this" baseline
const STRATEGY_STROKES = ["#7C6FF7", "#2E9E6B"]; // borg-accent violet, gain green
const DEPOSITED_STROKE = "#52525B"; // dashed neutral — capital paid in

function strokeFor(s: PanelSeries, strategyIndex: number): string {
  if (s.role === "benchmark") return BENCHMARK_STROKE;
  return STRATEGY_STROKES[strategyIndex % STRATEGY_STROKES.length];
}

export default function EquityPanel({
  title, taxLabel, series, rows,
}: EquityPanelProps) {
  const last = rows.length > 0 ? rows[rows.length - 1] : undefined;
  const yDomain = panelYDomain(rows);

  // Stable strategy colour index (benchmark sits outside the strategy palette).
  let strategyCursor = 0;
  const resolved = series.map((s) => {
    const color = strokeFor(s, s.role === "strategy" ? strategyCursor : 0);
    if (s.role === "strategy") strategyCursor += 1;
    return { ...s, color };
  });

  // Recharts consumes a flat row: { date, deposited, <key>: value, ... }
  const chartData = rows.map((r) => ({
    date: r.date,
    deposited: r.deposited,
    ...r.values,
  }));

  const tickEvery = Math.max(1, Math.floor(chartData.length / 8));

  return (
    <section
      className="rounded-[6px] p-6"
      style={{
        background: "var(--surface-raised)",
        border: "1px solid var(--border-subtle)",
      }}
      aria-label={`${title} equity comparison`}
    >
      {/* Panel header */}
      <div className="mb-5 flex items-baseline justify-between gap-4">
        <h2
          className="text-base font-semibold tracking-tight"
          style={{ color: "var(--text-primary)" }}
        >
          {title}
        </h2>
        <span
          className="text-[11px] uppercase tracking-wide"
          style={{ color: "var(--text-muted)" }}
        >
          Net tax {taxLabel}
        </span>
      </div>

      {/* Terminal-value cards (gross + net) per series */}
      <div className="mb-6 grid grid-cols-1 gap-3 sm:grid-cols-3">
        {resolved.map((s) => {
          const gross = last?.values[s.key];
          const net = last?.net[s.key];
          return (
            <div
              key={s.key}
              className="rounded-[6px] p-3"
              style={{
                background: "var(--surface-base)",
                border: `1px solid ${s.color}2E`,
              }}
            >
              <div className="mb-1.5 flex items-center gap-2">
                <span
                  className="h-2.5 w-2.5 shrink-0 rounded-sm"
                  style={{ background: s.color }}
                  aria-hidden="true"
                />
                <p
                  className="text-[11px] uppercase tracking-wide truncate"
                  style={{ color: "var(--text-secondary)" }}
                  title={s.label}
                >
                  {s.label}
                </p>
              </div>
              <p
                className="font-mono text-lg font-semibold"
                style={{ color: s.color }}
              >
                {net != null ? fmt(net) : "—"}
              </p>
              <p
                className="mt-0.5 text-[11px]"
                style={{ color: "var(--text-muted)" }}
              >
                gross {gross != null ? fmt(gross) : "—"}
              </p>
            </div>
          );
        })}
      </div>

      {/* Chart */}
      <ResponsiveContainer width="100%" height={320}>
        <LineChart data={chartData} margin={{ top: 8, right: 16, bottom: 0, left: 0 }}>
          <CartesianGrid strokeDasharray="3 3" stroke="#27272a" />
          <XAxis
            dataKey="date"
            tick={{ fontSize: 11, fill: "#71717a" }}
            tickLine={false}
            axisLine={{ stroke: "#27272a" }}
            interval={tickEvery}
            minTickGap={24}
          />
          <YAxis
            domain={yDomain}
            tick={{ fontSize: 11, fill: "#71717a" }}
            tickLine={false}
            axisLine={false}
            width={56}
            tickFormatter={(v) => `€${((v as number) / 1000).toFixed(0)}k`}
          />
          <Tooltip
            contentStyle={{
              background: "#18181b",
              border: "1px solid #3f3f46",
              borderRadius: 6,
              fontSize: 12,
            }}
            labelStyle={{ color: "#a1a1aa" }}
            formatter={(value, name) => [
              typeof value === "number" ? fmt(value) : String(value),
              String(name),
            ]}
          />

          {/* Deposited capital — dashed neutral reference line (panel-agnostic) */}
          <Line
            type="monotone"
            dataKey="deposited"
            name="Deposited capital"
            stroke={DEPOSITED_STROKE}
            strokeWidth={1.25}
            strokeDasharray="5 4"
            dot={false}
            isAnimationActive={false}
          />

          {/* One line per series — benchmark muted/thin, strategies full weight */}
          {resolved.map((s) => (
            <Line
              key={s.key}
              type="monotone"
              dataKey={s.key}
              name={s.label}
              stroke={s.color}
              strokeWidth={s.role === "benchmark" ? 1.5 : 2.25}
              dot={false}
              isAnimationActive={false}
            />
          ))}
        </LineChart>
      </ResponsiveContainer>

      {/* Legend — labels sourced from the feed, never hardcoded */}
      <ul
        className="mt-5 grid grid-cols-1 gap-2 text-[12px] sm:grid-cols-2"
        style={{ color: "var(--text-secondary)" }}
      >
        {resolved.map((s) => (
          <li key={s.key} className="flex items-center gap-2">
            <span
              className="h-2.5 w-4 shrink-0 rounded-sm"
              style={{ background: s.color }}
              aria-hidden="true"
            />
            <span>
              <b style={{ color: "var(--text-primary)" }}>{s.label}</b>
              {s.role === "benchmark" ? " — buy & hold benchmark" : ""}
            </span>
          </li>
        ))}
        <li className="flex items-center gap-2">
          <span
            className="h-0 w-4 shrink-0"
            style={{ borderTop: `2px dashed ${DEPOSITED_STROKE}` }}
            aria-hidden="true"
          />
          <span>Deposited capital — €10k + €1k/mo paid in</span>
        </li>
      </ul>
    </section>
  );
}
