"use client";

import {
  useReactTable,
  getCoreRowModel,
  getSortedRowModel,
  getFilteredRowModel,
  flexRender,
  type ColumnDef,
  type SortingState,
} from "@tanstack/react-table";
import { useState } from "react";
import {
  Table,
  TableHeader,
  TableBody,
  TableHead,
  TableRow,
  TableCell,
} from "@/components/ui/table";
import SparkLine from "@/components/SparkLine";
import { Search } from "lucide-react";
import { getTickerName } from "@/lib/tickerHelper";

export interface CanonicalHolding {
  isin: string;
  ticker: string;
  name: string;
  qty: number;
  avg_cost_eur: number | null;
  mark_eur: number | null;
  currency: string;
  fx_rate_to_eur: number;
  account_type: "CTO" | "PEA";
  sector: string;
  source: string;
  weight: number;
  market_value_eur: number | null;
  unrealized_pnl_gross: number | null;
  unrealized_pnl_net: number | null;
}

const fmtNum = (val: number | null): string =>
  val == null ? "—" : val.toFixed(2);

const fmtPct = (val: number | null): string =>
  val == null ? "—" : (val * 100).toFixed(1) + "%";

function PnlCell({ value }: { value: number | null }) {
  const color =
    value == null
      ? "var(--text-muted)"
      : value > 0
      ? "var(--gain)"
      : value < 0
      ? "var(--loss)"
      : "var(--text-muted)";
  return (
    <span className="tabular-nums font-mono" style={{ color }}>
      {fmtNum(value)}
    </span>
  );
}

function buildColumns(priceHistory: Record<string, number[]>): ColumnDef<CanonicalHolding>[] {
  return [
    {
      accessorKey: "name",
      header: "Product / Asset",
      cell: ({ row }) => (
        <div className="flex flex-col py-0.5">
          <span className="font-semibold text-[13px] leading-tight" style={{ color: "var(--text-primary)" }}>
            {getTickerName(row.original.ticker, row.original.name)}
          </span>
          <span className="text-[10px] font-mono tracking-wider opacity-60 mt-0.5" style={{ color: "var(--text-muted)" }}>
            {row.original.ticker} · {row.original.isin}
          </span>
        </div>
      ),
    },
    {
      accessorKey: "qty",
      header: () => <span className="w-full text-right block">Qty</span>,
      cell: ({ getValue }) => (
        <span className="tabular-nums font-mono block text-right">
          {(getValue() as number).toFixed(4)}
        </span>
      ),
    },
    {
      accessorKey: "avg_cost_eur",
      header: () => <span className="w-full text-right block">Avg Cost (€)</span>,
      cell: ({ getValue }) => (
        <span className="tabular-nums font-mono block text-right">
          {fmtNum(getValue() as number | null)}
        </span>
      ),
    },
    {
      accessorKey: "mark_eur",
      header: () => <span className="w-full text-right block">Price (€)</span>,
      cell: ({ getValue }) => (
        <span className="tabular-nums font-mono block text-right">
          {fmtNum(getValue() as number | null)}
        </span>
      ),
    },
    {
      accessorKey: "market_value_eur",
      header: () => <span className="w-full text-right block">Value (€)</span>,
      cell: ({ getValue }) => (
        <span className="tabular-nums font-mono block text-right">
          {fmtNum(getValue() as number | null)}
        </span>
      ),
    },
    {
      id: "unrealized_pnl_net",
      accessorKey: "unrealized_pnl_net",
      header: () => <span className="w-full text-right block">P&L Net</span>,
      cell: ({ row }) => {
        const net = row.original.unrealized_pnl_net;
        const cost = row.original.avg_cost_eur;
        const qty = row.original.qty;
        const pct = cost && qty && cost > 0 && net != null
          ? (net / (cost * qty)) * 100
          : null;
        const color = net == null ? "var(--text-muted)" : net > 0 ? "var(--gain)" : net < 0 ? "var(--loss)" : "var(--text-muted)";
        return (
          <div className="text-right tabular-nums font-mono" style={{ color }}>
            <span>{fmtNum(net)}</span>
            {pct != null && (
              <span className="ml-2 text-xs opacity-75">
                ({pct > 0 ? "+" : ""}{pct.toFixed(1)}%)
              </span>
            )}
          </div>
        );
      },
    },
    {
      accessorKey: "weight",
      header: () => <span className="w-full text-right block">Weight</span>,
      cell: ({ getValue }) => (
        <span className="tabular-nums font-mono block text-right">
          {fmtPct(getValue() as number | null)}
        </span>
      ),
    },
    { accessorKey: "account_type", header: "Acct" },
    { accessorKey: "sector", header: "Sector" },
    {
      id: "sparkline",
      header: "7d",
      cell: ({ row }) => {
        const ticker = row.original.ticker;
        const prices = priceHistory[ticker];
        if (!prices || prices.length < 2) {
          return <span style={{ color: "var(--text-muted)" }} className="text-xs">—</span>;
        }
        const positive = prices[prices.length - 1] >= prices[0];
        return <SparkLine data={prices} positive={positive} />;
      },
    },
  ];
}

interface HoldingsTableProps {
  rows: CanonicalHolding[];
  priceHistory?: Record<string, number[]>;
}

export default function HoldingsTable({ rows, priceHistory = {} }: HoldingsTableProps) {
  const [sorting, setSorting] = useState<SortingState>([]);
  const [globalFilter, setGlobalFilter] = useState<string>("");

  const columns = buildColumns(priceHistory);

  const table = useReactTable({
    data: rows,
    columns,
    state: { sorting, globalFilter },
    onSortingChange: setSorting,
    onGlobalFilterChange: setGlobalFilter,
    getCoreRowModel: getCoreRowModel(),
    getSortedRowModel: getSortedRowModel(),
    getFilteredRowModel: getFilteredRowModel(),
  });

  return (
    <>
      <div className="relative mb-6 max-w-sm">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-zinc-500" />
        <input
          value={globalFilter}
          onChange={(e) => setGlobalFilter(e.target.value)}
          placeholder="Filter holdings..."
          aria-label="Filter holdings"
          className="pl-9 pr-4 py-2 rounded text-xs w-full transition-all focus:outline-none focus:ring-1 focus:ring-[var(--borg-accent)]"
          style={{
            background: "var(--surface-raised)",
            border: "1px solid var(--border-subtle)",
            color: "var(--text-primary)",
          }}
        />
      </div>
      <div className="md:hidden mb-2 text-[11px]" style={{ color: "var(--text-muted)" }}>
        Swipe horizontally to view all holding columns.
      </div>
      <div
        className="overflow-x-auto rounded-[6px]"
        role="region"
        aria-label="Holdings table; scroll horizontally on narrow screens"
        tabIndex={0}
        style={{ border: "1px solid var(--border-subtle)" }}
      >
        <Table>
          <TableHeader>
            {table.getHeaderGroups().map((hg) => (
              <TableRow
                key={hg.id}
                style={{ background: "var(--surface-raised)", borderBottom: "1px solid var(--border-subtle)" }}
              >
                {hg.headers.map((h) => (
                  <TableHead
                    key={h.id}
                    onClick={h.column.getToggleSortingHandler()}
                    className="cursor-pointer select-none text-xs uppercase tracking-wide"
                    style={{ color: "var(--text-muted)" }}
                  >
                    {flexRender(h.column.columnDef.header, h.getContext())}
                    {h.column.getIsSorted() === "asc"
                      ? " ▲"
                      : h.column.getIsSorted() === "desc"
                      ? " ▼"
                      : ""}
                  </TableHead>
                ))}
              </TableRow>
            ))}
          </TableHeader>
          <TableBody>
            {table.getRowModel().rows.map((row) => (
              <TableRow
                key={row.id}
                className="transition-colors"
                style={{
                  opacity: row.original.market_value_eur == null ? 0.45 : 1,
                  borderBottom: "1px solid var(--border-subtle)",
                }}
                onMouseEnter={(e) =>
                  (e.currentTarget.style.background = "var(--surface-hover)")
                }
                onMouseLeave={(e) => (e.currentTarget.style.background = "")}
              >
                {row.getVisibleCells().map((cell) => (
                  <TableCell key={cell.id} style={{ color: "var(--text-secondary)" }}>
                    {flexRender(cell.column.columnDef.cell, cell.getContext())}
                  </TableCell>
                ))}
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </div>
    </>
  );
}
