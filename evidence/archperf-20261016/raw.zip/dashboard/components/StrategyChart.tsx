"use client";

/**
 * StrategyChart — Phase-19 event-annotated price chart (REQ-4 / DASH-V2-04).
 *
 * A SINGLE recharts v3 `ComposedChart` holding:
 *   - the price `Line` (close series),
 *   - a `Scatter` series of buy/sell markers bound by date to trade entry/exit rows,
 *   - optional ex-div `ReferenceLine`s,
 *   - a custom `Tooltip` (typed `TooltipContentProps`) that shows trade detail on a
 *     marker and date+close on a plain point.
 *
 * recharts 3.8.1 idioms ONLY (RESEARCH Pattern 2 + Pitfall 2):
 *   - ONE ComposedChart (not overlaid LineChart+ScatterChart).
 *   - Markers render AFTER the Line in JSX so they sit on top (SVG has no z-index).
 *   - Custom tooltip props = `TooltipContentProps` (NOT v2 `TooltipProps`).
 *   - The v2 props removed in v3 (Scatter active-index / points; ReferenceLine
 *     always-show / is-front) are NOT used anywhere in this file — the plan grep
 *     gate over this file must return zero matches for those tokens.
 *
 * Marker binding (RESEARCH Pattern 3): chart rows are built from the price series;
 * for each date matching a trade `entry_date`/`exit_date` we attach `marker`, `trade`
 * and `markerY` (= that day's close) so the dot lands on the line.
 */
import {
  ComposedChart,
  Line,
  Scatter,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ReferenceLine,
  ResponsiveContainer,
  Cell,
  type TooltipContentProps,
} from "recharts";

/** A shadow trade as consumed by the chart for marker placement. */
import { getTickerName } from "@/lib/tickerHelper";

export type StrategyTrade = {
  ticker: string;
  entry_date: string;
  exit_date?: string | null;
  entry_price_eur?: number | null;
  exit_price_eur?: number | null;
  pnl_eur?: number | null;
  pnl_pct?: number | null;
};

type MarkerKind = "BUY" | "SELL" | "MIXED";

/** Trade detail attached to a marker row, surfaced in the tooltip. */
type MarkerTrade = {
  ticker: string;
  price: number | null;
  pnl_eur: number | null;
  pnl_pct: number | null;
};

/** A single chart row: a price point optionally annotated with a marker. */
type ChartRow = {
  date: string;
  close: number;
  marker?: MarkerKind;
  markerY?: number;
  trades?: (MarkerTrade & { kind: Exclude<MarkerKind, "MIXED"> })[];
};

export type StrategyChartProps = {
  /** Ordered close series for the charted ticker(s): [{date, close}]. */
  series: { date: string; close: number }[];
  /** Shadow trades whose entry/exit dates become buy/sell markers. */
  trades: StrategyTrade[];
  /** Optional ex-div dates (BorgDiv) drawn as ReferenceLines. */
  exDivDates?: string[];
  quoteCurrencyUnknown?: boolean;
  selectedTicker?: string;
};

const GAIN = "var(--gain)";
const LOSS = "var(--loss)";
const ACCENT = "var(--borg-accent)";
const TRANSPARENT = "transparent";

const fmtEur = (v: number | null | undefined): string =>
  v == null ? "—" : `€${v.toLocaleString("fr-FR", { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;

const fmtPct = (v: number | null | undefined): string =>
  v == null ? "—" : `${v > 0 ? "+" : ""}${v.toFixed(1)}%`;

/**
 * Build chart rows from the price series, merging trade entry/exit dates into
 * matching rows. A BUY marker is placed on the entry_date, a SELL marker on the
 * exit_date. Missing exact session-close dates remain unplotted; never append
 * synthetic carry-forward closes or move events to a different session.
 * Multiple same-day events are grouped into one tooltip and BUY+SELL days render
 * as a mixed marker.
 */
export function buildChartRows(
  series: { date: string; close: number }[],
  trades: StrategyTrade[],
  selectedTicker?: string,
): ChartRow[] {
  const rows: ChartRow[] = series.map((p) => ({ date: p.date, close: p.close }));
  if (!rows.length) return rows;

  const byDate = new Map<string, ChartRow>();
  for (const r of rows) byDate.set(r.date, r);

  function ensureRow(date: string): ChartRow | undefined {
    // Missing session close is unknown, never a carry-forward invented quote.
    return byDate.get(date);
  }

  function attachMarker(
    row: ChartRow | undefined,
    kind: Exclude<MarkerKind, "MIXED">,
    trade: MarkerTrade,
  ) {
    if (!row) return;
    if (!row.marker) {
      row.marker = kind;
    } else if (row.marker !== kind) {
      row.marker = "MIXED";
    }
    row.markerY = row.close;
    row.trades = [...(row.trades ?? []), { ...trade, kind }];
  }

  for (const t of trades) {
    if (selectedTicker && t.ticker !== selectedTicker) continue;
    attachMarker(
      ensureRow(t.entry_date),
      "BUY",
      {
        ticker: t.ticker,
        price: t.entry_price_eur ?? null,
        pnl_eur: null,
        pnl_pct: null,
      },
    );
    if (t.exit_date) {
      attachMarker(
        ensureRow(t.exit_date),
        "SELL",
        {
          ticker: t.ticker,
          price: t.exit_price_eur ?? null,
          pnl_eur: t.pnl_eur ?? null,
          pnl_pct: t.pnl_pct ?? null,
        },
      );
    }
  }

  return rows;
}

/**
 * Custom tooltip content — v3 props are `TooltipContentProps` (NOT v2 `TooltipProps`).
 * Rendered via the function form of `Tooltip.content` so TS validates against the
 * `(props: TooltipContentProps) => ReactNode` signature (recharts injects all props
 * at runtime; the ReactElement form would demand them at the JSX call site).
 */
function TradeTooltip({ active, payload, label, quoteCurrencyUnknown = false }: TooltipContentProps & { quoteCurrencyUnknown?: boolean }) {
  if (!active || !payload || payload.length === 0) return null;
  // The chart row is carried on the entry payload object.
  const row = payload[0]?.payload as ChartRow | undefined;
  if (!row) return null;

  const dateLabel = typeof label === "string" || typeof label === "number" ? String(label) : row.date;

  return (
    <div
      className="rounded text-xs"
      style={{
        background: "var(--surface-overlay)",
        border: "1px solid var(--border-default)",
        padding: "8px 10px",
        color: "var(--text-secondary)",
        minWidth: 140,
      }}
    >
      <div className="font-mono" style={{ color: "var(--text-primary)" }}>
        {dateLabel}
      </div>
      {row.marker && row.trades?.length ? (
        <>
          <div
            className="mt-1 font-semibold"
            style={{
              color:
                row.marker === "BUY"
                  ? "var(--gain)"
                  : row.marker === "SELL"
                    ? "var(--loss)"
                    : "var(--borg-accent)",
            }}
          >
            {row.marker === "MIXED" ? "BUY/SELL" : row.marker} events
          </div>
          {row.trades.slice(0, 6).map((trade, idx) => (
            <div key={`${trade.kind}-${trade.ticker}-${idx}`} className="mt-1">
              <span style={{ color: trade.kind === "BUY" ? "var(--gain)" : "var(--loss)" }}>
                {trade.kind}
              </span>{" "}
              <span className="text-xs font-semibold">{getTickerName(trade.ticker)}</span> <span className="font-mono text-[10px] opacity-60">({trade.ticker})</span>
              <div className="mt-0.5">reported event price {quoteCurrencyUnknown ? (trade.price == null ? "—" : `${trade.price.toLocaleString("fr-FR")} (currency unknown)`) : fmtEur(trade.price)}</div>
              {trade.pnl_eur != null && (
                <div
                  className="mt-0.5 tabular-nums font-mono"
                  style={{ color: trade.pnl_eur >= 0 ? "var(--gain)" : "var(--loss)" }}
                >
                  P&amp;L {fmtEur(trade.pnl_eur)} ({fmtPct(trade.pnl_pct)})
                </div>
              )}
            </div>
          ))}
          {row.trades.length > 6 && (
            <div className="mt-1" style={{ color: "var(--text-muted)" }}>
              +{row.trades.length - 6} more events
            </div>
          )}
          <div className="mt-1" style={{ color: "var(--text-muted)" }}>
            marker plotted on selected price line
          </div>
        </>
      ) : (
        <div className="mt-1 tabular-nums font-mono">close {quoteCurrencyUnknown ? `${row.close.toLocaleString("fr-FR")} (currency unknown)` : fmtEur(row.close)}</div>
      )}
    </div>
  );
}

export default function StrategyChart({ series, trades, exDivDates = [], quoteCurrencyUnknown = false, selectedTicker }: StrategyChartProps) {
  const rows = buildChartRows(series, trades, selectedTicker);
  const markers = rows.filter(row => row.marker);

  if (!rows.length) {
    return (
      <div
        className="flex items-center justify-center rounded-[6px] text-sm"
        style={{
          height: 340,
          border: "1px solid var(--border-subtle)",
          background: "var(--surface-raised)",
          color: "var(--text-muted)",
        }}
      >
        No price history available for this strategy.
      </div>
    );
  }

  return (
    <ResponsiveContainer width="100%" height={340}>
      <ComposedChart data={rows} margin={{ top: 8, right: 16, bottom: 0, left: 0 }}>
        <CartesianGrid strokeDasharray="3 3" stroke="#27272a" />
        <XAxis
          dataKey="date"
          tick={{ fontSize: 11, fill: "var(--text-muted)" }}
          tickLine={false}
          minTickGap={32}
        />
        <YAxis
          tick={{ fontSize: 11, fill: "var(--text-muted)" }}
          axisLine={false}
          tickLine={false}
          domain={["auto", "auto"]}
          tickFormatter={(v) => `${quoteCurrencyUnknown ? "" : "€"}${(v as number).toLocaleString("fr-FR")}`}
        />
        {/* ex-div markers: a plain ReferenceLine per date (v3 idiom; no v2-removed props). */}
        {exDivDates.map((d) => (
          <ReferenceLine key={d} x={d} stroke={ACCENT} strokeDasharray="4 2" />
        ))}
        {/* Line first… */}
        <Line
          type="monotone"
          dataKey="close"
          stroke={GAIN}
          strokeWidth={2}
          dot={false}
          isAnimationActive={false}
        />
        {/* …then Scatter so markers render on top (SVG render-order = z-order). */}
        {markers.length > 0 && <Scatter data={markers} dataKey="markerY" shape="circle" isAnimationActive={false}>
          {markers.map((r, i) => (
            <Cell
              key={i}
              fill={
                r.marker === "BUY"
                  ? GAIN
                  : r.marker === "SELL"
                    ? LOSS
                    : r.marker === "MIXED"
                      ? ACCENT
                      : TRANSPARENT
              }
            />
          ))}
        </Scatter>}
        <Tooltip content={(props) => <TradeTooltip {...props} quoteCurrencyUnknown={quoteCurrencyUnknown} />} cursor={{ stroke: "var(--border-default)" }} />
      </ComposedChart>
    </ResponsiveContainer>
  );
}
