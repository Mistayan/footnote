import Card from "@/components/ui-patterns/Card";
import type { EquityFeed, KpiFeed, StrategyKpis } from "@/lib/feeds";
import KpiProvenance from "./KpiProvenance";

const fmtEur = (v?: number | null): string =>
  v == null ? "—" : `€${v.toLocaleString("en-EU", { maximumFractionDigits: 0 })}`;
const fmtSignedPct = (v?: number | null, digits = 1): string =>
  v == null ? "—" : `${v >= 0 ? "+" : "−"}${Math.abs(v).toFixed(digits)}%`;
const fmtSignedEur = (v?: number | null): string =>
  v == null ? "—" : `${v >= 0 ? "+" : "−"}€${Math.abs(v).toLocaleString("en-EU", { maximumFractionDigits: 0 })}`;
const pnlColor = (v?: number | null): string =>
  v == null ? "var(--text-muted)" : v > 0 ? "var(--gain)" : v < 0 ? "var(--loss)" : "var(--text-muted)";

function sectionHeader(label: string, title: string, subtitle: string) {
  return (
    <div className="mb-4 flex flex-col gap-1">
      <span className="text-[11px] font-semibold uppercase tracking-widest" style={{ color: "var(--borg-accent)" }}>
        {label}
      </span>
      <h2 className="text-lg font-semibold" style={{ color: "var(--text-primary)" }}>
        {title}
      </h2>
      <p className="max-w-4xl text-sm" style={{ color: "var(--text-secondary)" }}>
        {subtitle}
      </p>
    </div>
  );
}

function MetricTile({ label, value, tone }: { label: string; value: string; tone?: "gain" | "loss" }) {
  const color = tone === "gain" ? "var(--gain)" : tone === "loss" ? "var(--loss)" : "var(--text-primary)";
  return (
    <div className="min-w-0 rounded-[6px] px-3 py-2" style={{ background: "var(--surface-overlay)" }}>
      <div className="text-[10px] uppercase tracking-widest" style={{ color: "var(--text-muted)" }}>
        {label}
      </div>
      <div className="mt-1 break-words font-mono text-sm font-semibold tabular-nums" style={{ color }}>
        {value}
      </div>
    </div>
  );
}

function strategyGroup(kpis: KpiFeed | null, keys: string[]): StrategyKpis[] {
  return keys.map((key) => kpis?.per_strategy?.[key]).filter((v): v is StrategyKpis => Boolean(v));
}

function combineShadow(kpis: KpiFeed | null, keys: string[]) {
  const rows = strategyGroup(kpis, keys);
  if (rows.length !== keys.length) return null;
  const safeAccounting = kpis?.basis === "original_fills_current_policy_diagnostic" || kpis?.basis === "fixed_20k_original_fills_no_monthly_deposits";
  const book = rows.every(r => r.book_value_eur != null) ? rows.reduce((sum, r) => sum + r.book_value_eur!, 0) : null;
  const pnl = safeAccounting && rows.every(r => r.net_pnl_eur != null) ? rows.reduce((sum, r) => sum + r.net_pnl_eur!, 0) : null;
  const current = safeAccounting && rows.every(r => r.current_value_eur != null) ? rows.reduce((sum, r) => sum + r.current_value_eur!, 0) : null;
  const closed = rows.every(r => r.closed_trades_count != null) ? rows.reduce((sum, r) => sum + r.closed_trades_count!, 0) : null;
  const open = rows.every(r => r.open_positions_count != null) ? rows.reduce((sum, r) => sum + r.open_positions_count!, 0) : null;
  const minStart = rows.map((r) => r.shadow_start_date).filter(Boolean).sort()[0] ?? null;
  const maxDays = Math.max(...rows.map((r) => r.shadow_day_count ?? 0));
  // Portfolio risk needs a synchronized NAV history; sleeve trade statistics
  // cannot be averaged or minimized into portfolio Sharpe/drawdown.
  return { book, pnl, current, closed, open, minStart, maxDays };
}

function ShadowEvidenceCard({ title, kpis, keys, benchmark }: { title: string; kpis: KpiFeed | null; keys: string[]; benchmark: string }) {
  const shadow = combineShadow(kpis, keys);
  const returnPct = shadow && shadow.pnl != null && shadow.book != null && shadow.book > 0 ? (shadow.pnl / shadow.book) * 100 : null;

  return (
    <Card className="flex flex-col gap-4" aria-label={title}>
      <div className="flex items-start justify-between gap-4">
        <div>
          <h3 className="text-base font-semibold" style={{ color: "var(--text-primary)" }}>
            {title}
          </h3>
          <p className="mt-1 text-xs" style={{ color: "var(--text-muted)" }}>
            Shadow book diagnostic · benchmark context only: {benchmark}
          </p>
        </div>
        <span className="rounded-[3px] px-2 py-1 text-[10px] uppercase tracking-widest" style={{ background: "var(--surface-overlay)", color: "var(--text-secondary)" }}>
          freshness unknown
        </span>
      </div>
      {kpis && keys.map(key => kpis.per_strategy[key]
        ? <KpiProvenance key={key} evidence={kpis.per_strategy[key]} />
        : <p key={key} className="text-xs" style={{ color: "var(--text-muted)" }}>Missing sleeve evidence: {key} — combined valuation unknown.</p>)}
      <div className="grid grid-cols-1 gap-2 sm:grid-cols-2 xl:grid-cols-5">
        <MetricTile label="Return / fixed book" value={fmtSignedPct(returnPct)} tone={returnPct != null && returnPct >= 0 ? "gain" : "loss"} />
        <MetricTile label="Net P&L" value={fmtSignedEur(shadow?.pnl)} tone={shadow?.pnl != null && shadow.pnl >= 0 ? "gain" : "loss"} />
        <MetricTile label="Value" value={fmtEur(shadow?.current)} />
        <MetricTile label="Portfolio Sharpe" value="—" />
        <MetricTile label="Portfolio Max DD" value="—" />
      </div>
      <p className="text-xs" style={{ color: "var(--text-muted)" }}>
        Portfolio Sharpe and drawdown require synchronized daily NAV history.
      </p>
      <p className="text-xs" style={{ color: "var(--text-muted)" }}>
        {shadow ? `${shadow.open ?? "—"} open · ${shadow.closed ?? "—"} closed · shadow since ${shadow.minStart ?? "—"} · ${shadow.maxDays}/90 days.` : "No shadow KPI feed yet."}
      </p>
    </Card>
  );
}

export default function PerformanceEvidence({
  kpis,
}: {
  kpis: KpiFeed | null;
  equity: EquityFeed | null;
}) {
  return (
    <section className="mb-10">
      {sectionHeader(
        "evidence split",
        "Historical Backtest vs Shadow Book Evidence",
        "Backtest curves and shadow book diagnostics have different profiles and windows; neither certifies current freshness or canonical comparison.",
      )}

      <Card className="space-y-2">
        <h3 className="font-semibold">Normalized €20,000 + €1,000 monthly — BLOCKED</h3>
        <p className="text-sm">No certified full-roster COMPARISON_V1 replay: matched deposits, common strategy/benchmark/FX window, costs and tax lane must be evidenced. Cohort and replay dates unknown. No ranking or promotion.</p>
        <p className="text-sm">Historical public equity curves and June LRT metrics withheld: profile/window and dedicated strategy lineage are unverified, not normalized proof.</p>
      </Card>

      <div className="my-8 h-px w-full" style={{ background: "var(--border-default)" }} />

      {sectionHeader(
        "shadow book evidence",
        "Snapshot Performance / Benchmark Context",
        "These values use shadow fills and unverified marks, not current certified prices. Historical restatements retain their input date. They are not blended into backtest proof.",
      )}
      <div className="grid grid-cols-1 gap-4 xl:grid-cols-2">
        <ShadowEvidenceCard title="PEA Sleeve" kpis={kpis} keys={["borgpea"]} benchmark="CW8.PA / MSCI World" />
        <ShadowEvidenceCard title="CTO Sleeve" kpis={kpis} keys={["borgdiv", "momentumb", "claudemomentum"]} benchmark="SP5.PA / S&P 500" />
      </div>
    </section>
  );
}
