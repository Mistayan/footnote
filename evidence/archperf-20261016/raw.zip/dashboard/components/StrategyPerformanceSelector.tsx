"use client";

import { usePathname, useRouter, useSearchParams } from "next/navigation";
import EquityPanel, { type PanelRow, type PanelSeries } from "@/components/EquityPanel";
import EtfAllocationChart from "@/components/EtfAllocationChart";
import EtfStrategyMethodology from "@/components/EtfStrategyMethodology";
import { STRATEGY_REGISTRY, stratLabel } from "@/lib/strategies";
import type { EtfAllocationFeed } from "@/lib/feeds";

type Panel = { key: string; title: string; taxLabel: string; series: PanelSeries[]; rows: PanelRow[] };
export default function StrategyPerformanceSelector({ panels, etf }: { panels: Panel[]; etf: EtfAllocationFeed | null }) {
  const search = useSearchParams();
  const router = useRouter();
  const pathname = usePathname();
  const requested = search.get("strategy") ?? "all";
  const selected = STRATEGY_REGISTRY.some(strategy => strategy.key === requested) ? requested : "all";
  const visible = panels.filter(panel => selected === "all" || panel.series.some(series => series.key === selected));
  return (
    <div className="min-w-0 space-y-6">
      <div>
        <label htmlFor="strategy-performance" className="block text-sm mb-2" style={{ color: "var(--text-secondary)" }}>Strategy performance</label>
        <select id="strategy-performance" value={selected} className="w-full sm:w-auto max-w-full min-h-12 rounded px-3 text-sm" style={{ background: "var(--surface-raised)", color: "var(--text-primary)", border: "1px solid var(--border-subtle)" }} onChange={event => {
          const params = new URLSearchParams(search.toString());
          if (event.target.value === "all") params.delete("strategy"); else params.set("strategy", event.target.value);
          router.replace(`${pathname}${params.size ? `?${params}` : ""}`, { scroll: false });
        }}>
          <option value="all">Existing equity feed panels</option>
          {STRATEGY_REGISTRY.map(strategy => <option key={strategy.key} value={strategy.key}>{strategy.label}{strategy.runtimeLedger ? "" : " — separate DCA research"}</option>)}
        </select>
      </div>
      {selected === "etf-allocation" ? <>
        <EtfStrategyMethodology feed={etf} />
        {etf ? <EtfAllocationChart feed={etf} /> : <p>No ETF allocation feed yet. Run uv run python -m simulator.main etf-allocation-backtest.</p>}
      </> : <>
        <p className="text-sm" style={{ color: "var(--text-secondary)" }}>Existing feed panels only. ETF Allocation is excluded: its contribution path and history differ. Presence here does not certify standard fixed-capital comparison eligibility.</p>
        <p className="text-xs" style={{ color: "var(--text-muted)" }}>Gross panel values are pre-fee and pre-slippage. PEA net assumes ≥5 years (17.2% social charges); CTO net uses 30% PFU. Past backtests do not guarantee future performance.</p>
        {visible.length ? visible.map(panel => <EquityPanel key={panel.key} title={panel.title} taxLabel={panel.taxLabel} rows={panel.rows} series={panel.series.filter(series => selected === "all" || series.role === "benchmark" || series.key === selected)} />) : <p style={{ color: "var(--text-secondary)" }}>No equity series published for {stratLabel(selected)}.</p>}
      </>}
    </div>
  );
}
