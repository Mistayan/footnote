/**
 * OverviewCards — global cockpit headline (REQ-2).
 * Render-only: every value is read straight from the tested kpis.json
 * (blended + per_strategy). No KPI recompute in JS (CONTEXT lock) — the only
 * arithmetic here is presentation (bar widths from already-computed € values).
 *
 *   - Current value + net P&L ← book + realized + unrealized
 *   - Per-strategy contribution ← each per_strategy[s].net_pnl_eur
 *   - Allocation ← invested value, cash, and yield-parked cash
 *   - Signal pressure (buy:sell) ← blended.signal_pressure
 *
 * null/absent → "—", never a fake 0-as-real (T-19-13).
 */
import type { KpiFeed } from "@/lib/feeds";
import KpiProvenance from "./KpiProvenance";
import { KpiTile, Card } from "@/components/ui-patterns";
import styles from './OverviewCards.module.css';

const STRAT_LABEL: Record<string, string> = {
  borgdiv: "BorgDiv",
  borgpea: "BorgPEA",
  momentumb: "MomentumB",
  claudemomentum: "Claude Momentum",
};
// Strategy palette → --strat-* tokens (25-01, muted gold family — no neon).
const STRAT_COLOR: Record<string, string> = {
  borgdiv: "var(--strat-borgdiv)",
  borgpea: "var(--strat-borgpea)",
  momentumb: "var(--strat-momentumb)",
  claudemomentum: "var(--strat-claudemomentum)",
};

const fmtEur = (v?: number | null): string =>
  v == null ? "—" : `€${v.toLocaleString("en-EU", { maximumFractionDigits: 0 })}`;
const fmtPnl = (v?: number | null): string =>
  v == null
    ? "—"
    : `${v >= 0 ? "+" : "−"}€${Math.abs(v).toLocaleString("en-EU", { maximumFractionDigits: 0 })}`;
const fmtInt = (v?: number | null): string =>
  v == null ? "—" : v.toLocaleString("en-EU", { maximumFractionDigits: 0 });
/** Signed return % on a cost basis. Presentation-only ratio of two computed € fields. */
const fmtReturnPct = (pnl?: number | null, basis?: number | null): string => {
  if (pnl == null || basis == null || Math.abs(basis) < 1) return "—";
  const p = (pnl / Math.abs(basis)) * 100;
  return `${p >= 0 ? "+" : "−"}${Math.abs(p).toFixed(1)}%`;
};
const pnlColor = (v?: number | null): string =>
  v == null ? "var(--text-muted)" : v > 0 ? "var(--gain)" : v < 0 ? "var(--loss)" : "var(--text-muted)";

export default function OverviewCards({ kpis }: { kpis: KpiFeed | null }) {
  if (!kpis) {
    return (
      <section className="mb-8">
        <div
          className="rounded-[6px] p-8 text-sm text-center"
          style={{
            background: "var(--surface-raised)",
            border: "1px solid var(--border-subtle)",
            color: "var(--text-muted)",
          }}
        >
          No KPI data yet — run the feed writer (kpis.json absent).
        </div>
      </section>
    );
  }

  const { blended, per_strategy } = kpis;
  const safeAccounting = kpis.basis === "original_fills_current_policy_diagnostic" || kpis.basis === "fixed_20k_original_fills_no_monthly_deposits";
  const blendedPnl = safeAccounting ? blended.net_pnl_eur : null;
  const currentValue = safeAccounting ? blended.current_value_eur : null;
  const bookValue = blended.book_value_eur;

  // Presentation only: bar fills from already-computed € magnitudes (not a KPI recompute).
  const invested = blended.invested_value_eur;
  const cash = safeAccounting ? blended.cash_eur : null;
  const yieldParked = blended.yield_parked_eur;
  const allocationKnown = invested != null && cash != null && currentValue != null && bookValue != null && blendedPnl != null
    && Math.abs(invested + cash - currentValue) <= 0.025
    && Math.abs(bookValue + blendedPnl - currentValue) <= 0.025;
  const allocationBase = Math.max(1, Math.abs(invested ?? 0) + Math.abs(cash ?? 0));
  const investedPct = allocationKnown ? Math.min(100, (Math.abs(invested) / allocationBase) * 100) : 0;
  const cashPct = allocationKnown ? Math.min(100, (Math.abs(cash) / allocationBase) * 100) : 0;


  const stratKeys = Object.keys(per_strategy);
  // Contribution bar scale: largest absolute strategy P&L = full width (display only).
  // totalAbsPnl = denominator for each strategy's share-of-P&L % (presentation-only).
  const contributionsKnown = safeAccounting && stratKeys.length === 4 && stratKeys.every(k => per_strategy[k]?.net_pnl_eur != null);
  let maxAbs = 0;
  let totalAbsPnl = 0;
  for (const k of stratKeys) {
    const a = safeAccounting ? Math.abs(per_strategy[k]?.net_pnl_eur ?? 0) : 0;
    if (a > maxAbs) maxAbs = a;
    totalAbsPnl += a;
  }

  const pressure = blended.signal_pressure;
  const shadowDays = blended.shadow_day_count ?? 0;
  const targetDays = blended.target_days ?? 90;
  const progress = Math.min(100, Math.max(0, (blended.target_progress ?? 0) * 100));

  return (
    <section className={styles.grid}>
      <div className={styles.full}><KpiProvenance evidence={{ ...kpis, ...blended, input_generated_at: kpis.input_generated_at ?? kpis.generated_at }} /></div>
      {!safeAccounting && <p className={`text-xs ${styles.full}`} style={{ color: "var(--text-secondary)" }}>Legacy accounting unverified — net valuation and cash withheld pending safe feed publication.</p>}
      {/* Current value + net P&L */}
      <Card>
        <span
          className="text-[11px] uppercase tracking-widest font-semibold mb-3 block"
          style={{ color: "var(--text-muted)" }}
        >
          Book Valuation / Net P&L
        </span>
        <KpiTile
          label={fmtEur(currentValue)}
          value={`${fmtPnl(blendedPnl)} (${fmtReturnPct(blendedPnl, bookValue)})`}
          sub={`book ${fmtEur(bookValue)} · realized ${fmtPnl(blended.realized_pnl_eur)} · unrealized ${fmtPnl(blended.unrealized_eur)} · recorded yield ${fmtEur(yieldParked)} · tax reserve ${fmtEur(blended.tax_reserve_eur !== undefined ? blended.tax_reserve_eur : blended.tax_eur)}`}
          tone={blendedPnl == null ? "neutral" : blendedPnl > 0 ? "gain" : blendedPnl < 0 ? "loss" : "neutral"}
        />
        <p className="text-xs" style={{ color: "var(--text-secondary)" }}>Dividend entitlement estimate (unverified): {fmtEur(blended.dividend_earned_entitlement_estimate_eur !== undefined ? blended.dividend_earned_entitlement_estimate_eur : blended.dividend_captured_eur)} · paid unknown · excluded from net P&amp;L</p>
      </Card>

      {/* Allocation */}
      <Card>
        <span
          className="text-[11px] uppercase tracking-widest font-semibold mb-3 block"
          style={{ color: "var(--text-muted)" }}
        >
          Snapshot Allocation (marks unverified)
        </span>
        <div className="flex items-baseline gap-2">
          <span
            className="text-xl font-semibold tabular-nums"
            style={{ fontFamily: "var(--font-mono, monospace)", color: "var(--text-primary)" }}
          >
            {fmtEur(invested)}
          </span>
          <span className="text-[11px]" style={{ color: "var(--text-muted)" }}>
            invested value
          </span>
        </div>
        <div
          className="h-2 w-full rounded-full overflow-hidden flex"
          style={{ background: "var(--border-subtle)" }}
        >
          <div
            className="h-full"
            style={{ width: `${investedPct}%`, background: "var(--borg-accent)" }}
          />
          <div
            className="h-full"
            style={{ width: `${cashPct}%`, background: cash != null && cash < 0 ? "var(--loss)" : "var(--text-muted)" }}
          />

        </div>
        <div className="grid grid-cols-3 gap-2 text-[11px]" style={{ color: "var(--text-muted)" }}>
          <span>cash {fmtPnl(cash)}</span>
          <span>yield {fmtEur(yieldParked)} included in signed cash</span>
          <span>book {fmtEur(bookValue)}</span>
        </div>
        <p className="text-xs" style={{ color: "var(--text-secondary)" }}>{allocationKnown ? "Allocation reconciles: invested + signed cash = net book valuation = fixed book + net P&L. Tax reserve is already deducted from signed cash." : "Allocation unknown / unreconciled — proportions withheld."} Bars show absolute exposure magnitudes, not positive funding weights; negative cash is borrowing. Recorded yield is not an additional asset.</p>
      </Card>

      {/* Shadow run counter */}
      <Card>
        <span
          className="text-[11px] uppercase tracking-widest font-semibold mb-3 block"
          style={{ color: "var(--text-muted)" }}
        >
          Shadow Run
        </span>
        <div className="flex items-baseline gap-2">
          <span
            className="text-xl font-semibold tabular-nums"
            style={{ fontFamily: "var(--font-mono, monospace)", color: "var(--text-primary)" }}
          >
            {fmtInt(shadowDays)}
          </span>
          <span className="text-[11px]" style={{ color: "var(--text-muted)" }}>
            / {fmtInt(targetDays)} days
          </span>
        </div>
        <div
          className="h-2 w-full rounded-full overflow-hidden"
          style={{ background: "var(--border-subtle)" }}
        >
          <div
            className="h-full rounded-full"
            style={{ width: `${progress}%`, background: "var(--borg-accent)" }}
          />
        </div>
        <span className="text-[11px]" style={{ color: "var(--text-muted)" }}>
          since {blended.shadow_start_date ?? "—"} · {progress.toFixed(0)}% of target
        </span>
      </Card>

      {/* Signal pressure */}
      <Card>
        <span
          className="text-[11px] uppercase tracking-widest font-semibold mb-3 block"
          style={{ color: "var(--text-muted)" }}
        >
          Signal Pressure (buy:sell)
        </span>
        <div className="flex items-baseline gap-3">
          <span className="text-xl font-semibold tabular-nums" style={{ color: "var(--gain)" }}>
            {pressure?.buy ?? "—"}
          </span>
          <span className="text-sm" style={{ color: "var(--text-muted)" }}>
            :
          </span>
          <span className="text-xl font-semibold tabular-nums" style={{ color: "var(--loss)" }}>
            {pressure?.sell ?? "—"}
          </span>
          {pressure != null && (
            <span
              className="ml-auto text-[11px] tabular-nums"
              style={{ color: "var(--text-muted)" }}
            >
              ratio {pressure.ratio.toFixed(2)}
            </span>
          )}
        </div>
        <span className="text-[11px]" style={{ color: "var(--text-muted)" }}>
          BUY vs SELL intents this window
        </span>
      </Card>

      {/* Per-strategy contribution (spans full width) */}
      <div className={styles.full}>
        <Card>
          <span
            className="text-[11px] uppercase tracking-widest font-semibold mb-3 block"
            style={{ color: "var(--text-muted)" }}
          >
            Per-Strategy Contribution
          </span>
          <div className="flex flex-col gap-3">
            {stratKeys.map((k) => {
              const v = safeAccounting ? per_strategy[k]?.net_pnl_eur ?? null : null;
              const w = maxAbs > 0 && v != null ? (Math.abs(v) / maxAbs) * 100 : 0;
              // Share of total P&L magnitude across strategies (presentation-only).
              const sharePct =
                contributionsKnown && totalAbsPnl > 0 && v != null
                  ? `${((Math.abs(v) / totalAbsPnl) * 100).toFixed(0)}%`
                  : "—";
              return (
                <div key={k} className="flex items-center gap-3">
                  <span
                    className="text-xs w-24 shrink-0"
                    style={{ color: "var(--text-secondary)" }}
                  >
                    {STRAT_LABEL[k] ?? k}
                  </span>
                  <div
                    className="h-2 flex-1 rounded-full overflow-hidden"
                    style={{ background: "var(--border-subtle)" }}
                  >
                    <div
                      className="h-full rounded-full"
                      style={{ width: `${w}%`, background: STRAT_COLOR[k] ?? "var(--borg-accent)" }}
                    />
                  </div>
                  <span
                    className="text-xs tabular-nums font-mono w-32 text-right shrink-0"
                    style={{ color: pnlColor(v) }}
                  >
                    {fmtPnl(v)}{" "}
                    <span style={{ color: "var(--text-muted)" }}>({sharePct})</span>
                  </span>
                </div>
              );
            })}
          </div>
        </Card>
      </div>
    </section>
  );
}
