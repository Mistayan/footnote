import styles from './SectionNavigation.module.css';

/** Local task shortcuts: native links preserve browser Back and keyboard focus. */
export default function SectionNavigation({label,items}:{label:string;items:readonly {href:string;label:string}[]}) {
  return <nav aria-label={label} className={styles.navigation}>
    <span className={styles.label}>On this page</span>
    {items.map(item=><a key={item.href} href={item.href}>{item.label}</a>)}
  </nav>;
}
