"use client";

import {
  CartesianGrid,
  Line,
  LineChart,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";
import type { EtfAllocationFeed } from "@/lib/feeds";
import { etfTaxPresentation, etfFeedStatus } from "@/lib/etf-metadata";

const eurFmt = new Intl.NumberFormat("fr-FR", {
  style: "currency",
  currency: "EUR",
  maximumFractionDigits: 0,
});
const fmtEur = (value: number) => eurFmt.format(value);
const fmtPct = (value: number) => `${value >= 0 ? "+" : "−"}${Math.abs(value).toFixed(1)}%`;

function downsample(rows: EtfAllocationFeed["series"], target = 320) {
  const step = Math.max(1, Math.floor(rows.length / target));
  return rows.filter((_, index) => index % step === 0 || index === rows.length - 1);
}

export default function EtfAllocationChart({ feed }: { feed: EtfAllocationFeed }) {
  const last = feed.series[feed.series.length - 1];
  const data = downsample(feed.series);
  const gainColor = feed.gain_eur >= 0 ? "var(--gain)" : "var(--loss)";
  const protocol = feed.protocol ?? "Protocol not published";
  const verdict = feed.verdict ?? "NOT_VALIDATED";
  const limitations = feed.limitations ?? ["Feed predates the protocol manifest; regenerate the backtest."];
  const tax = etfTaxPresentation(feed.tax_model, limitations, feed.assumptions ?? []);
  const benchmark = feed.benchmark ?? {
    ticker: "not published",
    final_value_eur: 0,
    net_value_after_tax_eur: 0,
    costs_eur: 0,
    tax_eur: 0,
    relative_gain_eur: 0,
    relative_return_pct: 0,
  };

  return (
    <div className="space-y-6">
      <div
        className="rounded-[6px] px-4 py-3 text-xs"
        style={{ background: "var(--borg-accent-subtle)", border: "1px solid var(--borg-accent-border)", color: "var(--text-secondary)" }}
      >
        <span className="font-mono font-semibold" style={{ color: "var(--borg-accent)" }}>{protocol}</span>
        <span className="mx-2">·</span>
        {feed.account_type ?? "Account not published"} · Published historical verdict: {verdict.replaceAll("_", " ")} — not current certification.
        <p className="mt-2">{etfFeedStatus(feed.generated_at, feed.history_end)}</p>
      </div>
      <div className="grid grid-cols-2 gap-3 lg:grid-cols-5">
        {[
          ["Final value", fmtEur(feed.final_value_eur)],
          ["Contributed", fmtEur(feed.total_contributed_eur)],
          ["Gain", fmtEur(feed.gain_eur)],
          ["DCA return", fmtPct(feed.return_pct)],
          ["Max drawdown", `−${feed.max_drawdown_pct.toFixed(1)}%`],
        ].map(([label, value]) => (
          <div
            key={label}
            className="rounded-[6px] p-4"
            style={{ background: "var(--surface-raised)", border: "1px solid var(--border-subtle)" }}
          >
            <p className="text-[10px] uppercase tracking-widest" style={{ color: "var(--text-muted)" }}>
              {label}
            </p>
            <p className="mt-2 font-mono text-lg font-semibold" style={{ color: label === "Gain" ? gainColor : "var(--text-primary)" }}>
              {value}
            </p>
          </div>
        ))}
      </div>

      <div
        className="flex flex-wrap items-baseline justify-between gap-3 rounded-[6px] px-4 py-3 text-xs"
        style={{ background: "var(--surface-raised)", border: "1px solid var(--border-subtle)", color: "var(--text-secondary)" }}
      >
        <span>
          Matched benchmark <span className="font-mono font-semibold" style={{ color: "var(--text-primary)" }}>{benchmark.ticker}</span>:
          <span className="ml-2 font-mono" style={{ color: "var(--text-primary)" }}>{benchmark.final_value_eur ? fmtEur(benchmark.final_value_eur) : "—"}</span>
        </span>
        <span className="font-mono" style={{ color: benchmark.relative_gain_eur >= 0 ? "var(--gain)" : "var(--loss)" }}>
          allocation relative gain {benchmark.final_value_eur ? `${benchmark.relative_gain_eur >= 0 ? "+" : "−"}${fmtEur(Math.abs(benchmark.relative_gain_eur))} · ${benchmark.relative_return_pct >= 0 ? "+" : "−"}${Math.abs(benchmark.relative_return_pct).toFixed(1)}pp` : "—"}
        </span>
      </div>

      <div className="flex flex-wrap gap-x-6 gap-y-2 rounded-[6px] px-4 py-3 text-xs" style={{ background: "var(--surface-base)", border: "1px solid var(--border-subtle)", color: "var(--text-muted)" }}>
        <span>{tax.valueLabel}: <b className="font-mono" style={{ color: "var(--text-primary)" }}>{fmtEur(feed.net_value_after_tax_eur)}</b></span>
        <span>Benchmark published tax-adjusted value (basis not separately published): <b className="font-mono" style={{ color: "var(--text-primary)" }}>{feed.benchmark ? fmtEur(benchmark.net_value_after_tax_eur) : "—"}</b></span>
        <span>Costs: <b className="font-mono" style={{ color: "var(--text-secondary)" }}>{fmtEur(feed.costs_eur)}</b></span>
        <span>{tax.taxLabel}: <b className="font-mono" style={{ color: "var(--text-secondary)" }}>{fmtEur(feed.tax_eur)}</b></span>
        <p className="w-full">{tax.explanation}</p>
      </div>

      <section
        className="rounded-[6px] p-5"
        style={{ background: "var(--surface-raised)", border: "1px solid var(--border-subtle)" }}
        aria-label="ETF allocation equity curve"
      >
        <div className="mb-4 flex flex-wrap items-baseline justify-between gap-3">
          <div>
            <h2 className="text-base font-semibold" style={{ color: "var(--text-primary)" }}>
              Monthly DCA equity curve
            </h2>
            <p className="mt-1 text-xs" style={{ color: "var(--text-muted)" }}>
              {feed.history_start} → {feed.history_end} · {fmtEur(feed.initial_capital_eur)} initial + {fmtEur(feed.monthly_budget_eur)}/month · adjusted close total return
            </p>
          </div>
          <span className="font-mono text-xs" style={{ color: "var(--text-secondary)" }}>
            Last mark {last ? fmtEur(last.equity) : "—"}
          </span>
        </div>
        <ResponsiveContainer width="100%" height={340}>
          <LineChart data={data} margin={{ top: 8, right: 12, bottom: 0, left: 4 }}>
            <CartesianGrid strokeDasharray="3 3" stroke="#27272a" />
            <XAxis dataKey="date" tick={{ fontSize: 11, fill: "#71717a" }} tickLine={false} axisLine={{ stroke: "#27272a" }} minTickGap={30} />
            <YAxis tick={{ fontSize: 11, fill: "#71717a" }} tickLine={false} axisLine={false} width={62} tickFormatter={(value) => `€${(Number(value) / 1000).toFixed(0)}k`} />
            <Tooltip
              contentStyle={{ background: "#18181b", border: "1px solid #3f3f46", borderRadius: 6, fontSize: 12 }}
              labelStyle={{ color: "#a1a1aa" }}
              formatter={(value, name) => [typeof value === "number" ? fmtEur(value) : String(value), String(name)]}
            />
            <Line type="monotone" dataKey="contributed" name="Contributed capital" stroke="#71717a" strokeDasharray="5 4" strokeWidth={1.5} dot={false} isAnimationActive={false} />
            {feed.benchmark && <Line type="monotone" dataKey="benchmark" name={`${benchmark.ticker} benchmark`} stroke="var(--strat-borgpea)" strokeWidth={1.5} dot={false} isAnimationActive={false} />}
            <Line type="monotone" dataKey="equity" name="Allocation value" stroke="#7C6FF7" strokeWidth={2.25} dot={false} isAnimationActive={false} />
          </LineChart>
        </ResponsiveContainer>
      </section>

      <section
        className="min-w-0 rounded-[6px]"
        style={{ background: "var(--surface-raised)", border: "1px solid var(--border-subtle)" }}
      >
        <div className="p-5 pb-3">
          <h2 className="text-base font-semibold" style={{ color: "var(--text-primary)" }}>
            Target allocation vs current drift
          </h2>
          <p className="mt-1 text-xs" style={{ color: "var(--text-muted)" }}>
            Fractional shares, no rebalancing. ISINs are retained so the exact broker listing can be checked before investing.
          </p>
        </div>
        <table aria-label="Original ETF allocation weights" className="block w-full text-sm lg:table">
          <thead className="sr-only lg:not-sr-only lg:table-header-group text-[10px] uppercase tracking-widest" style={{ color: "var(--text-muted)", background: "var(--surface-base)" }}>
            <tr>
              <th className="px-5 py-3 text-left">Bucket / ticker</th>
              <th className="px-3 py-3 text-left">ISIN</th>
              <th className="px-3 py-3 text-right">Monthly</th>
              <th className="px-3 py-3 text-right">Target</th>
              <th className="px-5 py-3 text-right">Current</th>
            </tr>
          </thead>
          <tbody className="block lg:table-row-group">
            {feed.holdings.map((holding) => (
              <tr key={holding.isin} className="block p-4 lg:table-row lg:p-0" style={{ borderTop: "1px solid var(--border-subtle)" }}>
                <td className="block pb-2 lg:table-cell lg:px-5 lg:py-3" style={{ color: "var(--text-primary)" }}>
                  <div className="font-medium">{holding.bucket}</div>
                  <div className="font-mono text-[11px]" style={{ color: "var(--text-muted)" }}>{holding.ticker}</div>
                </td>
                <td className="block break-all pb-2 font-mono text-xs lg:table-cell lg:px-3 lg:py-3" style={{ color: "var(--text-secondary)" }}><span className="lg:hidden">ISIN: </span>{holding.isin}</td>
                <td className="flex justify-between gap-2 py-1 font-mono tabular-nums lg:table-cell lg:px-3 lg:py-3 lg:text-right" style={{ color: "var(--text-secondary)" }}><span className="lg:hidden">Monthly</span>{fmtEur(holding.monthly_eur)}</td>
                <td className="flex justify-between gap-2 py-1 font-mono tabular-nums lg:table-cell lg:px-3 lg:py-3 lg:text-right" style={{ color: "var(--text-secondary)" }}><span className="lg:hidden">Target</span>{holding.allocation_pct.toFixed(1)}%</td>
                <td className="block py-1 font-mono tabular-nums lg:table-cell lg:px-5 lg:py-3 lg:text-right" style={{ color: "var(--text-primary)" }}><span className="lg:hidden">Current: </span>{holding.weight_pct.toFixed(1)}% · {fmtEur(holding.market_value_eur)}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </section>

      <section className="rounded-[6px] p-5" style={{ background: "var(--surface-base)", border: "1px solid var(--border-subtle)" }}>
        <h2 className="text-sm font-semibold" style={{ color: "var(--text-primary)" }}>Method and caveats</h2>
        <ul className="mt-3 space-y-1 text-xs" style={{ color: "var(--text-secondary)" }}>
          {tax.caveats.map((caveat, index) => <li key={`${index}-${caveat}`}>• {caveat}</li>)}
        </ul>
        <p className="mt-3 text-[11px]" style={{ color: "var(--text-muted)" }}>
          This is a contribution-path backtest, not an apples-to-apples CAGR against a lump-sum benchmark. It is research evidence, not a recommendation.
        </p>
      </section>
    </div>
  );
}
