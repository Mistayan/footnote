"use client";
export default function RechartsWrapper({ children }: { children: React.ReactNode }) {
  return <>{children}</>;
}
