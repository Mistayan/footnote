"use client";
import { useEffect, useState } from "react";
export type BackendPerformance = { fetch_seconds:number; simulation_seconds:number; total_seconds:number; price_rows_loaded:number; data_transport:string };
type Metrics = { response:number|null; dom:number|null; load:number|null; document:number|null; resources:number|null; count:number|null; lcp:number|null; path:string|null };
const ms=(v:number|null)=>v==null?"—":`${v.toFixed(0)} ms`;
const bytes=(v:number|null)=>v==null?"—":`${(v/1000).toFixed(1)} KB`;
export default function RuntimePerformance({backend,generatedAt}:{backend:BackendPerformance|null;generatedAt?:string}) {
  const [metrics,setMetrics]=useState<Metrics>({response:null,dom:null,load:null,document:null,resources:null,count:null,lcp:null,path:null});
  useEffect(()=>{
    let lcp:number|null=null; let observer:PerformanceObserver|null=null;
    try { observer=new PerformanceObserver(list=>{const last=list.getEntries().at(-1);if(last)lcp=last.startTime;});observer.observe({type:"largest-contentful-paint",buffered:true}); } catch { /* Unsupported timing remains unknown. */ }
    const timer=window.setTimeout(()=>{
      const n=performance.getEntriesByType("navigation")[0] as PerformanceNavigationTiming|undefined;
      const r=performance.getEntriesByType("resource") as PerformanceResourceTiming[];
      if(n)setMetrics({response:n.responseStart,dom:n.domContentLoadedEventEnd||null,load:n.loadEventEnd||null,document:n.transferSize,resources:r.reduce((sum,e)=>sum+e.transferSize,0),count:r.length,lcp,path:new URL(n.name).pathname});
      observer?.disconnect();
    },2500);
    return ()=>{window.clearTimeout(timer);observer?.disconnect();};
  },[]);
  const tile=([label,value]:string[])=><div key={label} className="rounded p-4 bg-[var(--surface-raised)]"><p className="text-xs text-[var(--text-muted)]">{label}</p><p className="mt-2 font-mono text-lg">{value}</p></div>;
  return <div className="space-y-6">
    <section><h2 className="text-sm font-semibold mb-3">Historical producer telemetry · ETF Allocation</h2>
      <p className="text-sm mb-3 text-[var(--text-secondary)]">Source: etf_allocation.json · file generated {generatedAt??"unknown"}. One research producer run, not current system health or route latency. Consumed-input freshness unknown.</p>
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">{[["Total run",backend?`${backend.total_seconds.toFixed(2)} s`:"—"],["Fetch",backend?`${backend.fetch_seconds.toFixed(2)} s`:"—"],["Simulation",backend?`${backend.simulation_seconds.toFixed(3)} s`:"—"],["Rows loaded",backend?backend.price_rows_loaded.toLocaleString("en-EU"):"—"]].map(tile)}</div>
      <p className="mt-3 text-xs text-[var(--text-secondary)]">{backend?.data_transport??"Producer telemetry unavailable; unknown, not zero."}</p>
    </section>
    <section><h2 className="text-sm font-semibold mb-3">Browser document and resource snapshot</h2>
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">{[["Response start",ms(metrics.response)],["DOMContentLoaded",ms(metrics.dom)],["Load complete",ms(metrics.load)],["LCP",ms(metrics.lcp)],["Document transfer",bytes(metrics.document)],["Resource transfer",bytes(metrics.resources)]].map(tile)}</div>
      <p className="mt-3 text-sm text-[var(--text-secondary)]">Local only; no financial payloads or telemetry uploads. Navigation Timing refers to the original document ({metrics.path??"pending"}), not subsequent client-side route transitions. Resource transfer sums {metrics.count??"unknown"} entries, including cross-route prefetch, at 2.5 seconds after this panel mounts; document bytes are separate. Zero can mean cache or unavailable cross-origin timing. LCP is the latest observed candidate within that window, not a final interaction metric.</p>
    </section>
  </div>;
}
