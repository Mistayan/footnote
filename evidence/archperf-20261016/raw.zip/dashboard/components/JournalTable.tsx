"use client";

import type { JournalFeedRow } from "@/app/journal/page";
import { getTickerName } from "@/lib/tickerHelper";

function actionColor(action: string): string {
  if (action === "BUY") return "var(--gain)";
  if (action === "SELL") return "var(--loss)";
  return "var(--text-primary)";
}

function stateColor(state: string): string {
  if (state === "open") return "var(--gain)";
  if (state === "closed") return "var(--text-muted)";
  return "var(--text-muted)";
}

function pnlColor(pnl: number | null | undefined): string {
  if (pnl == null) return "var(--text-muted)";
  if (pnl > 0) return "var(--gain)";
  if (pnl < 0) return "var(--loss)";
  return "var(--text-primary)";
}

function fmt(n: number | null | undefined, digits = 2): string {
  return n == null ? "—" : n.toFixed(digits);
}

function fmtDateTime(dt: string): string {
  if (!dt) return "—";
  // ISO ts -> "YYYY-MM-DD HH:MM"; date-only legacy rows stay as-is.
  if (dt.includes("T")) {
    const d = new Date(dt);
    if (!isNaN(d.getTime())) {
      const pad = (num: number) => String(num).padStart(2, "0");
      return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())} ${pad(d.getHours())}:${pad(d.getMinutes())}`;
    }
  }
  return dt;
}

interface BadgeProps {
  text: string;
  color: string;
}

function Badge({ text, color }: BadgeProps) {
  return (
    <span
      className="inline-flex items-center gap-1 text-[11px] font-bold tracking-wider px-1.5 py-0.5 rounded"
      style={{
        color,
        background: "rgba(255, 255, 255, 0.02)",
        border: `1px solid var(--border-subtle)`,
      }}
    >
      {text}
    </span>
  );
}

interface JournalTableProps {
  rows: JournalFeedRow[];
  showStrategy?: boolean;
}

export default function JournalTable({ rows, showStrategy = true }: JournalTableProps) {
  if (!rows.length) return <div className="text-sm p-4 text-[var(--text-muted)]">No trades found.</div>;
  return (
    <div
      className="rounded-[6px]"
      style={{ border: "1px solid var(--borg-accent-border)" }}
    >
      <div className="md:hidden space-y-3">
        {rows.map((r, i) => <article data-journal-card data-journal-ticker={r.ticker} key={`${r.strategy}-${r.ticker}-${r.datetime}-${i}`} className="rounded p-3 break-words" style={{background:"var(--surface-raised)"}}>
          <h3 className="font-semibold text-sm">{getTickerName(r.ticker, r.name)}</h3>
          <p className="text-xs font-mono text-[var(--text-secondary)]">{r.ticker} · {showStrategy ? r.strategy : ""}</p>
          <p className="text-sm mt-2">{r.action} · {r.state} · {fmtDateTime(r.datetime)}</p>
          <dl className="text-sm mt-2 space-y-1">
            <div><dt className="inline text-[var(--text-muted)]">Quantity: </dt><dd className="inline">{fmt(r.qty)}</dd></div>
            <div><dt className="inline text-[var(--text-muted)]">Price (EUR): </dt><dd className="inline">{fmt(r.price)}</dd></div>
            <div><dt className="inline text-[var(--text-muted)]">P&amp;L (EUR): </dt><dd className="inline" style={{color:pnlColor(r.pnl)}}>{r.action === "SELL" ? fmt(r.pnl) : "—"}</dd></div>
          </dl>
        </article>)}
      </div>
      <div className="hidden md:block overflow-x-auto"><table className="w-full text-sm">
        <thead
          className="text-xs uppercase tracking-wide"
          style={{ background: "var(--surface-raised)", color: "var(--text-muted)" }}
        >
          <tr>
            {showStrategy && (
              <th scope="col" className="py-2 px-3 text-left">
                Strategy
              </th>
            )}
            <th scope="col" className="py-2 px-3 text-left">Action</th>
            <th scope="col" className="py-2 px-3 text-left">Product / Asset</th>
            <th scope="col" className="py-2 px-3 text-right">Qty</th>
            <th scope="col" className="py-2 px-3 text-right">Price (EUR)</th>
            <th scope="col" className="py-2 px-3 text-left">Date / Time</th>
            <th scope="col" className="py-2 px-3 text-left">State</th>
            <th scope="col" className="py-2 px-3 text-right">P&amp;L (EUR)</th>
          </tr>
        </thead>
        <tbody>
          {rows.map((r, i) => (
            <tr
              data-journal-ticker={r.ticker}
              key={`${r.strategy}-${r.ticker}-${r.action}-${r.datetime}-${i}`}
              style={{ borderTop: "1px solid var(--border-subtle)" }}
            >
              {showStrategy && (
                <td className="py-1.5 px-3" style={{ color: "var(--text-muted)" }}>
                  {r.strategy}
                </td>
              )}
              <td className="py-1.5 px-3">
                <Badge text={r.action} color={actionColor(r.action)} />
              </td>
              <td className="py-1.5 px-3" style={{ color: "var(--text-primary)" }}>
                <div className="flex flex-col py-0.5">
                  <span className="font-semibold text-[13px] leading-tight">{getTickerName(r.ticker, r.name)}</span>
                  <span className="text-[10px] font-mono tracking-wider mt-0.5" style={{ color: "var(--text-muted)" }}>{r.ticker}</span>
                </div>
              </td>
              <td className="py-1.5 px-3 text-right tabular-nums font-mono" style={{ color: "var(--text-muted)" }}>
                {fmt(r.qty)}
              </td>
              <td className="py-1.5 px-3 text-right tabular-nums font-mono" style={{ color: "var(--text-primary)" }}>
                {fmt(r.price)}
              </td>
              <td className="py-1.5 px-3 font-mono text-xs" style={{ color: "var(--text-muted)" }}>
                {fmtDateTime(r.datetime)}
              </td>
              <td className="py-1.5 px-3">
                <Badge text={r.state} color={stateColor(r.state)} />
              </td>
              <td className="py-1.5 px-3 text-right tabular-nums font-mono" style={{ color: pnlColor(r.pnl) }}>
                {r.action === "SELL" ? fmt(r.pnl) : "—"}
              </td>
            </tr>
          ))}
        </tbody>
      </table></div>
    </div>
  );
}
