"use client";

/**
 * MomentumEventChart — MomentumB event/P&L line (REQ-6 / DASH-V2-06).
 *
 * MomentumB has sparse shadow trades rather than a continuous strategy equity feed.
 * The chart therefore uses trade-journal events first (BUY/SELL rows ordered by
 * datetime) and terminates at the current net P&L anchor from kpis.json. If the
 * journal is absent, it falls back to same-day shadow intents.
 *
 * With journal rows, BUY events hold cumulative realized P&L flat, SELL events
 * add realized P&L, and the terminal point anchors current net P&L. With only
 * intents, BUY/SELL score pressure is used as a fallback. A single recharts v3
 * `ComposedChart` (RESEARCH Pattern 2): one Line, custom Tooltip typed
 * `TooltipContentProps`. None of the v3-removed legacy props are used — the plan
 * grep-gate asserts zero matches for the forbidden token set in this file.
 */
import {
  ComposedChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  type TooltipContentProps,
} from "recharts";
import { useMemo } from "react";
import type { IntentFeed, JournalFeedRow } from "@/lib/feeds";

/** One point on the event line: a journal/intent event or the terminal "now" anchor. */
type EventRow = {
  /** X label: the event date or "now" for the live shadow anchor. */
  label: string;
  /** Running cumulative realized/net P&L signal up to and including this event. */
  cumulative: number;
  /** Human detail surfaced in the tooltip. */
  detail: string;
  /** True for the terminal shadow-store anchor point. */
  anchor?: boolean;
};

const ACCENT = "#7C6FF7"; // var(--borg-accent)

const fmtNum = (v: number): string =>
  v.toLocaleString("fr-FR", { minimumFractionDigits: 1, maximumFractionDigits: 1 });

/** Map an action to its signed contribution to the cumulative event signal. */
function signedScore(action: string, score: number): number {
  const a = action.toUpperCase();
  if (a.startsWith("BUY")) return score;
  if (a.startsWith("SELL")) return -score;
  return 0;
}

/**
 * Build the event line from journal rows when available, else same-day intents,
 * plus a terminal shadow-store net-P&L anchor. No price series is synthesized —
 * points are events, not calendar days.
 */
export function buildEventRows(
  intents: IntentFeed["intents"],
  shadowNetPnlEur: number | null,
  journalRows: JournalFeedRow[] = [],
): EventRow[] {
  if (journalRows.length) {
    const orderedJournal = [...journalRows].sort((a, b) =>
      (a.datetime || a.date).localeCompare(b.datetime || b.date),
    );
    let realized = 0;
    const rows: EventRow[] = orderedJournal.map((r, idx) => {
      if (r.action === "SELL" && r.pnl != null) realized += r.pnl;
      return {
        label: `${r.date}#${idx + 1}`,
        cumulative: Number(realized.toFixed(2)),
        detail:
          r.action === "SELL"
            ? `${r.action} ${r.ticker} · realized €${(r.pnl ?? 0).toFixed(2)}`
            : `${r.action} ${r.ticker} · open ${r.state}`,
      };
    });

    if (shadowNetPnlEur != null) {
      rows.push({
        label: "now",
        cumulative: Number(shadowNetPnlEur.toFixed(2)),
        detail: `Shadow store · net P&L €${shadowNetPnlEur.toFixed(2)}`,
        anchor: true,
      });
    }
    return rows;
  }

  const ordered = [...intents].sort((a, b) => a.date.localeCompare(b.date));

  let running = 0;
  const rows: EventRow[] = ordered.map((i, idx) => {
    running += signedScore(i.action, i.score);
    return {
      label: `${i.date}#${idx + 1}`,
      cumulative: Number(running.toFixed(4)),
      detail: `${i.action} ${i.ticker} · score ${i.score.toFixed(2)}`,
    };
  });

  if (shadowNetPnlEur != null) {
    rows.push({
      label: "now",
      cumulative: Number(shadowNetPnlEur.toFixed(2)),
      detail: `Shadow store · net P&L €${shadowNetPnlEur.toFixed(2)}`,
      anchor: true,
    });
  }

  return rows;
}

/** v3 custom tooltip — props are TooltipContentProps (NOT v2 TooltipProps). */
function EventTooltip({ active, payload }: TooltipContentProps) {
  if (!active || !payload || payload.length === 0) return null;
  const row = payload[0]?.payload as EventRow | undefined;
  if (!row) return null;
  return (
    <div
      className="rounded text-xs"
      style={{
        background: "var(--surface-overlay)",
        border: "1px solid var(--border-default)",
        padding: "8px 10px",
        color: "var(--text-secondary)",
        minWidth: 160,
      }}
    >
      <div className="font-mono" style={{ color: "var(--text-primary)" }}>
        {row.anchor ? "now" : row.label}
      </div>
      <div className="mt-1">{row.detail}</div>
      <div className="mt-0.5 tabular-nums font-mono">cum {fmtNum(row.cumulative)}</div>
    </div>
  );
}

export default function MomentumEventChart({
  feed,
  shadowNetPnlEur,
  journalRows = [],
}: {
  feed: IntentFeed | null;
  shadowNetPnlEur: number | null;
  journalRows?: JournalFeedRow[];
}) {
  const rows = useMemo(
    () => buildEventRows(feed?.intents ?? [], shadowNetPnlEur, journalRows),
    [feed, shadowNetPnlEur, journalRows],
  );

  if (!rows.length) {
    return (
      <div
        className="flex items-center justify-center rounded-[6px] text-sm"
        style={{
          height: 280,
          border: "1px solid var(--border-subtle)",
          background: "var(--surface-raised)",
          color: "var(--text-muted)",
        }}
      >
        No MomentumB trade telemetry yet — the event/P&L line grows as shadow fills accrue.
      </div>
    );
  }

  return (
    <div>
      <ResponsiveContainer width="100%" height={280}>
        <ComposedChart data={rows} margin={{ top: 8, right: 16, bottom: 0, left: 0 }}>
          <CartesianGrid strokeDasharray="3 3" stroke="#27272a" />
          <XAxis
            dataKey="label"
            tick={{ fontSize: 10, fill: "#71717a" }}
            tickLine={false}
            minTickGap={24}
          />
          <YAxis
            tick={{ fontSize: 11, fill: "#71717a" }}
            axisLine={false}
            tickLine={false}
            domain={["auto", "auto"]}
          />
          <Tooltip
            content={(props) => <EventTooltip {...props} />}
            cursor={{ stroke: "var(--border-default)" }}
          />
          <Line
            type="monotone"
            dataKey="cumulative"
            stroke={ACCENT}
            strokeWidth={2}
            dot={{ r: 2, fill: ACCENT }}
            isAnimationActive={false}
          />
        </ComposedChart>
      </ResponsiveContainer>
      <p className="mt-3 text-xs" style={{ color: "var(--text-muted)" }}>
        Event/P&amp;L line — MomentumB BUY/SELL journal events terminating at current net P&amp;L.
        This is an event sequence, not a continuous price series.
      </p>
    </div>
  );
}
