/**
 * NewsPanel — CTO ticker news for MomentumB (REQ-7 / DASH-V2-07).
 *
 * Consumes news.json (NewsFeed): a card group per ticker in `by_ticker`, each
 * card showing headline, summary and timestamp. When `feed.empty` is true (or
 * the feed is null/missing) it renders a graceful empty-state — never a crash
 * (T-19-15).
 *
 * XSS (T-19-08, transferred from 19-03): every external string (headline,
 * summary) is rendered as a plain React text child — never via raw-HTML
 * injection. React auto-escapes text nodes, so untrusted Alpaca-sourced
 * strings cannot inject markup. The plan grep-gate asserts zero raw-HTML
 * sinks in this file.
 *
 * Presentational / props-only (server-renderable): no client state.
 */
import type { NewsFeed, NewsItem } from "@/lib/feeds";

/** Format an ISO timestamp compactly; fall back to the raw string on parse failure. */
function fmtTs(ts: string): string {
  const d = new Date(ts);
  if (Number.isNaN(d.getTime())) return ts;
  return d.toLocaleString("fr-FR", {
    month: "short",
    day: "numeric",
    hour: "2-digit",
    minute: "2-digit",
  });
}

function EmptyState() {
  return (
    <div
      className="rounded-[6px] px-4 py-6 text-sm text-center"
      style={{
        background: "var(--surface-raised)",
        border: "1px solid var(--border-subtle)",
        color: "var(--text-muted)",
      }}
    >
      No recent news for the held CTO tickers.
    </div>
  );
}

/**
 * Accept only http(s) source links. An untrusted news url could be a
 * `javascript:` (or `data:`) scheme, which executes on click — XSS. Anything
 * that is not an http/https absolute URL is dropped (headline renders as plain
 * text instead of a link).
 */
function safeHttpUrl(url: string | null | undefined): string | null {
  if (!url) return null;
  try {
    const parsed = new URL(url);
    return parsed.protocol === "http:" || parsed.protocol === "https:" ? parsed.href : null;
  } catch {
    return null;
  }
}

function NewsCard({ item }: { item: NewsItem }) {
  const safeUrl = safeHttpUrl(item.url);
  return (
    <div
      className="rounded-[6px] p-3"
      style={{
        background: "var(--surface-raised)",
        border: "1px solid var(--border-subtle)",
      }}
    >
      {/* headline + summary rendered as React text nodes ONLY (XSS-safe, T-19-08).
          When the feed carries a valid http(s) source url, the headline links out
          (new tab, noopener/noreferrer to block tab-nabbing). Non-http schemes
          (javascript:/data:) are rejected by safeHttpUrl → plain text. */}
      <div
        className="text-sm font-semibold mb-1 leading-snug"
        style={{ color: "var(--text-primary)" }}
      >
        {safeUrl ? (
          <a
            href={safeUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="hover:underline"
            style={{ color: "var(--text-primary)" }}
          >
            {item.headline}
          </a>
        ) : (
          item.headline
        )}
      </div>
      {item.summary && (
        <p className="text-xs leading-relaxed mb-2" style={{ color: "var(--text-secondary)" }}>
          {item.summary}
        </p>
      )}
      <span className="text-[11px] font-mono uppercase tracking-wide" style={{ color: "var(--text-muted)" }}>
        {fmtTs(item.ts)}
      </span>
    </div>
  );
}

export default function NewsPanel({ feed }: { feed: NewsFeed | null }) {
  // Null/missing feed or explicitly empty → graceful empty-state, no crash.
  const byTicker = feed?.by_ticker ?? {};
  const tickers = Object.keys(byTicker).filter((t) => (byTicker[t]?.length ?? 0) > 0);

  if (!feed || feed.empty || tickers.length === 0) {
    return <EmptyState />;
  }

  return (
    <div className="flex flex-col gap-5">
      {tickers.map((ticker) => (
        <section key={ticker}>
          <div
            className="text-xs font-semibold uppercase tracking-wide mb-2 font-mono"
            style={{ color: "var(--text-secondary)" }}
          >
            {ticker}
          </div>
          <div className="flex flex-col gap-2">
            {byTicker[ticker].map((item, i) => (
              <NewsCard key={`${ticker}-${i}`} item={item} />
            ))}
          </div>
        </section>
      ))}
    </div>
  );
}
