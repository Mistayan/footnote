"use client";
import {
  AreaChart, Area, XAxis, YAxis, CartesianGrid,
  Tooltip, ResponsiveContainer,
} from "recharts";

interface Row { date: string; equity: number | null; bh?: number }

export default function EquityChart({ data, shadow = false }: { data: Row[]; shadow?: boolean }) {
  const hasBenchmark = data.some((row) => Number.isFinite(row.bh));
  const label = shadow ? "Combined shadow portfolio" : "Portfolio";
  const first = data[0]?.equity;
  const last = data[data.length - 1]?.equity;
  const totalReturn = data.every(row => row.equity != null) && first != null && last != null && first > 0
    ? ((last - first) / first * 100).toFixed(1) : null;

  return (
    <div>
      <ResponsiveContainer width="100%" height={340}>
        <AreaChart data={data} margin={{ top: 8, right: 16, bottom: 0, left: 0 }}>
          <defs>
            <linearGradient id="gEq" x1="0" y1="0" x2="0" y2="1">
              <stop offset="5%"  stopColor="#B59A6B" stopOpacity={0.35} />
              <stop offset="95%" stopColor="#B59A6B" stopOpacity={0} />
            </linearGradient>
            <linearGradient id="gBh" x1="0" y1="0" x2="0" y2="1">
              <stop offset="5%"  stopColor="#8A93A8" stopOpacity={0.25} />
              <stop offset="95%" stopColor="#8A93A8" stopOpacity={0} />
            </linearGradient>
          </defs>
          <CartesianGrid strokeDasharray="3 3" stroke="#27272a" />
          <XAxis dataKey="date" tick={{ fontSize: 11, fill: "#71717a" }} tickLine={false} />
          <YAxis tick={{ fontSize: 11, fill: "#71717a" }} tickLine={false} axisLine={false}
            tickFormatter={(v) => `€${(v as number).toLocaleString("fr-FR")}`} />
          <Tooltip
            contentStyle={{ background: "#18181b", border: "1px solid #3f3f46", fontSize: 12 }}
            labelStyle={{ color: "#a1a1aa" }}
            formatter={(value, name) => [
              typeof value === "number"
                ? `€${value.toLocaleString("fr-FR", { minimumFractionDigits: 0, maximumFractionDigits: 0 })}`
                : String(value),
              String(name),
            ]}
          />
          <Area type="linear" dataKey="equity" name={label} stroke="#B59A6B"
            strokeWidth={2} fill="url(#gEq)" connectNulls={false} dot={false} isAnimationActive={false} />
          {hasBenchmark && <Area type="linear" dataKey="bh" name="Benchmark" stroke="#8A93A8"
            strokeWidth={1.5} fill="url(#gBh)" dot={false} isAnimationActive={false} />}
        </AreaChart>
      </ResponsiveContainer>

      {/* Legend + explanation */}
      <div className="mt-6 grid grid-cols-1 gap-4 sm:grid-cols-2 text-sm"
           style={{ color: "var(--text-secondary)" }}>
        <div className="flex gap-3 items-start">
          <span className="mt-1 shrink-0 w-3 h-3 rounded-sm" style={{ background: "var(--strat-momentumb)" }} />
          <div>
            <p className="font-semibold" style={{ color: "var(--text-primary)" }}>
              {label}
              {totalReturn != null && (
                <span className="ml-2 font-mono text-xs"
                  style={{ color: Number(totalReturn) >= 0 ? "var(--gain)" : "var(--loss)" }}>
                  {Number(totalReturn) >= 0 ? "+" : ""}{totalReturn}% value change
                </span>
              )}
            </p>
            <p className="text-xs mt-0.5" style={{ color: "var(--text-muted)" }}>
              {shadow
                ? "Realized ledger history with the latest marked valuation. This is not a daily NAV history."
                : "Portfolio values from the published dataset. Value change is not adjusted for contributions."}
            </p>
          </div>
        </div>
        {hasBenchmark && <div className="flex gap-3 items-start">
          <span className="mt-1 shrink-0 w-3 h-3 rounded-sm" style={{ background: "var(--strat-borgpea)" }} />
          <div>
            <p className="font-semibold" style={{ color: "var(--text-primary)" }}>
              Benchmark
            </p>
            <p className="text-xs mt-0.5" style={{ color: "var(--text-muted)" }}>
              Reference series supplied by the same dataset. Consult its report for
              the benchmark, contribution, cost and tax assumptions.
            </p>
          </div>
        </div>}
      </div>

      <p className="mt-4 text-xs" style={{ color: "var(--text-muted)" }}>
        All values in EUR. Historical and simulated results do not guarantee future results.
      </p>
    </div>
  );
}
