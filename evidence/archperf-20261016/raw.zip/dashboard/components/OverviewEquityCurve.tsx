"use client";
/**
 * OverviewEquityCurve — combined blended equity curve (REQ-2).
 * Render-only: maps kpis.equity_curve ({date, equity}[]) 1:1 onto the existing
 * EquityChart row shape. No JS recompute — the series is built/tested in Python (19-02).
 * Empty/absent series → explicit "no equity data" state (T-19-15), never crashes the chart.
 */
import EquityChart from "./EquityChart";
import type { KpiFeed } from "@/lib/feeds";

export default function OverviewEquityCurve({
  equityCurve,
}: {
  equityCurve?: KpiFeed["equity_curve"] | null;
}) {
  const rows = (equityCurve ?? []).map((p) => ({ date: p.date, equity: p.equity }));

  if (!rows.some(row => row.equity != null && Number.isFinite(row.equity))) {
    return (
      <section className="mb-8">
        <h2
          className="text-sm font-semibold mb-3 uppercase tracking-wide"
          style={{ color: "var(--text-secondary)" }}
        >
          Realized P&amp;L Book Proxy
        </h2>
        <div
          className="rounded-[6px] p-8 text-sm text-center"
          style={{
            background: "var(--surface-raised)",
            border: "1px solid var(--border-subtle)",
            color: "var(--text-muted)",
          }}
        >
          No dated daily marked NAV evidence. Historical restatement has no daily curve.
        </div>
      </section>
    );
  }

  return (
    <section className="mb-8">
      <h2
        className="text-sm font-semibold mb-3 uppercase tracking-wide"
        style={{ color: "var(--text-secondary)" }}
      >
        Realized P&amp;L Book Proxy
      </h2>
      {rows.some(row => row.equity == null) && <p className="text-xs mb-3" style={{ color: "var(--text-secondary)" }}>Missing valuation observations — gaps are unknown, not zero; no end-to-end return is inferred.</p>}
      <p className="text-xs mb-3" style={{ color: "var(--text-secondary)" }}>Realized P&amp;L on fixed book plus snapshot tail — not daily marked NAV. Daily drawdown and Sharpe unknown; mark freshness unknown.</p>
      <div
        className="rounded-[6px] p-5"
        style={{
          background: "var(--surface-raised)",
          border: "1px solid var(--borg-accent-border)",
        }}
      >
        <EquityChart data={rows} shadow />
      </div>
    </section>
  );
}
