"use client";

import type { StrategyKpis } from "@/lib/feeds";
import KpiProvenance from "./KpiProvenance";
import { STRAT_LABEL } from "@/lib/strategies";
import { Percent, TrendingUp, Zap, BarChart, Calendar } from "lucide-react";

const STRAT_ICON: Record<string, React.ComponentType<{ className?: string }>> = {
  borgdiv: Percent,
  borgpea: TrendingUp,
  momentumb: Zap,
  claudemomentum: BarChart,
};

const STRAT_COLOR: Record<string, string> = {
  borgdiv: "var(--strat-borgdiv)",
  borgpea: "var(--strat-borgpea)",
  momentumb: "var(--strat-momentumb)",
  claudemomentum: "var(--strat-claudemomentum)",
};

const STRAT_FORMULA: Record<string, string> = {
  borgdiv: "Variant Q (QuantPreExRunup)",
  borgpea: "BorgPEA-LRT (Region + Sector)",
  momentumb: "9/50 EMA cross with Index Gate",
  claudemomentum: "100-day SMA baseline",
};

const fmtEur = (v?: number | null) =>
  v == null ? "—" : `€${v.toLocaleString("en-EU", { maximumFractionDigits: 0 })}`;

const fmtPnl = (v?: number | null) =>
  v == null
    ? "—"
    : `${v >= 0 ? "+" : "−"}€${Math.abs(v).toLocaleString("en-EU", { maximumFractionDigits: 0 })}`;

const fmtReturnPct = (pnl?: number | null, basis?: number | null): string => {
  if (pnl == null || basis == null || Math.abs(basis) < 1) return "—";
  const p = (pnl / Math.abs(basis)) * 100;
  return `${p >= 0 ? "+" : "−"}${Math.abs(p).toFixed(1)}%`;
};

const pnlColor = (v?: number | null): string =>
  v == null ? "var(--text-muted)" : v > 0 ? "var(--gain)" : v < 0 ? "var(--loss)" : "var(--text-muted)";

export default function StrategyKpiCard({
  strategy,
  kpi,
}: {
  strategy: string;
  kpi: StrategyKpis | null;
}) {
  if (!kpi) {
    return (
      <div
        className="rounded-[6px] p-6 text-sm flex items-center justify-between"
        style={{
          background: "var(--surface-raised)",
          border: "1px solid var(--border-subtle)",
          color: "var(--text-muted)",
        }}
      >
        <span>{STRAT_LABEL[strategy] ?? strategy}</span>
        <span className="text-xs font-mono">No KPI Data Published</span>
      </div>
    );
  }

  const Icon = STRAT_ICON[strategy] || BarChart;
  const color = STRAT_COLOR[strategy] || "var(--borg-accent)";
  const formula = STRAT_FORMULA[strategy] || "Custom model";

  const safeAccounting = kpi.basis === "original_fills_current_policy_diagnostic" || kpi.basis === "fixed_20k_original_fills_no_monthly_deposits";
  const netPnl = safeAccounting ? kpi.net_pnl_eur : null;
  const currentValue = safeAccounting ? kpi.current_value_eur : null;
  const investedValue = kpi.invested_value_eur;
  const cash = safeAccounting ? kpi.cash_eur : null;
  const yieldParked = kpi.yield_parked_eur;
  const closed = kpi.closed_trades_count ?? "—";
  const winners = kpi.winning_trades_count ?? "—";
  const open = kpi.open_positions_count ?? "—";
  const shadowDays = kpi.shadow_day_count ?? 0;
  const targetDays = kpi.target_days ?? 90;

  const winRateStr = kpi.win_rate != null ? `${(kpi.win_rate * 100).toFixed(0)}%` : "—";


  return (
    <div
      className="rounded-[6px] p-5 flex flex-col justify-between space-y-5 premium-card-hover animate-fade-in-up"
      style={{
        background: "var(--surface-raised)",
        border: "1px solid var(--border-subtle)",
      }}
    >
      {/* 1. Header (Icon, Name, Formula) */}
      <div className="flex items-start justify-between">
        <div className="space-y-1">
          <div className="flex items-center gap-2">
            <div className="p-1 rounded-sm bg-zinc-800" style={{ color }}>
              <Icon className="w-4 h-4" />
            </div>
            <h3 className="text-sm font-bold text-white">
              {STRAT_LABEL[strategy] ?? strategy}
            </h3>
          </div>
          <span className="text-[10px] font-mono text-zinc-500 block leading-tight">
            {formula}
          </span>
        </div>
        
        {/* Runtime Badge */}
        <div className="flex items-center gap-1 text-[10px] font-mono text-zinc-500 bg-zinc-900 px-2 py-0.5 rounded border border-zinc-800">
          <Calendar className="w-3 h-3 text-zinc-600" />
          {shadowDays}/{targetDays}d
        </div>
      </div>

      {/* 2. Headline Net asset value + P&L */}
      <div className="space-y-0.5">
        <span className="text-xs font-mono uppercase tracking-wider text-zinc-500">Book valuation (marks unverified)</span>
        <div className="flex items-baseline gap-3">
          <span className="text-2xl font-extrabold text-white font-mono tracking-tight leading-none">
            {fmtEur(currentValue)}
          </span>
          <span className="text-sm font-mono font-bold leading-none" style={{ color: pnlColor(netPnl) }}>
            {fmtPnl(netPnl)} ({fmtReturnPct(netPnl, kpi.book_value_eur)})
          </span>
        </div>
      </div>

      <KpiProvenance evidence={kpi} />
      <p className="text-xs" style={{ color: "var(--text-secondary)" }}>Return denominator: fixed book {fmtEur(kpi.book_value_eur)}, not invested market value. Runtime metadata since {kpi.shadow_start_date ?? "unknown"}; historical strategy/profile identity unverified.</p>
      {!safeAccounting && <p className="text-xs" style={{ color: "var(--text-secondary)" }}>Legacy accounting unverified — net valuation and cash withheld pending safe feed publication.</p>}

      {/* 3. Detailed metrics split */}
      <div className="grid grid-cols-3 gap-2 pt-3 border-t text-[11px]" style={{ borderColor: "var(--border-subtle)" }}>
        
        {/* Deployed cap */}
        <div className="space-y-0.5">
          <span className="text-zinc-500 block uppercase font-mono tracking-wide text-[9px]">Deployed</span>
          <span className="font-semibold text-zinc-300 font-mono">{fmtEur(investedValue)}</span>
        </div>

        {/* Cash / Yield */}
        <div className="space-y-0.5">
          <span className="text-zinc-500 block uppercase font-mono tracking-wide text-[9px]">Cash / Yield / Tax</span>
          <span className="font-semibold text-zinc-300 font-mono">
            {fmtEur(cash)} · yield {fmtEur(yieldParked)} · reserve {fmtEur(kpi.tax_reserve_eur !== undefined ? kpi.tax_reserve_eur : kpi.tax_eur)}
          </span>
        </div>

        {/* Win Rate & Counts */}
        <div className="space-y-0.5">
          <span className="text-zinc-500 block uppercase font-mono tracking-wide text-[9px]">Win Rate / Counts</span>
          <span className="font-semibold text-zinc-300 font-mono">
            {winRateStr} ({winners}/{closed} W)
          </span>
        </div>

        {/* Sharpe */}
        <div className="space-y-0.5 mt-2">
          <span className="text-zinc-500 block uppercase font-mono tracking-wide text-[9px]">Daily Sharpe (unknown)</span>
          <span className="font-semibold text-zinc-300 font-mono">
            —
          </span>
        </div>

        {/* Max Drawdown */}
        <div className="space-y-0.5 mt-2">
          <span className="text-zinc-500 block uppercase font-mono tracking-wide text-[9px]">Daily drawdown (unknown)</span>
          <span className="font-semibold font-mono" style={{ color: "var(--loss)" }}>
            —
          </span>
        </div>

        {/* Active Positions */}
        <div className="space-y-0.5 mt-2">
          <span className="text-zinc-500 block uppercase font-mono tracking-wide text-[9px]">Open Slots</span>
          <span className="font-semibold text-zinc-300 font-mono">
            {open} positions
          </span>
        </div>

      </div>

      {/* 4. Strategy Specific highlights (e.g. Dividend for BorgDiv) */}
      {strategy === "borgdiv" && (
        <div className="p-3 rounded text-xs space-y-2" style={{ background: "var(--surface-overlay)", color: "var(--text-secondary)" }}>
          <p>Dividend entitlement estimate (unverified): {fmtEur(kpi.dividend_earned_entitlement_estimate_eur !== undefined ? kpi.dividend_earned_entitlement_estimate_eur : kpi.dividend_captured_eur)}</p>
          <p>Paid dividends: unknown · not spendable cash · excluded from net P&amp;L</p>
          <p>14d projection (not earned): {fmtEur(kpi.dividend_projected_14d_eur)}</p>
        </div>
      )}

    </div>
  );
}
