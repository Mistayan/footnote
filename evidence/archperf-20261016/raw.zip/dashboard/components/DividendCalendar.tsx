"use client";

/**
 * DividendCalendar — BorgDiv 14-day forward dividend candidates, calendar layout.
 *
 * Renders the GATE-PASSING candidates (borgdiv_forward_candidates.json) — the
 * post quality-gate + net-edge set the strategy actually considers — NOT the raw
 * market-wide discovery calendar (dividends.json, hundreds of events). The top
 * `pick_limit` entries are flagged is_pick: the slots we would fill.
 *
 * Each candidate is a chip on its ex_date cell; hover/focus reveals a fixed
 * popover (escapes the cell scroll-clip) with the full instrument name + ISIN
 * (journal-style naming), dividend/share, ex-div date, payout date, gross/net
 * yield, and expected edge. The 14-day window is enforced upstream in Python.
 */
import { useState } from "react";
import type { ForwardDividendFeed } from "@/lib/feeds";
import { getTickerName } from "@/lib/tickerHelper";

type Candidate = NonNullable<ForwardDividendFeed["candidates"]>[number];
type Active = { id: string; c: Candidate; rect: DOMRect };

const WEEKDAYS = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"];
const WINDOW_DAYS = 14;
const POP_W = 248;
const POP_H = 260;

const fmtAmount = (v: number, currency: string): string => {
  const sym = currency === "EUR" ? "€" : currency === "USD" ? "$" : currency === "GBP" ? "£" : "";
  const amount = v.toLocaleString("fr-FR", { minimumFractionDigits: 2, maximumFractionDigits: 4 });
  return sym ? `${sym}${amount}` : `${amount} ${currency}`;
};
const fmtPct = (v: number): string => `${v.toLocaleString("fr-FR", { minimumFractionDigits: 2, maximumFractionDigits: 2 })}%`;

const parseDay = (iso: string): Date => new Date(`${iso.slice(0, 10)}T00:00:00`);
const dayKey = (d: Date): string =>
  `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
const mondayIdx = (d: Date): number => (d.getDay() + 6) % 7;
const addDays = (d: Date, n: number): Date => {
  const c = new Date(d);
  c.setDate(c.getDate() + n);
  return c;
};
const fmtDayLabel = (d: Date): string => d.toLocaleDateString("fr-FR", { day: "numeric", month: "short" });
const fullName = (c: Candidate): string => (c.name?.trim() ? c.name.trim() : getTickerName(c.ticker));

// Currency/country do not identify a listing calendar, timezone or DST boundary.
// Date-only candidates cannot evidence an exact exchange-session timestamp.
const exSession = (c: Candidate): string => {
  return `${c.exchange || "Exchange unknown"} · session boundary unknown (no exchange-calendar receipt)`;
};

export type DividendCalendarProps = {
  feed: ForwardDividendFeed | null;
};

export default function DividendCalendar({ feed }: DividendCalendarProps) {
  const [active, setActive] = useState<Active | null>(null);
  const candidates = feed?.candidates ?? [];

  if (candidates.length === 0) {
    return (
      <div className="overflow-hidden rounded-[6px]" style={{ border: "1px solid var(--borg-accent-border)" }}>
        <div className="text-center text-sm py-6" style={{ color: "var(--text-muted)" }}>
          {feed ? "No dividend candidates passed the filters in the next 14 days." : "Dividend candidate evidence unavailable — unknown, not zero candidates."}
        </div>
      </div>
    );
  }

  const exDays = candidates.map((c) => parseDay(c.ex_date)).sort((a, b) => a.getTime() - b.getTime());
  const anchor = feed?.generated_at ? parseDay(feed.generated_at) : exDays[0];
  const windowStart = anchor;
  const windowEnd = addDays(windowStart, WINDOW_DAYS - 1);
  const gridStart = addDays(windowStart, -mondayIdx(windowStart));
  const gridEnd = addDays(windowEnd, 6 - mondayIdx(windowEnd));
  const cellCount = Math.round((gridEnd.getTime() - gridStart.getTime()) / 86_400_000) + 1;

  const byDay = new Map<string, Candidate[]>();
  for (const c of candidates) {
    const k = dayKey(parseDay(c.ex_date));
    (byDay.get(k) ?? byDay.set(k, []).get(k)!).push(c);
  }

  const todayKey = dayKey(windowStart);
  const cells = Array.from({ length: cellCount }, (_, i) => addDays(gridStart, i));

  const pop = active
    ? (() => {
        const r = active.rect;
        const vw = typeof window !== "undefined" ? window.innerWidth : 1280;
        const vh = typeof window !== "undefined" ? window.innerHeight : 800;
        const left = Math.min(Math.max(8, r.left), vw - POP_W - 8);
        const below = r.bottom + 6;
        const top = below + POP_H > vh ? Math.max(8, r.top - POP_H - 6) : below;
        return { left, top };
      })()
    : null;

  return (
    <div className="rounded-[6px] p-3" style={{ border: "1px solid var(--borg-accent-border)" }}>
      <div className="flex flex-wrap items-center justify-between gap-2 mb-2">
        <span className="text-[10px] uppercase tracking-wider" style={{ color: "var(--text-muted)" }}>
          Gate-passing candidates · up to {feed?.pick_limit ?? 3} ranked picks · not executed trades
        </span>
        <span className="text-[10px] tabular-nums" style={{ color: "var(--text-muted)" }}>
          {candidates.length} pass filters
        </span>
      </div>

      <p className="text-xs mb-3" style={{ color: "var(--text-secondary)" }}>BorgDiv Q pre-ex run-up candidates. Calendar dividend/share, yields and pay dates are estimates, not entitlement, paid cash or income.</p>
      <p className="text-xs mb-3" style={{ color: "var(--text-secondary)" }}>Modeled net yield assumes gross × 0.686 (PFU modeled 31.4%), not verified personal taxation. Foreign withholding, treaty credit eligibility/caps and account circumstances may change the result. Dividend currency is not necessarily quote currency: gross yield requires dividend/price currency alignment and evidenced FX. FX and tax receipts are unknown here. Edge is a dividend-yield ranking estimate, not Q price profit or a guaranteed return.</p>
      <section aria-label="Dividend candidate agenda" className="md:hidden space-y-3 mb-4">
        {[...candidates].sort((a,b)=>a.ex_date.localeCompare(b.ex_date)).map((c,i)=><article key={`${c.ticker}-${c.ex_date}-${i}`} className="rounded p-3 break-words bg-[var(--surface-raised)]">
          <h3 className="text-sm font-semibold">{c.is_pick ? "★ " : ""}{fullName(c)}</h3>
          <p className="text-sm mt-2">Ex-date {c.ex_date} · payout {c.pay_date ?? "unknown"}</p>
          <p className="text-sm">{fmtPct(c.net_yield_pct)} estimated net yield · {fmtAmount(c.gross_dividend,c.currency)} estimated dividend/share</p>
          <details className="mt-2 text-sm"><summary className="min-h-12 cursor-pointer">Candidate identifiers and evidence</summary>
            <p className="font-mono">{c.ticker}{c.isin ? ` · ${c.isin}` : " · ISIN unknown"}</p>
            <p>{exSession(c)}</p><p>Gross yield {fmtPct(c.gross_yield_pct)} · modeled dividend edge {c.expected_edge_bps.toFixed(0)} bps. FX and tax receipts unknown.</p>
          </details>
        </article>)}
      </section>
      <div className="hidden md:grid grid-cols-7 gap-1.5 mb-1.5">
        {WEEKDAYS.map((w) => (
          <div key={w} className="text-[10px] font-semibold uppercase tracking-wider text-center pb-1" style={{ color: "var(--text-muted)" }}>
            {w}
          </div>
        ))}
      </div>

      <div className="hidden md:grid grid-cols-7 gap-1.5">
        {cells.map((date) => {
          const k = dayKey(date);
          const inWindow = date >= windowStart && date <= windowEnd;
          const isToday = k === todayKey;
          const events = byDay.get(k) ?? [];
          return (
            <div
              key={k}
              className="rounded-[5px] min-h-[88px] p-1.5 flex flex-col"
              style={{
                background: inWindow ? "var(--surface-raised)" : "transparent",
                border: isToday ? "1px solid var(--borg-accent)" : "1px solid var(--border-subtle)",
                opacity: inWindow ? 1 : 0.4,
              }}
            >
              <div className="flex items-center justify-between mb-1 shrink-0">
                <span className="text-[11px] font-mono tabular-nums" style={{ color: isToday ? "var(--borg-accent)" : "var(--text-secondary)" }}>
                  {date.getDate()}
                </span>
                {isToday && (
                  <span className="text-[8px] font-bold uppercase tracking-wider" style={{ color: "var(--borg-accent)" }}>
                    As-of
                  </span>
                )}
              </div>

              <div className="flex flex-col gap-1 overflow-y-auto max-h-[160px] pr-0.5">
                {events.map((c, i) => {
                  const id = `${k}-${c.ticker}-${i}`;
                  const name = fullName(c);
                  const open = (e: React.FocusEvent<HTMLButtonElement> | React.MouseEvent<HTMLButtonElement>) =>
                    setActive({ id, c, rect: e.currentTarget.getBoundingClientRect() });
                  const close = () => setActive((a) => (a?.id === id ? null : a));
                  return (
                    <button
                      key={id}
                      type="button"
                      className="w-full text-left rounded-[4px] px-1.5 py-0.5 truncate motion-safe:transition-colors"
                      style={{
                        background: c.is_pick ? "var(--borg-accent)" : "var(--borg-accent-bg, rgba(99,102,241,0.12))",
                        color: c.is_pick ? "var(--surface-base)" : "var(--text-primary)",
                        outlineColor: "var(--borg-accent)",
                      }}
                      aria-label={`${c.is_pick ? "Pick: " : ""}${name}, ${fmtAmount(
                        c.gross_dividend,
                        c.currency,
                      )} per share, net yield ${fmtPct(c.net_yield_pct)}, ex-dividend ${fmtDayLabel(
                        parseDay(c.ex_date),
                      )}, payout ${c.pay_date ? fmtDayLabel(parseDay(c.pay_date)) : "unknown"}`}
                      onMouseEnter={open}
                      onMouseLeave={close}
                      onFocus={open}
                      onBlur={close}
                      onKeyDown={e => { if (e.key === "Escape") close(); }}
                    >
                      <span className="text-[10px] font-semibold">{c.is_pick ? "★ " : ""}{name}</span>
                    </button>
                  );
                })}
              </div>
            </div>
          );
        })}
      </div>

      {active && pop && (
        <div
          role="tooltip"
          className="fixed z-50 rounded-[6px] p-3 shadow-lg motion-safe:transition-opacity pointer-events-none"
          style={{
            left: pop.left,
            top: pop.top,
            width: POP_W,
            background: "var(--surface-overlay, #1A1A1A)",
            border: "1px solid var(--borg-accent-border)",
          }}
        >
          <div className="text-xs font-semibold leading-tight" style={{ color: "var(--text-primary)" }}>
            {active.c.is_pick && <span style={{ color: "var(--borg-accent)" }}>★ </span>}
            {fullName(active.c)}
          </div>
          <div className="text-[10px] font-mono mb-2 mt-0.5" style={{ color: "var(--text-muted)" }}>
            {active.c.ticker}
            {active.c.isin ? ` · ${active.c.isin}` : ""}
          </div>
          <dl className="grid grid-cols-[auto_1fr] gap-x-2 gap-y-1 text-[11px]">
            <dt style={{ color: "var(--text-muted)" }}>Div / share</dt>
            <dd className="text-right font-mono tabular-nums" style={{ color: "var(--text-secondary)" }}>
              {fmtAmount(active.c.gross_dividend, active.c.currency)}
            </dd>
            <dt style={{ color: "var(--text-muted)" }}>Ex-div</dt>
            <dd className="text-right font-mono tabular-nums" style={{ color: "var(--text-secondary)" }}>
              {fmtDayLabel(parseDay(active.c.ex_date))}
            </dd>
            <dt style={{ color: "var(--text-muted)" }}>Ex session</dt>
            <dd className="text-right font-mono" style={{ color: "var(--text-secondary)" }}>
              {exSession(active.c)}
            </dd>
            <dt style={{ color: "var(--text-muted)" }}>Payout</dt>
            <dd className="text-right font-mono tabular-nums" style={{ color: "var(--text-secondary)" }}>
              {active.c.pay_date ? fmtDayLabel(parseDay(active.c.pay_date)) : "—"}
            </dd>
            <dt style={{ color: "var(--text-muted)" }}>Gross yield</dt>
            <dd className="text-right font-mono tabular-nums" style={{ color: "var(--text-secondary)" }}>
              {fmtPct(active.c.gross_yield_pct)}
            </dd>
            <dt style={{ color: "var(--text-muted)" }}>Net yield</dt>
            <dd className="text-right font-mono tabular-nums" style={{ color: "var(--text-secondary)" }}>
              {fmtPct(active.c.net_yield_pct)}
            </dd>
            <dt style={{ color: "var(--text-muted)" }}>Modeled dividend edge</dt>
            <dd className="text-right font-mono tabular-nums" style={{ color: "var(--text-secondary)" }}>
              {active.c.expected_edge_bps.toFixed(0)} bps
            </dd>
          </dl>
        </div>
      )}
    </div>
  );
}
