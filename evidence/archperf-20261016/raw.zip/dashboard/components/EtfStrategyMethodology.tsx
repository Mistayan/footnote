import Link from "next/link";
import type { EtfAllocationFeed } from "@/lib/feeds";
import { etfFeedStatus } from "@/lib/etf-metadata";

export default function EtfStrategyMethodology({ feed }: { feed: EtfAllocationFeed | null }) {
  const eur = (value: number) => new Intl.NumberFormat("en-IE", { style: "currency", currency: "EUR", maximumFractionDigits: 0 }).format(value);
  return (
    <section aria-label="ETF strategy methodology" className="mb-6 min-w-0 break-words rounded p-4 space-y-2" style={{ background: "var(--surface-raised)", border: "1px solid var(--border-subtle)", color: "var(--text-secondary)" }}>
      <h2 className="text-base font-semibold" style={{ color: "var(--text-primary)" }}>Cross-strategy comparison blocked</h2>
      <p className="text-sm">ETF Allocation is a separate research strategy, not a runtime shadow sleeve. {feed ? `${eur(feed.initial_capital_eur)} initial + ${eur(feed.monthly_budget_eur)}/month.` : "No ETF allocation feed published."} Six supplied fund weights are unchanged; no research weights applied.</p>
      <p className="text-sm">Eligible only for its matched contribution-path benchmark when the feed contract is validated. Not eligible for fixed-capital strategy ranking or the existing equity panels with a different initial capital/window. DCA return is gain divided by contributed capital, not time-weighted CAGR. No combined totals or leaderboard.</p>
      {feed && <p className="text-sm">Published historical feed status: {feed.comparison_status ?? "not published"}. {etfFeedStatus(feed.generated_at, feed.history_end)}</p>}
      <Link className="inline-block py-2 text-sm underline" style={{ color: "var(--borg-accent)" }} href="/etf-allocation">Open ETF Allocation strategy</Link>
    </section>
  );
}
