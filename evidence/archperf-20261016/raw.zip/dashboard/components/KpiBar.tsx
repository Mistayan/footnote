interface KpiBarProps {
  portfolioEur?: number | null;
  dailyPnlEur?: number | null;
  positionsCount?: number | null;
  winRate?: number | null;
  marketBreadth?: number | null;
  vix?: number | null;
  signalCount?: number | null;
}

function Divider() {
  return (
    <div
      className="hidden md:block self-stretch w-px my-1"
      style={{ background: "var(--border-subtle)" }}
    />
  );
}

function Stat({
  label,
  value,
  delta,
  deltaColor,
}: {
  label: string;
  value: string;
  delta?: string;
  deltaColor?: string;
}) {
  return (
    <div className="flex flex-col items-center px-5 py-2 min-w-[80px]">
      <span
        className="text-[11px] uppercase tracking-widest mb-1"
        style={{ color: "var(--text-muted)" }}
      >
        {label}
      </span>
      <span
        className="text-sm font-semibold tabular-nums"
        style={{ fontFamily: "var(--font-mono, monospace)", color: "var(--text-primary)" }}
      >
        {value}
      </span>
      {delta && (
        <span className="text-[11px] mt-0.5" style={{ color: deltaColor ?? "var(--text-muted)" }}>
          {delta}
        </span>
      )}
    </div>
  );
}

function RegimeBadge({ breadth, vix }: { breadth?: number | null; vix?: number | null }) {
  const b = breadth ?? 0;
  const v = vix ?? 0;
  const label = breadth == null || vix == null ? "UNKNOWN" : b >= 0.55 && v < 25 ? "RISK-ON" : v >= 32 ? "RISK-OFF" : "CAUTION";
  const color =
    label === "RISK-ON"  ? "var(--gain)"  :
    label === "RISK-OFF" ? "var(--loss)"  :
    "var(--warn)";
  const bg =
    label === "RISK-ON"  ? "var(--gain-bg)"  :
    label === "RISK-OFF" ? "var(--loss-bg)"  :
    "var(--warn-bg)";
  const borderColor =
    label === "RISK-ON"  ? "var(--gain-border)"  :
    label === "RISK-OFF" ? "var(--loss-border)"  :
    "var(--warn-border)";

  return (
    <div className="flex flex-col items-center px-5 py-2 min-w-[90px]">
      <span
        className="text-[11px] uppercase tracking-widest mb-1"
        style={{ color: "var(--text-muted)" }}
      >
        Regime
      </span>
      <span
        className="inline-flex items-center gap-1 text-[11px] font-medium px-2 py-0.5 rounded"
        style={{ color, background: bg, border: `1px solid ${borderColor}` }}
      >
        <span
          className="w-1.5 h-1.5 rounded-full shrink-0"
          style={{ background: color }}
        />
        {label}
      </span>
      {vix != null && (
        <span className="text-[11px] mt-0.5" style={{ color: "var(--text-muted)" }}>
          VIX {vix.toFixed(1)}
        </span>
      )}
    </div>
  );
}

export default function KpiBar({
  portfolioEur,
  dailyPnlEur,
  positionsCount,
  winRate,
  marketBreadth,
  vix,
  signalCount,
}: KpiBarProps) {
  const fmtEur = (v?: number | null) =>
    v == null ? "—" : `€${v.toLocaleString("en-EU", { maximumFractionDigits: 0 })}`;
  const fmtPnl = (v?: number | null) =>
    v == null ? "—" : `${v >= 0 ? "+" : "−"}€${Math.abs(v).toLocaleString("en-EU", { maximumFractionDigits: 0 })}`;

  return (
    <div
      className="kpi-strip grid grid-cols-2 md:flex items-center rounded-[6px] text-sm mb-6"
      style={{
        background: "var(--surface-raised)",
        border: "1px solid var(--border-subtle)",
      }}
    >
      <Stat
        label="Portfolio"
        value={fmtEur(portfolioEur)}
        delta={portfolioEur == null ? undefined : "total"}
        deltaColor="var(--text-muted)"
      />
      <Divider />
      <Stat
        label="Unrealized P&L"
        value={fmtPnl(dailyPnlEur)}
        delta="open positions"
        deltaColor={
          dailyPnlEur == null ? "var(--text-muted)" :
          dailyPnlEur >= 0 ? "var(--gain)" : "var(--loss)"
        }
      />
      <Divider />
      <Stat
        label="Positions"
        value={positionsCount == null ? "—" : String(positionsCount)}
        delta={signalCount == null ? undefined : `${signalCount} signals`}
        deltaColor="var(--borg-accent)"
      />
      <Divider />
      <Stat
        label="Win Rate"
        value={winRate == null ? "—" : `${(winRate * 100).toFixed(0)}%`}
        delta="90-day"
        deltaColor="var(--text-muted)"
      />
      <Divider />
      <RegimeBadge breadth={marketBreadth} vix={vix} />
    </div>
  );
}
