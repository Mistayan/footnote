"use client";
import {
  AreaChart,
  Area,
  ResponsiveContainer,
  Tooltip,
  YAxis,
} from "recharts";

interface Props {
  data: number[];
  positive?: boolean;
}

export default function SparkLine({ data, positive = true }: Props) {
  if (!data || data.length < 2) return <span className="text-xs" style={{ color: "var(--text-muted)" }}>—</span>;
  const color = positive ? "#2E865F" : "#C0392B";
  const rows = data.map((v, i) => ({ i, v }));
  return (
    <ResponsiveContainer width={80} height={32}>
      <AreaChart data={rows} margin={{ top: 2, right: 0, bottom: 2, left: 0 }}>
        <defs>
          <linearGradient id={`g${positive}`} x1="0" y1="0" x2="0" y2="1">
            <stop offset="5%" stopColor={color} stopOpacity={0.4} />
            <stop offset="95%" stopColor={color} stopOpacity={0} />
          </linearGradient>
        </defs>
        <YAxis domain={["auto", "auto"]} hide />
        <Tooltip
          contentStyle={{ background: "#18181b", border: "none", fontSize: 10 }}
          formatter={(v: unknown) => typeof v === "number" ? v.toFixed(2) : String(v)}
          labelFormatter={() => ""}
        />
        <Area
          type="monotone"
          dataKey="v"
          stroke={color}
          strokeWidth={1.5}
          fill={`url(#g${positive})`}
          dot={false}
          isAnimationActive={false}
        />
      </AreaChart>
    </ResponsiveContainer>
  );
}
