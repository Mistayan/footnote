/**
 * Shared UI pattern primitives (Phase 25 cohesion pass).
 *
 * Modeled on the gold-standard pages (EquityPanel, JournalTabs): token-driven,
 * weight <=600, type-scale compliant (11/12/13/14/16/20px), 8px spacing,
 * RSC-safe. Plans 25-03/04 adopt these across all 14 pages.
 */
export { PageHeader } from "./PageHeader";
export type { PageHeaderProps } from "./PageHeader";

export { Card } from "./Card";
export type { CardProps } from "./Card";

export { KpiTile } from "./KpiTile";
export type { KpiTileProps, KpiTone } from "./KpiTile";

export { EmptyState } from "./EmptyState";
export type { EmptyStateProps } from "./EmptyState";
