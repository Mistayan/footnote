import type { ReactNode } from "react";

/**
 * Canonical empty-state (gold standard: JournalTabs.EmptyState).
 *
 * Collapses the three audited variants (gold caps-label + body, the
 * `px-4 py-6` centered inline, and bare `<p>`) onto one primitive:
 * optional 11px caps label + 13px body message, centered.
 *
 * RSC-safe: presentational only, no "use client". `message` accepts a
 * pre-formatted string or ReactNode.
 */
export interface EmptyStateProps {
  /** Optional caps label (11px uppercase, text-secondary). */
  label?: string;
  /** Body copy (13px, text-muted). */
  message: ReactNode;
}

export function EmptyState({ label, message }: EmptyStateProps) {
  return (
    <div className="px-4 py-6 text-center">
      {label && (
        <p
          className="mb-1 text-[11px] uppercase tracking-wide"
          style={{ color: "var(--text-secondary)" }}
        >
          {label}
        </p>
      )}
      <p className="text-[13px]" style={{ color: "var(--text-muted)" }}>
        {message}
      </p>
    </div>
  );
}

export default EmptyState;
