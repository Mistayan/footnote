import type { ReactNode } from "react";

/** Value tone — colors the value via a semantic token (no hardcoded hex). */
export type KpiTone = "gain" | "loss" | "neutral" | "warn";

const TONE_VAR: Record<KpiTone, string> = {
  gain: "var(--gain)",
  loss: "var(--loss)",
  neutral: "var(--text-primary)",
  warn: "var(--warn)",
};

/**
 * Canonical KPI tile (consolidates KpiBar / StrategyKpiBar / OverviewCards tile
 * specs onto one primitive — adopted in later plans 25-03/04).
 *
 * - label: 11px uppercase caps (the audited floor — never 9/10px), text-secondary
 * - value: mono tabular-nums, text-lg, weight <=600, tone-colored
 * - sub:   optional 11px meta line, text-muted
 *
 * RSC-safe: presentational only, no "use client". `value`/`sub` accept
 * pre-formatted strings (or ReactNode) — no formatter crosses the
 * server->client boundary (Phase 22 rule).
 */
export interface KpiTileProps {
  /** Caps label (11px, tracking-wide, text-secondary). */
  label: string;
  /** Pre-formatted value (mono, tabular-nums). */
  value: ReactNode;
  /** Optional secondary line (11px, text-muted). */
  sub?: ReactNode;
  /** Value color tone. Defaults to neutral (text-primary). */
  tone?: KpiTone;
  /** Extra classes for layout composition. */
  className?: string;
}

export function KpiTile({
  label,
  value,
  sub,
  tone = "neutral",
  className = "",
}: KpiTileProps) {
  return (
    <div className={className}>
      <p
        className="text-[11px] uppercase tracking-wide"
        style={{ color: "var(--text-secondary)" }}
      >
        {label}
      </p>
      <p
        className="mt-1 font-mono tabular-nums text-lg font-semibold"
        style={{ color: TONE_VAR[tone] }}
      >
        {value}
      </p>
      {sub != null && (
        <p
          className="mt-0.5 text-[11px]"
          style={{ color: "var(--text-muted)" }}
        >
          {sub}
        </p>
      )}
    </div>
  );
}

export default KpiTile;
