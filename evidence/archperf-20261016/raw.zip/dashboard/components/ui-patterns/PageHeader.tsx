import type { ReactNode } from "react";

export interface PageHeaderProps {
  /** Page title — 24px primary heading, tracking-tight, weight 800. */
  title: string;
  /** Optional secondary line under the title (13px body-sm, text-secondary). */
  subtitle?: string;
  /** Optional right-aligned slot (e.g. a status chip or single ghost action). */
  actions?: ReactNode;
}

export function PageHeader({ title, subtitle, actions }: PageHeaderProps) {
  return (
    <header className="mb-8 flex items-start justify-between gap-4 border-b pb-6" style={{ borderColor: "var(--border-subtle)" }}>
      <div className="min-w-0">
        <h1
          className="text-2xl font-extrabold tracking-tight text-white"
        >
          {title}
        </h1>
        {subtitle && (
          <p
            className="mt-1 text-[13px] font-medium"
            style={{ color: "var(--text-secondary)" }}
          >
            {subtitle}
          </p>
        )}
      </div>
      {actions && <div className="shrink-0">{actions}</div>}
    </header>
  );
}

export default PageHeader;
