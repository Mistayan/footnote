import type { ReactNode } from "react";

/**
 * Canonical container surface (gold standard: EquityPanel card chrome).
 *
 * rounded-[6px] p-6, var(--surface-raised) background, 1px var(--border-subtle)
 * border by DEFAULT. Per the 25-01 accent-border demotion policy, neutral
 * containers use --border-subtle; --borg-accent-border is reserved for genuine
 * emphasis (opt in via `emphasis`).
 *
 * RSC-safe: presentational only, no "use client". Accepts ReactNode children
 * so server or client callers can pass pre-formatted content.
 */
export interface CardProps {
  children: ReactNode;
  /** Extra classes (e.g. override padding `!p-0`, add spacing utilities). */
  className?: string;
  /** Switches the border to the accent token for the rare accented case. */
  emphasis?: boolean;
  /** Accessible label when the card is a meaningful region. */
  "aria-label"?: string;
}

export function Card({
  children,
  className = "",
  emphasis = false,
  "aria-label": ariaLabel,
}: CardProps) {
  return (
    <section
      className={`rounded-[6px] p-6 premium-card-hover animate-fade-in-up ${className}`}
      style={{
        background: "var(--surface-raised)",
        border: `1px solid ${
          emphasis ? "var(--borg-accent-border)" : "var(--border-subtle)"
        }`,
      }}
      aria-label={ariaLabel}
    >
      {children}
    </section>
  );
}

export default Card;
