"use client";
import { useEffect, useState } from "react";
export type Signal = {
  ticker: string;
  action?: string;
  score?: number;
  price?: number;
  stop?: number;
  atr?: number;
  sector?: string;
  name?: string;
  score_decay?: number;
  price_history?: number[];
};

export type LivePayload = {
  timestamp?: string;
  market_breadth?: number;
  vix?: number;
  alpha_signals?: Signal[];
  risky_signals?: Signal[];
};
import SparkLine from "./SparkLine";
import KpiBar from "./KpiBar";
import { getTickerName } from "@/lib/tickerHelper";

// ── Action badge ─────────────────────────────────────────
function ActionBadge({ action }: { action?: string }) {
  const cfg =
    action === "BUY"
      ? { color: "var(--gain)", bg: "var(--gain-bg)", border: "var(--gain-border)", label: "BUY" }
      : action === "SELL"
      ? { color: "var(--loss)", bg: "var(--loss-bg)", border: "var(--loss-border)", label: "SELL" }
      : { color: "var(--text-muted)", bg: "transparent", border: "var(--border-subtle)", label: action ?? "—" };

  return (
    <span
      className="inline-flex items-center gap-1 text-xs font-medium px-1.5 py-0.5 rounded"
      style={{ color: cfg.color, background: cfg.bg, border: `1px solid ${cfg.border}` }}
    >
      <span className="w-1.5 h-1.5 rounded-full shrink-0" style={{ background: cfg.color }} />
      {cfg.label}
    </span>
  );
}

// ── Shadow positions ─────────────────────────────────────
export type ShadowPosition = {
  ticker: string;
  strategy: string | null;
  entry_eur: number;
  current_eur: number | null;
  shares: number;
  unrealized_eur: number | null;
  unrealized_pct: number | null;
};

export type ShadowPayload = {
  generated_at?: string;
  open_count?: number;
  unpriced_count?: number;
  total_unrealized_eur?: number;
  positions?: ShadowPosition[];
};

const fmtEur = (v: number | null): string => (v == null ? "—" : v.toFixed(2));
const pnlColor = (v: number | null): string =>
  v == null ? "var(--text-muted)" : v > 0 ? "var(--gain)" : v < 0 ? "var(--loss)" : "var(--text-muted)";

function ShadowTable({ shadow }: { shadow: ShadowPayload | null }) {
  const rows = shadow?.positions ?? [];
  if (!rows.length) return null;
  const total = shadow?.total_unrealized_eur ?? 0;
  return (
    <section className="mb-8">
      <h2
        className="text-sm font-semibold mb-3 uppercase tracking-wide flex items-center gap-3"
        style={{ color: "var(--text-secondary)" }}
      >
        Shadow Positions
        <span className="tabular-nums font-mono text-xs" style={{ color: pnlColor(total) }}>
          {total > 0 ? "+" : ""}{fmtEur(total)}€
        </span>
        {shadow?.generated_at && (
          <span className="text-xs font-normal normal-case" style={{ color: "var(--text-muted)" }}>
            as of {shadow.generated_at}
          </span>
        )}
      </h2>
      <div className="overflow-x-auto rounded-[6px]" style={{ border: "1px solid var(--border-subtle)" }}>
        <table className="w-full text-sm">
          <thead
            className="text-xs uppercase tracking-wide"
            style={{ background: "var(--surface-raised)", color: "var(--text-muted)" }}
          >
            <tr>
              <th scope="col" className="px-3 py-2 text-left">Ticker</th>
              <th scope="col" className="px-3 py-2 text-left">Strategy</th>
              <th scope="col" className="px-3 py-2 text-right tabular-nums">Entry €</th>
              <th scope="col" className="px-3 py-2 text-right tabular-nums">Now €</th>
              <th scope="col" className="px-3 py-2 text-right tabular-nums">Shares</th>
              <th scope="col" className="px-3 py-2 text-right tabular-nums">Unreal. €</th>
              <th scope="col" className="px-3 py-2 text-right tabular-nums">%</th>
            </tr>
          </thead>
          <tbody>
            {rows.map((p, i) => (
              <tr
                key={`${p.ticker}-${i}`}
                className="transition-colors"
                style={{ borderTop: "1px solid var(--border-subtle)", opacity: p.current_eur == null ? 0.45 : 1 }}
                onMouseEnter={(e) => (e.currentTarget.style.background = "var(--surface-hover)")}
                onMouseLeave={(e) => (e.currentTarget.style.background = "")}
              >
                <td className="px-3 py-2" style={{ color: "var(--text-primary)" }}>
                  <div className="flex flex-col py-0.5">
                    <span className="font-semibold text-[13px] leading-tight">{getTickerName(p.ticker)}</span>
                    <span className="text-[10px] font-mono tracking-wider opacity-60 mt-0.5" style={{ color: "var(--text-muted)" }}>{p.ticker}</span>
                  </div>
                </td>
                <td className="px-3 py-2 text-xs" style={{ color: "var(--text-muted)" }}>
                  {p.strategy ?? "—"}
                </td>
                <td className="px-3 py-2 text-right tabular-nums font-mono" style={{ color: "var(--text-secondary)" }}>
                  {fmtEur(p.entry_eur)}
                </td>
                <td className="px-3 py-2 text-right tabular-nums font-mono" style={{ color: "var(--text-primary)" }}>
                  {fmtEur(p.current_eur)}
                </td>
                <td className="px-3 py-2 text-right tabular-nums font-mono" style={{ color: "var(--text-secondary)" }}>
                  {p.shares.toFixed(1)}
                </td>
                <td className="px-3 py-2 text-right tabular-nums font-mono" style={{ color: pnlColor(p.unrealized_eur) }}>
                  {p.unrealized_eur != null && p.unrealized_eur > 0 ? "+" : ""}{fmtEur(p.unrealized_eur)}
                </td>
                <td className="px-3 py-2 text-right tabular-nums font-mono text-xs" style={{ color: pnlColor(p.unrealized_pct) }}>
                  {p.unrealized_pct == null ? "—" : `${p.unrealized_pct > 0 ? "+" : ""}${p.unrealized_pct.toFixed(2)}%`}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </section>
  );
}

// ── Signal table ──────────────────────────────────────────
function SignalTable({ rows, title }: { rows: Signal[]; title: string }) {
  if (!rows.length) return null;
  return (
    <section className="mb-8">
      <h2
        className="text-sm font-semibold mb-3 uppercase tracking-wide"
        style={{ color: "var(--text-secondary)" }}
      >
        {title}
      </h2>
      <div
        className="overflow-x-auto rounded-[6px]"
        style={{ border: "1px solid var(--border-subtle)" }}
      >
        <table className="w-full text-sm">
          <thead
            className="text-xs uppercase tracking-wide"
            style={{ background: "var(--surface-raised)", color: "var(--text-muted)" }}
          >
            <tr>
              <th scope="col" className="px-3 py-2 text-left">Ticker</th>
              <th scope="col" className="px-3 py-2 text-left">Action</th>
              <th scope="col" className="px-3 py-2 text-right tabular-nums">Score</th>
              <th scope="col" className="px-3 py-2 text-right tabular-nums">Price</th>
              <th scope="col" className="px-3 py-2 text-right tabular-nums">Stop</th>
              <th scope="col" className="px-3 py-2 text-left">Sector</th>
              <th scope="col" className="px-3 py-2 text-left">7d</th>
            </tr>
          </thead>
          <tbody>
            {rows.map((s, i) => (
              <tr
                key={`${s.ticker}-${i}`}
                className="transition-colors"
                style={{ borderTop: "1px solid var(--border-subtle)" }}
                onMouseEnter={(e) =>
                  (e.currentTarget.style.background = "var(--surface-hover)")
                }
                onMouseLeave={(e) => (e.currentTarget.style.background = "")}
              >
                <td className="px-3 py-2" style={{ color: "var(--text-primary)" }}>
                  <div className="flex flex-col py-0.5">
                    <span className="font-semibold text-[13px] leading-tight">{getTickerName(s.ticker, s.name)}</span>
                    <span className="text-[10px] font-mono tracking-wider opacity-60 mt-0.5" style={{ color: "var(--text-muted)" }}>{s.ticker}</span>
                  </div>
                </td>
                <td className="px-3 py-2">
                  <div className="flex items-center gap-1.5">
                    <ActionBadge action={s.action} />
                    {s.score_decay != null && s.score_decay > 0 && (
                      <span
                        className="text-xs"
                        style={{ color: "var(--warn)" }}
                        title="score decayed due to low breadth"
                      >
                        ↓{(s.score_decay * 100).toFixed(0)}%
                      </span>
                    )}
                  </div>
                </td>
                <td
                  className="px-3 py-2 text-right tabular-nums font-mono"
                  style={{ color: "var(--borg-accent)" }}
                >
                  {s.score?.toFixed(1) ?? "—"}
                </td>
                <td
                  className="px-3 py-2 text-right tabular-nums font-mono"
                  style={{ color: "var(--text-primary)" }}
                >
                  ${s.price?.toFixed(2) ?? "—"}
                </td>
                <td
                  className="px-3 py-2 text-right tabular-nums font-mono"
                  style={{ color: "var(--text-muted)" }}
                >
                  {s.stop?.toFixed(2) ?? "—"}
                </td>
                <td className="px-3 py-2" style={{ color: "var(--text-muted)" }}>
                  {s.sector ?? "—"}
                </td>
                <td className="px-3 py-2">
                  {s.price_history && s.price_history.length > 1 ? (
                    <SparkLine
                      data={s.price_history}
                      positive={(s.price_history.at(-1) ?? 0) >= (s.price_history[0] ?? 0)}
                    />
                  ) : (
                    <span style={{ color: "var(--text-muted)" }} className="text-xs">—</span>
                  )}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </section>
  );
}

// ── Main component ────────────────────────────────────────
interface PortfolioSummary {
  total_value_eur: number | null;
  unrealized_pnl_net_eur: number | null;
  positions_count: number | null;
  win_rate_90d: number | null;
}

interface Props { initial: LivePayload | null; shadow?: ShadowPayload | null; }

export default function LiveDashboard({ initial, shadow = null }: Props) {
  const [data, setData] = useState<LivePayload | null>(initial);
  const [live, setLive] = useState(false);
  const [summary, setSummary] = useState<PortfolioSummary | null>(null);

  useEffect(() => {
    const es = new EventSource("/api/stream");
    es.addEventListener("signal", (e) => {
      try {
        setData(JSON.parse(e.data) as LivePayload);
        setLive(true);
      } catch { /* ignore */ }
    });
    return () => es.close();
  }, []);

  useEffect(() => {
    const apiUrl = process.env.NEXT_PUBLIC_API_URL ?? "http://localhost:8000";
    fetch(`${apiUrl}/portfolio-summary`)
      .then((r) => r.ok ? r.json() as Promise<PortfolioSummary> : null)
      .then((s) => { if (s) setSummary(s); })
      .catch(() => {});
  }, []);

  const allSignals = [
    ...(data?.alpha_signals ?? []),
    ...(data?.risky_signals ?? []),
  ];
  const signalCount = allSignals.length;

  return (
    <main className="px-4 py-6 md:px-8 md:py-8">
      <KpiBar
        portfolioEur={summary?.total_value_eur}
        dailyPnlEur={summary?.unrealized_pnl_net_eur}
        positionsCount={summary?.positions_count}
        winRate={summary?.win_rate_90d}
        marketBreadth={data?.market_breadth}
        vix={data?.vix}
        signalCount={signalCount > 0 ? signalCount : null}
      />

      {!data ? (
        <p style={{ color: "var(--text-muted)" }}>
          No <code className="font-mono">live_signals.json</code> yet. Run{" "}
          <code className="font-mono">python -m simulator.live_monitor</code>.
        </p>
      ) : (
        <>
          <SignalTable rows={data.alpha_signals ?? []} title="Alpha Signals" />
          <SignalTable rows={data.risky_signals ?? []} title="Risky Signals" />
        </>
      )}

      <ShadowTable shadow={shadow} />
    </main>
  );
}
