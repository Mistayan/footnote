"use client";
import { useEffect, useRef, useState, useTransition } from "react";
import { useRouter } from "next/navigation";
import { STRATEGY_ORDER, stratLabel } from "@/lib/strategies";
import type { JournalPageResult, JournalQuery } from "@/lib/journalQuery";
import JournalTable from "@/components/JournalTable";
const TABS = [{key:"all",label:"All"},...STRATEGY_ORDER.map(key=>({key,label:stratLabel(key)}))];
const CONTROL="block w-full min-h-12 rounded p-3 mt-2 bg-[var(--surface-raised)] border border-[var(--border-default)]";
export default function JournalTabs({result}:{result:JournalPageResult}) {
  const router=useRouter(); const [pending,startTransition]=useTransition();
  const [draft,setDraft]=useState(result.query); const tabRefs=useRef<Array<HTMLButtonElement|null>>([]);
  useEffect(()=>setDraft(result.query),[result.query]);
  const state=result.query, activeIndex=TABS.findIndex(t=>t.key===state.strategy);
  const start=(state.page-1)*state.size;
  function update(next:JournalQuery) {
    const url=new URL(window.location.href);
    for(const [key,value] of Object.entries(next)) {
      if(value===""||(key==="strategy"&&value==="all")||(key==="page"&&value===1)||(key==="size"&&value===25)||(key==="sort"&&value==="desc")) url.searchParams.delete(key);
      else url.searchParams.set(key,String(value));
    }
    startTransition(()=>router.push(url.pathname+url.search,{scroll:false}));
  }
  function focusTab(index:number) {const next=(index+TABS.length)%TABS.length; update({...draft,strategy:TABS[next].key,page:1}); tabRefs.current[next]?.focus();}
  return <div className="space-y-4" aria-busy={pending}>
    {result.generatedAt&&<p className="text-xs text-[var(--text-muted)]">File generated {result.generatedAt} · not a market freshness receipt</p>}
    <div role="tablist" aria-label="Trade journal strategies" className="flex flex-wrap gap-1 rounded p-1 bg-[var(--surface-raised)]" onKeyDown={e=>{
      const targets:Record<string,number>={ArrowRight:activeIndex+1,ArrowDown:activeIndex+1,ArrowLeft:activeIndex-1,ArrowUp:activeIndex-1,Home:0,End:TABS.length-1};
      if(e.key in targets){e.preventDefault();focusTab(targets[e.key]);}
    }}>
      {TABS.map((tab,i)=><button key={tab.key} ref={el=>{tabRefs.current[i]=el;}} role="tab" id={`journal-tab-${tab.key}`} aria-selected={tab.key===state.strategy} aria-controls="journal-panel" tabIndex={tab.key===state.strategy?0:-1} type="button" className="journal-tab min-h-12 px-3 rounded text-sm" style={{color:tab.key===state.strategy?"var(--text-primary)":"var(--text-muted)",background:tab.key===state.strategy?"var(--surface-overlay)":"transparent"}} onClick={()=>update({...draft,strategy:tab.key,page:1})}>{tab.label}</button>)}
    </div>
    <form className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-4" onSubmit={e=>{e.preventDefault();update({...draft,page:1});}}>
      <label className="block text-sm">Search journal<input aria-label="Search journal" className={CONTROL} type="search" value={draft.q} onChange={e=>setDraft({...draft,q:e.target.value})}/></label>
      <label className="block text-sm">From source date<input className={CONTROL} type="date" value={draft.from} onChange={e=>setDraft({...draft,from:e.target.value})}/></label>
      <label className="block text-sm">To source date<input className={CONTROL} type="date" value={draft.to} onChange={e=>setDraft({...draft,to:e.target.value})}/></label>
      <label className="block text-sm">Date order<select className={CONTROL} value={draft.sort} onChange={e=>setDraft({...draft,sort:e.target.value as 'asc'|'desc'})}><option value="desc">Newest first</option><option value="asc">Oldest first</option></select></label>
      <label className="block text-sm">Rows per page<select className={CONTROL} value={draft.size} onChange={e=>setDraft({...draft,size:Number(e.target.value)})}>{[...new Set([25,50,100,draft.size])].map(n=><option key={n} value={n}>{n}</option>)}</select></label>
      <button type="submit" disabled={pending} className="min-h-12 px-3 rounded border disabled:opacity-60">Apply filters</button>
    </form>
    <p role="status" className="text-sm text-[var(--text-secondary)]">{pending?"Loading journal page…":result.status==='ready'?`${result.matching?start+1:0}–${start+result.rows.length} of ${result.matching} matching · ${result.total} total source rows · ${result.omitted} matching rows omitted from this page · page ${state.page} of ${result.pages}`:"Source and matching counts unknown."}</p>
    {result.status!=='ready'&&<div role="alert" className="p-4"><p>{result.error}</p><button className="min-h-12 px-3 rounded border" onClick={()=>startTransition(()=>router.refresh())}>Retry journal</button></div>}
    <div role="tabpanel" id="journal-panel" aria-labelledby={`journal-tab-${state.strategy}`} tabIndex={0}>
      {result.status==='ready'&&(result.rows.length?<JournalTable rows={result.rows} showStrategy={state.strategy==='all'}/>:<p className="p-4 text-sm text-[var(--text-secondary)]">{result.total===0?"No journal events in this source file.":state.strategy==='etf-allocation'?"Research replay only — no runtime trades published for ETF Allocation.":"No matching journal rows."}</p>)}
    </div>
    <nav aria-label="Journal pages" className="flex flex-wrap gap-4">
      <button type="button" className="min-h-12 px-3 rounded border disabled:opacity-60" disabled={pending||result.status!=='ready'||state.page<=1} onClick={()=>update({...state,page:state.page-1})}>Previous page</button>
      <button type="button" className="min-h-12 px-3 rounded border disabled:opacity-60" disabled={pending||result.status!=='ready'||state.page>=result.pages} onClick={()=>update({...state,page:state.page+1})}>Next page</button>
    </nav>
  </div>;
}
