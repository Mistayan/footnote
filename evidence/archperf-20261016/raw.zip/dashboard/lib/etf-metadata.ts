// Seven days is a display warning threshold, not a backtest validation gate.
export function etfFeedStatus(generated?: string, historyEnd?: string, now = new Date()) {
  const parse = (value?: string) => {
    if (typeof value !== "string" || !/^\d{4}-\d{2}-\d{2}(?:T.*)?$/.test(value)) return NaN;
    const stamp = Date.parse(value);
    return Number.isFinite(stamp) && new Date(stamp).toISOString().slice(0, 10) === value.slice(0, 10) ? stamp : NaN;
  };
  const published = parse(generated);
  const observed = parse(historyEnd);
  const today = Date.parse(now.toISOString().slice(0, 10));
  const publicationDay = Number.isFinite(published) ? Date.parse(new Date(published).toISOString().slice(0, 10)) : NaN;
  if (!Number.isFinite(published) || !Number.isFinite(observed) || publicationDay > today || observed > published) {
    return "Freshness unverified: missing, invalid, future or inconsistent dates; not current certification.";
  }
  const days = (stamp: number) => Math.floor((today - stamp) / 86_400_000);
  return `${days(publicationDay) > 7 || days(observed) > 7 ? "Stale historical evidence" : "Historical evidence"}: published ${generated}, observed through ${historyEnd} (${days(publicationDay)} / ${days(observed)} days old; 7-day display warning threshold); not current certification. A publication timestamp does not prove a fresh run.`;
}

export type EtfTaxModel = { tax_basis?: string; liquidation_at_report_end?: boolean; applied_tax_eur?: number };

export function etfTaxPresentation(model: EtfTaxModel | undefined, limitations: string[] = [], assumptions: string[] = []) {
  const marked = model?.tax_basis === "realized_sales_only" && model.liquidation_at_report_end === false;
  const liquidated = model?.tax_basis === "realized_sales_only" && model.liquidation_at_report_end === true;
  const caveats = [...limitations, ...assumptions].map(text => marked && /terminal\s+CTO\s+gain\s+proxy/i.test(text)
    ? "Metadata conflict: terminal-tax prose conflicts with structured realized-sales-only, no-liquidation metadata; that terminal claim is not applied. Account-specific withholding and broker FX markup are not modeled."
    : text);
  return {
    valueLabel: marked ? "Marked value after realized-sales tax" : liquidated ? "Terminal liquidation value after modeled tax" : "Published tax-adjusted value (basis unverified)",
    taxLabel: marked || liquidated ? "Realized-sales tax" : "Published tax (basis unverified)",
    explanation: marked ? "Tax basis: realized_sales_only; no liquidation at report end. Open holdings remain marked; this is not terminal liquidation proceeds. Zero tax does not mean a tax-free exit." : liquidated ? "Tax basis: realized_sales_only; liquidation at report end is modeled. This is modeled liquidation value, not a broker tax assessment." : "Tax basis or liquidation metadata is missing or unsupported; terminal liquidation proceeds are not verified.",
    caveats,
  };
}
