import { validateDashboardIndex, type DashboardIndex } from "./dashboardSchema";

export async function loadDashboardIndex(fetcher: typeof fetch = fetch): Promise<DashboardIndex> {
  const response = await fetcher("/dashboard_index.json", { cache: "no-store" });
  if (!response.ok) throw new Error(`dashboard_index fetch failed: ${response.status}`);
  return validateDashboardIndex(await response.json());
}
