import { STRATEGY_ORDER } from './strategies';
export interface JournalFeedRow {
  strategy: string; ticker: string; name: string; action: string;
  qty: number | null; price: number | null; datetime: string; date: string; state: string; pnl?: number | null;
}
export interface JournalQuery { strategy: string; q: string; from: string; to: string; sort: 'desc' | 'asc'; page: number; size: number }
export interface JournalPageResult {
  status: 'ready' | 'unavailable' | 'blocked'; query: JournalQuery; rows: JournalFeedRow[];
  total: number | null; matching: number | null; omitted: number | null; pages: number;
  generatedAt?: string; sourceHash?: string; error?: string;
}
export function parseJournalQuery(params: URLSearchParams): JournalQuery {
  const integer=(key:string,fallback:number,max:number)=>{const raw=Number(params.get(key)); return Number.isSafeInteger(raw)&&raw>0?Math.min(raw,max):fallback;};
  const strategy=params.get('strategy')||'all';
  return {strategy:STRATEGY_ORDER.includes(strategy)?strategy:'all',q:params.get('q')||'',from:params.get('from')||'',to:params.get('to')||'',sort:params.get('sort')==='asc'?'asc':'desc',page:integer('page',1,Number.MAX_SAFE_INTEGER),size:integer('size',25,100)};
}
export function journalRows(feed: unknown): JournalFeedRow[] {
  const source=feed as {by_strategy?:Record<string,Omit<JournalFeedRow,'strategy'>[]>};
  if(!source || !source.by_strategy || typeof source.by_strategy!=='object' || Array.isArray(source.by_strategy)) throw new Error('Invalid journal collection');
  // Match the original loader's seeded bucket order, including stable ties.
  const buckets={...Object.fromEntries(STRATEGY_ORDER.map(k=>[k,[]])),...source.by_strategy};
  const all=Object.entries(buckets).flatMap(([strategy,rows])=> {
    if(!Array.isArray(rows)) throw new Error('Invalid journal bucket');
    return rows.map(r=>{if(!r || ['ticker','name','action','datetime','date','state'].some(k=>typeof r[k as keyof Omit<JournalFeedRow,'strategy'>]!=='string')) throw new Error('Invalid journal row'); if(['qty','price','pnl'].some(k=>{const value=r[k as 'qty'|'price'|'pnl']; return value!=null&&(typeof value!=='number'||!Number.isFinite(value));})) throw new Error('Invalid journal number'); return {strategy,...r};});
  });
  return all;
}
export function queryJournal(feed: unknown, query: JournalQuery): JournalPageResult {
  const source=feed as {generated_at?:string};
  const all=journalRows(feed);
  const q=query.q.toLocaleLowerCase();
  const rows=all.filter(r=>(query.strategy==='all'||r.strategy===query.strategy)
    && (!q || `${r.ticker} ${r.name} ${r.action} ${r.state} ${r.datetime}`.toLocaleLowerCase().includes(q))
    && (!query.from || r.date>=query.from) && (!query.to || r.date<=query.to))
    .sort((a,b)=>query.sort==='asc'?a.datetime.localeCompare(b.datetime):b.datetime.localeCompare(a.datetime));
  const pages=Math.max(1,Math.ceil(rows.length/query.size)), page=Math.min(query.page,pages), start=(page-1)*query.size;
  return {status:'ready',query:{...query,page},rows:rows.slice(start,start+query.size),total:all.length,matching:rows.length,omitted:rows.length-Math.min(query.size,rows.length-start),pages,generatedAt:source.generated_at};
}
