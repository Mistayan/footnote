import fs from 'node:fs/promises';
import path from 'node:path';
import { createHash } from 'node:crypto';
import { loadRestatementKpis } from './restatementAdapter';
import { adaptBorgDivAttribution, attributionFromEvents, type BorgDivAttributionModel } from './borgdivAttribution';

export async function loadBorgDivAttribution(): Promise<BorgDivAttributionModel> {
  try {
    const directory = process.env.BORG_RESTATEMENT_DIR;
    if (directory) {
      const legacy = process.env.BORG_RESTATEMENT_LEGACY_KPIS;
      if (!legacy) throw new Error('Missing frozen lineage');
      await loadRestatementKpis(directory, legacy);
      const [bytes, manifestBytes] = await Promise.all(['restatement.json','manifest.json'].map(name=>fs.readFile(path.join(directory,name))));
      const hash = createHash('sha256').update(bytes).digest('hex');
      const manifest = JSON.parse(manifestBytes.toString('utf8'));
      if (manifest.outputs['restatement.json'] !== hash) throw new Error('Changed report');
      return adaptBorgDivAttribution(JSON.parse(bytes.toString('utf8')), hash);
    }
    const [bytes,kpiBytes] = await Promise.all(['trades.json','kpis.json'].map(name=>fs.readFile(path.join(process.cwd(),'public',name))));
    const kpi = JSON.parse(kpiBytes.toString('utf8'));
    if (kpi.protocol === 'ORIGINAL_FILLS_RESTATEMENT_V1') throw new Error('Unvalidated sidecar');
    return attributionFromEvents(JSON.parse(bytes.toString('utf8')), kpi.per_strategy?.borgdiv, createHash('sha256').update(bytes).digest('hex'));
  } catch {
    // No public fallback from a selected, missing or rejected frozen lane.
    return { ...adaptBorgDivAttribution(null), status: process.env.BORG_RESTATEMENT_DIR ? 'invalid' : 'unavailable' };
  }
}
