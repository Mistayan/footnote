type Obj = Record<string, unknown>;
const obj = (v: unknown): Obj => v !== null && typeof v === 'object' && !Array.isArray(v) ? v as Obj : {};
const num = (v: unknown): number | null => typeof v === 'number' && Number.isFinite(v) ? v : null;
const str = (v: unknown): string | null => typeof v === 'string' && v.length > 0 ? v : null;
const list = (v: unknown): Obj[] => Array.isArray(v) ? v.map(obj) : [];
const day = (v: unknown): string | null => typeof v === 'string' && /^\d{4}-\d{2}-\d{2}$/.test(v) && Number.isFinite(Date.parse(v)) && new Date(v).toISOString().slice(0, 10) === v ? v : null;
export type ReturnClassification = 'legacy-pre-ex' | 'mixed-winner' | 'retained-post-ex' | 'other-sale' | 'unclassified' | 'open';
export type ReturnSale = {
  id: string; tradeId: string | null; ticker: string; eventId: string | null;
  entryDate: string | null; date: string | null; exDate: string | null; closed: boolean;
  strategyVersion: string; historicalQ: boolean; recordedRegime: string | null; reason: string; classification: ReturnClassification;
  classificationBasis: string; source: string | null; included: boolean | null;
  gross: number | null; acquisitionCost: number | null; disposalCost: number | null;
  saleTax: number | null; net: number | null; evidence: 'actual' | 'modeled' | 'unknown';
};
export type ReturnCash = { id: string | null; obligationId: string | null; tradeId: string | null; eventId: string | null; strategyVersion: string; date: string | null; source: string | null; kind: 'dividend' | 'cash-yield'; evidence: 'actual' | 'modeled' | 'unknown'; status: 'paid' | 'estimated-unpaid' | 'unverified'; gross: number | null; withholding: number | null; net: number | null };
export type CashAmounts = { gross: number | null; withholding: number | null; net: number | null; count: number };
export type ReturnAttribution = {
  protocol: 'BORGDIV_RETURN_ATTRIBUTION_V1'; sales: ReturnSale[]; cash: ReturnCash[];
  buckets: Record<Exclude<ReturnClassification, 'open'>, { count: number; gross: number | null; net: number | null; netActual: number | null; netModeled: number | null }>;
  paid: { actual: CashAmounts; modeled: CashAmounts }; cashYield: { actual: CashAmounts; modeled: CashAmounts };
  estimatedUnpaid: number | null; totalNet: { actual: number | null; modeled: number | null };
  priceReconciliation: { bucketSum: number | null; originalSaleSum: number | null; difference: number | null };
  issues: string[]; source: string | null;
};
const sum = (values: (number | null)[]): number | null => values.some(v => v === null) ? null : values.reduce<number>((s, v) => s + v!, 0);

/** Read-only, signed original-fill diagnostics. Missing costs/receipts never become zero.
 * The optional explicit return ledger is defined in BORGDIV_RETURN_ATTRIBUTION.md. */
export function buildBorgDivReturnAttribution(input: unknown, source: string | null = null): ReturnAttribution {
  const report = obj(input), attribution = obj(report.performance_attribution);
  const backend = attribution.protocol === 'ORIGINAL_PRICE_PNL_ATTRIBUTION_V1' ? list(attribution.closed_trades) : [];
  const cutoff = day(report.as_of ?? obj(report.return_attribution).as_of);
  const issues: string[] = [];
  const original = list(report.original_rows).filter(r => r.strategy === 'borgdiv');
  const originalIdentity = (r: Obj): boolean => {
    const id = str(r.trade_id), entry = day(r.entry_date), ex = day(r.target_ex_date);
    const quantity = num(r.shares), price = num(r.entry_price_eur);
    const event = str(r.target_event_id ?? r.event_id);
    const matches = backend.filter(b => b.trade_id === id && b.strategy === 'borgdiv');
    return !!id && original.filter(o => o.trade_id === id).length === 1 && !!str(r.ticker)
      && quantity !== null && quantity > 0 && price !== null && price > 0 && !!entry
      && (r.status === undefined || r.status === 'open' || r.status === 'closed')
      && (r.status !== 'closed' || !!day(r.exit_date))
      && (!cutoff || entry <= cutoff) && matches.length <= 1
      && matches.every(b => (b.ticker === undefined || b.ticker === r.ticker)
        && (b.target_event_id === undefined || event === null || b.target_event_id === event)
        && (b.target_ex_date_used === undefined || ex === null || b.target_ex_date_used === ex))
      && (r.target_event_id == null || r.event_id == null || r.target_event_id === r.event_id);
  };
  const sales: ReturnSale[] = original.map((r, index) => {
    const tradeId = str(r.trade_id), matching = backend.filter(b => b.trade_id === tradeId && b.strategy === 'borgdiv');
    const b = matching.length === 1 ? matching[0] : {};
    const entryDate = day(r.entry_date), date = day(r.exit_date), exDate = day(b.target_ex_date_used ?? r.target_ex_date);
    const reason = str(b.exit_reason ?? r.exit_reason) ?? 'Unknown exit reason';
    const entry = num(r.entry_price_eur), exit = num(r.exit_price_eur), quantity = num(r.shares);
    const unique = originalIdentity(r);
    const withinCutoff = !cutoff || !!entryDate && entryDate <= cutoff && (!date || date <= cutoff);
    if (!withinCutoff) issues.push(`Sale withheld beyond report cutoff: ${tradeId ?? index}`);
    const valid = withinCutoff && unique && entry !== null && entry > 0 && exit !== null && exit > 0 && quantity !== null && quantity > 0 && !!entryDate && !!date && date >= entryDate;
    const calculated = valid ? (exit! - entry!) * quantity! : null;
    const stored = num(b.realized_price_pnl_eur);
    const gross = calculated !== null && matching.length <= 1 && (stored === null || Math.abs(stored - calculated) <= 0.005) ? stored ?? calculated : null;
    const closed = r.status === 'closed' || r.exit_date !== null && r.exit_date !== undefined;
    const historicalQ = str(r.regime)?.includes('QuantPreExRunup') === true || b.strategy_identity === 'original_Q_not_MIXED';
    const strategyVersion = str(r.strategy_version ?? b.strategy_version) ?? (historicalQ ? 'Historical Q · original fills' : 'Unknown version');
    let classification: ReturnClassification = closed ? 'unclassified' : 'open';
    let classificationBasis = 'Missing stable identity, targeted-event boundary or recorded exit intent';
    if (withinCutoff && unique && date && entryDate && date >= entryDate) {
      if (exDate && entryDate < exDate && date < exDate && reason === 'quant_pre_ex' && historicalQ) {
        classification = 'legacy-pre-ex'; classificationBasis = 'Recorded Q quant_pre_ex exit + target date boundary; not a MIXED winner';
      } else if (exDate && entryDate < exDate && date >= exDate && ['recovery', 'price_recovery', 'entry_cost_recovery', 'ENTRY_COST_RECOVERY'].includes(reason)) {
        classification = 'retained-post-ex'; classificationBasis = 'Recorded recovery exit + entry before / sale on or after targeted ex-date';
      } else if (['late_exit_missed', 'risk_stop', 'stop_loss', 'max_hold', 'timeout', 'RISK_STOP', 'MAX_HOLD'].includes(reason)) {
        classification = 'other-sale'; classificationBasis = 'Recorded risk, timeout or missed exit; not dividend income or successful recovery';
      }
    }
    return { id: tradeId ?? `unidentified-row-${index}`, tradeId, ticker: str(r.ticker) ?? 'Unknown listing', eventId: str(b.target_event_id ?? r.target_event_id ?? r.event_id), entryDate, date, exDate, closed, strategyVersion, historicalQ, recordedRegime: str(r.regime ?? b.recorded_regime), reason, classification, classificationBasis, source: str(b.original_row_sha256 ?? r.original_row_sha256) ?? source, included: typeof b.included_in_active_totals === 'boolean' ? b.included_in_active_totals : null, gross, acquisitionCost: null, disposalCost: null, saleTax: null, net: null, evidence: 'unknown' };
  });
  const ledger = obj(report.return_attribution);
  const entries = ledger.protocol === 'BORGDIV_RETURN_ATTRIBUTION_V1' ? list(ledger.entries) : [];
  // An empty/missing original array is not an evidenced empty BorgDiv cohort.
  const cohortValid = Array.isArray(report.original_rows) && original.length > 0
    && report.original_rows.every(r => !!str(obj(r).strategy)) && original.every(originalIdentity);
  const schemaValid = ledger.protocol === 'BORGDIV_RETURN_ATTRIBUTION_V1' && Array.isArray(ledger.entries)
    && ledger.entries.every(e => ['sale', 'dividend', 'cash-yield', 'deposit'].includes(String(obj(e).kind)));
  if (!cohortValid) issues.push('Original cohort missing, malformed or ambiguous: completeness withheld.');
  if (!schemaValid) issues.push('Return ledger schema missing or malformed: completeness withheld.');
  const coverage = obj(ledger.coverage);
  for (const s of sales) {
    const matches = entries.filter(e => e.kind === 'sale' && e.trade_id === s.tradeId);
    const e = matches.length === 1 ? matches[0] : {};
    const evidence = e.evidence === 'actual' || e.evidence === 'modeled' ? e.evidence : 'unknown';
    const acquisition = num(e.acquisition_cost_eur), disposal = num(e.disposal_cost_eur), tax = num(e.sale_tax_eur);
    const supported = !!cutoff && s.closed && !!s.date && s.date <= cutoff && !!str(e.source) && evidence !== 'unknown' && e.cost_basis === 'price_only' && num(e.gross_eur) !== null && s.gross !== null && Math.abs((e.gross_eur as number) - s.gross) <= 0.005
      && (e.date === undefined || !!day(e.date) && day(e.date)! >= s.date && day(e.date)! <= cutoff)
      && (e.event_id === undefined || e.event_id === s.eventId) && (e.ticker === undefined || e.ticker === s.ticker);
    if (supported) {
      s.evidence = evidence; s.source = str(e.source);
      s.acquisitionCost = acquisition !== null && acquisition >= 0 ? acquisition : null;
      s.disposalCost = disposal !== null && disposal >= 0 ? disposal : null;
      s.saleTax = tax !== null && tax >= 0 ? tax : null;
      if (s.acquisitionCost !== null && s.disposalCost !== null && s.saleTax !== null) s.net = s.gross! - s.acquisitionCost - s.disposalCost - s.saleTax;
    }
    if (!s.historicalQ && supported && s.gross! > 0 && s.eventId && s.entryDate && s.date && s.exDate && s.entryDate < s.exDate && s.date < s.exDate && ['MIXED_V1', 'BORGDIV_MIXED_V1'].includes(s.strategyVersion) && ['pre_ex_winner', 'PRE_EX_WINNER'].includes(s.reason) && str(e.winner_selection_source) && e.next_exchange_session_verified === true) {
      s.classification = 'mixed-winner'; s.classificationBasis = `Recorded pre_ex_winner + target event + next-session boundary + selection ${e.winner_selection_source}`;
    }
    if (matches.length > 1) issues.push(`Duplicate sale evidence: ${s.id}`);
  }
  const cashEntries = entries.filter(e => e.kind === 'dividend' || e.kind === 'cash-yield');
  const cash: ReturnCash[] = cashEntries.map(e => {
    const gross = num(e.gross_eur), withholding = num(e.withholding_eur), net = num(e.net_eur);
    const evidence = e.evidence === 'actual' || e.evidence === 'modeled' ? e.evidence : 'unknown';
    const kind = e.kind === 'dividend' ? 'dividend' : 'cash-yield';
    const identity = !!str(e.id) && !!str(e.economic_obligation_id) && !!str(e.source) && !!day(e.date) && (kind === 'cash-yield' || (!!str(e.trade_id) && !!str(e.event_id)));
    const paymentDate = day(e.date);
    const originals = original.filter(r => r.trade_id === e.trade_id);
    const r = originals.length === 1 ? originals[0] : {};
    const entryDate = day(r.entry_date), exDate = day(r.target_ex_date), exitDate = day(r.exit_date);
    const quantity = num(r.shares), entitled = num(e.entitled_quantity);
    const closed = r.status === 'closed' || r.exit_date != null;
    const entitlement = kind === 'cash-yield' || originals.length === 1 && originalIdentity(r)
      && str(r.target_event_id ?? r.event_id) === e.event_id && !!entryDate && !!exDate && entryDate < exDate
      && !!paymentDate && exDate <= paymentDate && !!cutoff && exDate <= cutoff
      && (!closed || !!exitDate && exitDate >= exDate && exitDate >= entryDate)
      && (e.ticker === undefined || e.ticker === r.ticker)
      && entitled !== null && entitled > 0 && quantity !== null && entitled <= quantity;
    const cashOnly = kind === 'cash-yield' || e.distribution_type === 'cash';
    const valid = identity && entitlement && cashOnly && !!cutoff && paymentDate !== null && paymentDate <= cutoff && evidence !== 'unknown' && gross !== null && gross >= 0 && withholding !== null && withholding >= 0 && withholding <= gross && net !== null && net >= 0 && Math.abs(gross - withholding - net) <= 0.005;
    if (!valid) issues.push(`Cash receipt withheld: invalid identity, quantity, cash semantics or entry/ex/payment/cutoff chronology: ${str(e.id) ?? 'unknown'}`);
    return { id: str(e.id), obligationId: str(e.economic_obligation_id), tradeId: str(e.trade_id), eventId: str(e.event_id), strategyVersion: str(e.strategy_version) ?? 'Unknown version', date: day(e.date), source: str(e.source), kind, evidence, status: e.status === 'paid' && valid ? 'paid' : e.status === 'estimated-unpaid' && valid ? 'estimated-unpaid' : 'unverified', gross, withholding, net: valid ? net : null };
  });
  // Economic identity, not receipt ID or payment date, is the deduplication key.
  const seen = new Map<string, ReturnCash>();
  const quantities = new Map<ReturnCash, number | null>();
  cash.forEach((c, i) => quantities.set(c, num(cashEntries[i].entitled_quantity)));
  const deduped: ReturnCash[] = [];
  for (const c of cash) {
    const key = c.obligationId ? `${c.kind}:${c.evidence}:${c.obligationId}` : null;
    const prior = key ? seen.get(key) : undefined;
    if (!prior) { deduped.push(c); if (key) seen.set(key, c); continue; }
    if (quantities.get(prior) !== quantities.get(c) || prior.gross !== c.gross || prior.withholding !== c.withholding || prior.net !== c.net || prior.tradeId !== c.tradeId || prior.eventId !== c.eventId || prior.status !== c.status) {
      prior.status = 'unverified'; prior.net = null; issues.push(`Conflicting economic obligation: ${c.obligationId}`);
    }
  }
  cash.splice(0, cash.length, ...deduped);
  const orphanSales = entries.some(e => e.kind === 'sale' && !sales.some(s => s.tradeId && s.tradeId === e.trade_id));
  if (orphanSales) issues.push('Unlinked sale receipt: total withheld.');
  const categories = ['legacy-pre-ex', 'mixed-winner', 'retained-post-ex', 'other-sale', 'unclassified'] as const;
  const buckets = Object.fromEntries(categories.map(c => {
    const rows = sales.filter(r => r.classification === c);
    const complete = rows.length > 0 && rows.every(r => r.net !== null && r.evidence !== 'unknown');
    return [c, { count: rows.length, gross: sales.length ? sum(rows.map(r => r.gross)) : null,
      net: complete && new Set(rows.map(r => r.evidence)).size === 1 ? sum(rows.map(r => r.net)) : null,
      netActual: complete ? sum(rows.filter(r => r.evidence === 'actual').map(r => r.net)) : null,
      netModeled: complete ? sum(rows.filter(r => r.evidence === 'modeled').map(r => r.net)) : null }];
  })) as ReturnAttribution['buckets'];
  const cashAmounts = (kind: ReturnCash['kind'], evidence: 'actual' | 'modeled'): CashAmounts => {
    const rows = cash.filter(c => c.kind === kind && c.evidence === evidence && c.status === 'paid');
    const complete = schemaValid && cohortValid && !!cutoff && coverage[kind === 'dividend' ? 'dividends' : 'cash_yield'] === true && !cash.some(c => c.kind === kind && c.status === 'unverified');
    return { gross: complete ? sum(rows.map(c => c.gross)) : null, withholding: complete ? sum(rows.map(c => c.withholding)) : null, net: complete ? sum(rows.map(c => c.net)) : null, count: rows.length };
  };
  const paid = { actual: cashAmounts('dividend', 'actual'), modeled: cashAmounts('dividend', 'modeled') };
  const cashYield = { actual: cashAmounts('cash-yield', 'actual'), modeled: cashAmounts('cash-yield', 'modeled') };
  const total = (evidence: 'actual' | 'modeled'): number | null => {
    const closed = sales.filter(s => s.closed);
    if (!schemaValid || !cohortValid || !cutoff || orphanSales || coverage.sales !== true || closed.some(s => s.net === null || s.evidence === 'unknown' || s.included === false)) return null;
    return sum([sum(closed.filter(s => s.evidence === evidence).map(s => s.net)), paid[evidence].net, cashYield[evidence].net]);
  };
  if (sales.some(s => s.closed && s.net === null)) issues.push('Net sale return withheld: explicit acquisition/disposal costs and realized sale-tax evidence required.');
  if (paid.actual.net === null) issues.push('Actual paid dividends unknown: no complete verified receipt ledger. Estimates are not paid income.');
  const originalSaleSum = sales.length ? sum(sales.filter(r => r.closed).map(r => r.gross)) : null;
  const bucketSum = sum(categories.map(c => buckets[c].gross));
  return { protocol: 'BORGDIV_RETURN_ATTRIBUTION_V1', sales, cash, buckets, paid, cashYield, estimatedUnpaid: cash.some(c => c.status === 'estimated-unpaid') ? sum(cash.filter(c => c.status === 'estimated-unpaid').map(c => c.gross)) : null, totalNet: { actual: total('actual'), modeled: total('modeled') }, priceReconciliation: { bucketSum, originalSaleSum, difference: bucketSum !== null && originalSaleSum !== null ? bucketSum - originalSaleSum : null }, issues, source };
}
