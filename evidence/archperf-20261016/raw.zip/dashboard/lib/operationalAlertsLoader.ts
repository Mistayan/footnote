import path from 'node:path';
import {spawn} from 'node:child_process';
import {getPythonExecutable} from './pythonRunner';
export type OperationalAlert={scope:string;state:'degraded'|'interrupted'|'recovered';at:string;run_id:string|null;channel:'in_app';accounting_status:'unknown';trade_signal:false;severity?:'warning'|'error'|'info';coverage_status?:'complete'|'partial'|'unknown'};
export type OperationalAlertsResult={status:'ready'|'blocked'|'unavailable';rows:OperationalAlert[];evaluated_at?:string|null;error?:string};
let active=0;
export async function loadOperationalAlerts(signal?:AbortSignal):Promise<OperationalAlertsResult>{
  const unknown=(status:OperationalAlertsResult['status']='unavailable'):OperationalAlertsResult=>({status,rows:[],error:'Operational alert history unknown. Maintenance may be disabled or unavailable.'});
  if(process.env.BORG_RESTATEMENT_DIR)return unknown('blocked');
  if(signal?.aborted||active>=4)return unknown();
  const root=path.resolve(process.cwd(),'..');
  const file=process.env.BORG_OPERATIONAL_ALERTS_PATH||path.join(process.env.BORG_STATE_DIR||path.join(root,'state'),'operational_alerts.sqlite');
  active++;
  try{return await new Promise<OperationalAlertsResult>(resolve=>{
    const child=spawn(process.env.BORG_REGISTRY_PYTHON||getPythonExecutable(root),['-I',path.join(root,'simulator','operational_alerts.py')],{cwd:root,windowsHide:true,stdio:['pipe','pipe','ignore']});
    let output='',bytes=0,failed=false,finished=false;
    const stop=()=>{failed=true;child.kill();};
    const timer=setTimeout(stop,3000);signal?.addEventListener('abort',stop,{once:true});
    const finish=(result:OperationalAlertsResult)=>{if(finished)return;finished=true;clearTimeout(timer);signal?.removeEventListener('abort',stop);resolve(result);};
    child.on('error',()=>finish(unknown()));child.stdin.on('error',stop);
    child.stdout.on('data',(chunk:Buffer)=>{bytes+=chunk.length;if(bytes>64*1024)stop();else output+=chunk.toString('utf8');});
    child.on('close',code=>{
      if(failed||code!==0)return finish(unknown());
      try{
        const result=JSON.parse(output) as OperationalAlertsResult;
        if(!['ready','blocked','unavailable'].includes(result.status)||!Array.isArray(result.rows)||result.rows.length>50)throw new Error('Invalid result');
        for(const row of result.rows)if(!['cli','monitor','sentinel','script','cache_update','news_feed'].includes(row.scope)||!['degraded','interrupted','recovered'].includes(row.state)||row.channel!=='in_app'||row.trade_signal!==false||row.accounting_status!=='unknown'||typeof row.at!=='string'||Number.isNaN(Date.parse(row.at))||(row.run_id!==null&&(typeof row.run_id!=='string'||row.run_id.length>36)))throw new Error('Invalid event');
        finish(result);
      }catch{finish(unknown());}
    });
    child.stdin.end(JSON.stringify({path:file}));
  });}finally{active--;}
}
