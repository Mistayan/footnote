export const REGISTRY_NAMES=['all','cli','monitor','sentinel','script','cache_update','news_feed','unknown'] as const;
export const REGISTRY_STATES=['all','running','ok','degraded','interrupted','recovered','unknown'] as const;
export type RegistryQuery={page:number;size:number;name:string;status:string;asof:string;runId?:string;from?:string;to?:string;snapshot?:string};
export type RegistryRow={run_id:string;parent_run_id:string|null;name:string;started_at:string;heartbeat_at:string|null;status:string;display_status:string;owner_status:string;recovery_cause:string;coverage_status:string;freshness_status:string;accounting_status:string;promotion_status:string;inputs_requested:number|null;inputs_available:number|null;evidence_bounded:boolean};
export type RegistryMaintenance={at:string;probed:number|null;recovered:number|null;pruned:number|null;database_bytes:number|null;used_bytes:number|null;retention_days:number|null;keep_latest:number|null;max_database_bytes:number|null;over_soft_cap:boolean|null};
export type RegistryResult={status:'ready'|'unavailable'|'blocked'|'changed'|'invalid';query:RegistryQuery;rows:RegistryRow[];matching:number|null;pages:number|null;page?:number;asof?:string;snapshot?:string;maintenance:RegistryMaintenance|null;error?:string};
const uuid=/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/;
export function parseRegistryQuery(params:URLSearchParams):RegistryQuery {
  const integer=(key:string,fallback:number,max:number)=>{const raw=params.get(key);if(!raw)return fallback;if(!/^[1-9][0-9]{0,9}$/.test(raw))throw new Error('Invalid pagination');return Math.min(Number(raw),max);};
  const name=params.get('name')||'all',status=params.get('status')||'all';
  if(!REGISTRY_NAMES.includes(name as typeof REGISTRY_NAMES[number])||!REGISTRY_STATES.includes(status as typeof REGISTRY_STATES[number]))throw new Error('Invalid filter');
  const runId=params.get('runId')||undefined,snapshot=params.get('snapshot')||undefined;
  if(runId&&!uuid.test(runId)||snapshot&&!/^[0-9]{1,18}(:[0-9]{1,18}){3}$/.test(snapshot))throw new Error('Invalid identifier');
  const date=(key:string)=>{const raw=params.get(key)||undefined;if(raw&&(!/^\d{4}-\d{2}-\d{2}$/.test(raw)||Number.isNaN(Date.parse(raw))||new Date(raw).toISOString().slice(0,10)!==raw))throw new Error('Invalid date');return raw;};
  const from=date('from'),to=date('to');if(from&&to&&from>to)throw new Error('Invalid date range');
  const raw=params.get('asof');
  if(raw&&(!/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(?:\.\d{1,6})?(?:Z|[+-]\d{2}:\d{2})$/.test(raw)||Number.isNaN(Date.parse(raw))||new Date(raw.slice(0,10)).toISOString().slice(0,10)!==raw.slice(0,10)||Date.parse(raw)>Date.now()))throw new Error('Invalid cutoff');
  const asof=raw||new Date().toISOString();
  return {page:integer('page',1,10000),size:integer('size',25,50),name,status,asof,runId,from,to,snapshot};
}
export function registryHref(query:RegistryQuery,changes:Partial<RegistryQuery>={}):string {
  const params=new URLSearchParams();for(const [key,value] of Object.entries({...query,...changes}))if(value!==undefined&&value!=='')params.set(key,String(value));
  return '/operations?'+params.toString();
}
