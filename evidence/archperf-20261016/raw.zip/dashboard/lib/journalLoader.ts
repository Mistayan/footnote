import fs from 'node:fs/promises';
import path from 'node:path';
import { queryJournal, type JournalQuery, type JournalPageResult } from './journalQuery';
import { buildJournalIndex, queryJournalIndex, type JournalIndex } from './journalIndex';
import { createHash } from 'node:crypto';
// Single bounded process-local snapshot; canonical JSON remains the only input.
const MAX_INDEX_BYTES=32*1024*1024, MAX_INDEX_ROWS=150000;
let snapshot:{file:string;hash:string;index:JournalIndex}|undefined;
export async function loadJournalPage(query:JournalQuery):Promise<JournalPageResult> {
  const unknown={query,rows:[],total:null,matching:null,omitted:null,pages:1};
  // Never bypass the frozen diagnostic lane via the filesystem or API.
  if(process.env.BORG_RESTATEMENT_DIR) return {...unknown,status:'blocked',error:'Journal is unavailable in the frozen evidence lane; source counts unknown.'};
  try {
    const file=path.join(process.cwd(),'public','journal.json');
    const bytes=await fs.readFile(file);
    // Hash exact bytes on every request, not mtime/size; stale hits are forbidden.
    const hash=createHash('sha256').update(bytes).digest('hex');
    if(snapshot?.file===file&&snapshot.hash===hash)return {...queryJournalIndex(snapshot.index,query),sourceHash:hash};
    snapshot=undefined;
    const feed=JSON.parse(bytes.toString('utf8'));
    if(bytes.length>MAX_INDEX_BYTES)return {...queryJournal(feed,query),sourceHash:hash};
    const index=buildJournalIndex(feed);
    // Synchronous validation/build, then one atomic reference assignment. No
    // await can expose a partially built index to another request.
    if(index.total<=MAX_INDEX_ROWS)snapshot={file,hash,index};
    return {...queryJournalIndex(index,query),sourceHash:hash};
  } catch {
    snapshot=undefined;
    return {...unknown,status:'unavailable',error:'Journal source is unreadable or invalid. Counts unknown; this is not evidence of no events.'};
  }
}
