export type DashboardIndex = {
  schema_version: string;
  metadata: Record<string, unknown>;
  portfolio: Record<string, unknown>;
  taxes: Array<Record<string, unknown>>;
  scanner: unknown[];
  strategies: Record<string, unknown>;
  risk: Record<string, unknown>;
  invested_curve: number[];
  benchmark: Record<string, unknown>;
  tickers_list: string[];
};

function isObject(value: unknown): value is Record<string, unknown> {
  return typeof value === "object" && value !== null && !Array.isArray(value);
}

export function validateDashboardIndex(value: unknown): DashboardIndex {
  if (!isObject(value)) throw new Error("dashboard_index must be an object");
  const required = [
    "schema_version",
    "metadata",
    "portfolio",
    "taxes",
    "scanner",
    "strategies",
    "risk",
    "invested_curve",
    "benchmark",
    "tickers_list",
  ] as const;
  for (const key of required) {
    if (!(key in value)) throw new Error(`dashboard_index missing ${key}`);
  }
  if (typeof value.schema_version !== "string") throw new Error("schema_version must be string");
  if (!Array.isArray(value.taxes)) throw new Error("taxes must be array");
  if (!Array.isArray(value.scanner)) throw new Error("scanner must be array");
  if (!Array.isArray(value.invested_curve)) throw new Error("invested_curve must be array");
  if (!Array.isArray(value.tickers_list) || value.tickers_list.length === 0) {
    throw new Error("tickers_list must be non-empty array");
  }
  if (!value.tickers_list.every((ticker) => typeof ticker === "string")) {
    throw new Error("tickers_list must contain strings");
  }
  if (!isObject(value.metadata) || !isObject(value.portfolio) || !isObject(value.strategies)) {
    throw new Error("dashboard_index object fields invalid");
  }
  return value as DashboardIndex;
}
