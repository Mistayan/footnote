import fs from "node:fs/promises";
import path from "node:path";

export async function tailJsonl(eventsPath: string, nLines = 2000): Promise<any[]> {
  try {
    const handle = await fs.open(eventsPath, "r");
    const stat = await handle.stat();
    const size = stat.size;
    const seekPos = Math.max(0, size - nLines * 600);
    
    const buffer = Buffer.alloc(size - seekPos);
    await handle.read(buffer, 0, buffer.length, seekPos);
    await handle.close();

    const raw = buffer.toString("utf8");
    let lines = raw.split(/\r?\n/);
    if (seekPos > 0) {
      lines = lines.slice(1);
    }

    const result: any[] = [];
    for (const line of lines) {
      const trimmed = line.trim();
      if (!trimmed) continue;
      try {
        result.push(JSON.parse(trimmed));
      } catch {
        continue;
      }
    }
    return result;
  } catch (err: any) {
    if (err.code === "ENOENT") {
      throw new Error("events.jsonl not found");
    }
    throw err;
  }
}
