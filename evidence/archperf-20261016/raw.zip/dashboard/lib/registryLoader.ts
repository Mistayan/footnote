import path from 'node:path';
import { spawn } from 'node:child_process';
import { getPythonExecutable } from './pythonRunner';
import type { RegistryQuery, RegistryResult } from './registryQuery';
let active=0;
export async function loadRegistryPage(query:RegistryQuery,signal?:AbortSignal):Promise<RegistryResult> {
  const unavailable=(status:RegistryResult['status']='unavailable'):RegistryResult=>({status,query,rows:[],matching:null,pages:null,maintenance:null,error:status==='blocked'?'Current registry is unavailable in the frozen evidence lane. Counts unknown.':'Registry unavailable. Counts unknown, not evidence of no runs.'});
  // Refuse before path resolution, child creation or file access.
  if(process.env.BORG_RESTATEMENT_DIR)return unavailable('blocked');
  if(signal?.aborted||active>=4)return unavailable();
  const root=path.resolve(process.cwd(),'..');
  const file=process.env.BORG_RUN_REGISTRY_PATH||path.join(process.env.BORG_STATE_DIR||path.join(root,'state'),'run_registry.sqlite');
  const executable=process.env.BORG_REGISTRY_PYTHON||getPythonExecutable(root);
  active++;
  try {
    return await new Promise<RegistryResult>((resolve)=>{
      const child=spawn(executable,['-I',path.join(root,'scripts','read_registry_dashboard.py')],{cwd:root,windowsHide:true,stdio:['pipe','pipe','ignore']});
      let output='',bytes=0,failed=false,finished=false;
      const stop=()=>{failed=true;child.kill();};
      const timer=setTimeout(stop,3000);
      signal?.addEventListener('abort',stop,{once:true});
      const finish=(result:RegistryResult)=>{if(finished)return;finished=true;clearTimeout(timer);signal?.removeEventListener('abort',stop);resolve(result);};
      child.on('error',()=>finish(unavailable()));
      child.stdin.on('error',stop);
      child.stdout.on('data',(chunk:Buffer)=>{bytes+=chunk.length;if(bytes>128*1024)stop();else output+=chunk.toString('utf8');});
      child.on('close',(code)=>{
        if(failed||code!==0)return finish(unavailable());
        try {
          const result=JSON.parse(output) as Omit<RegistryResult,'query'>;
          if(!['ready','unavailable','blocked','changed'].includes(result.status)||!Array.isArray(result.rows)||result.rows.length>query.size)throw new Error('Invalid projection');
          finish({...result,query});
        }catch{finish(unavailable());}
      });
      child.stdin.end(JSON.stringify({path:file,query}));
    });
  }finally{active--;}
}
