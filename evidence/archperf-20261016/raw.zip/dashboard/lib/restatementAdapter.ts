import fs from "node:fs/promises";
import path from "node:path";
import { createHash } from "node:crypto";
import type { BlendedKpis, KpiEvidence, KpiFeed, StrategyKpis } from "./feeds";

const PROTOCOL = "ORIGINAL_FILLS_RESTATEMENT_V1";
const STRATEGIES = ["borgdiv", "borgpea", "momentumb", "claudemomentum"] as const;
type Obj = Record<string, unknown>;
function obj(value: unknown): Obj {
  if (!value || typeof value !== "object" || Array.isArray(value)) throw new Error("Invalid restatement object");
  return value as Obj;
}
function hash(bytes: Buffer): string { return createHash("sha256").update(bytes).digest("hex"); }
function num(block: Obj, key: string, nullable = false): number | null {
  const v = block[key];
  if (nullable && v === null) return null;
  if (typeof v !== "number" || !Number.isFinite(v)) throw new Error(`Invalid restatement ${key}`);
  return v;
}
function requiredNum(block: Obj, key: string): number { return num(block, key) as number; }
function str(block: Obj, key: string): string {
  if (typeof block[key] !== "string") throw new Error(`Invalid restatement ${key}`);
  return block[key] as string;
}
function assert(condition: unknown, message: string): asserts condition {
  if (!condition) throw new Error(message);
}

/** Read only. Legacy metadata must be the exact hash-bound frozen input, not
 * today's public feed or another capital profile. Unknown identity stays unknown.
 * All valuations come exclusively from the sidecar; null never falls back.
 * Integrity manifests are unauthenticated, not accounting certification.
 */
export async function loadRestatementKpis(directory: string, frozenLegacyPath: string): Promise<KpiFeed> {
  const names = ["manifest.json", "restatement.json", "kpis.json", "trades.json"] as const;
  const bytes = await Promise.all(names.map(name => fs.readFile(path.join(directory, name))));
  const [manifest, report, sidecar] = bytes.map(b => obj(JSON.parse(b.toString("utf8"))));
  assert(manifest.protocol === PROTOCOL && report.protocol === PROTOCOL && sidecar.protocol === PROTOCOL, "Wrong restatement protocol");
  const runId = str(manifest, "run_id");
  assert(/^[a-f0-9]{64}$/.test(runId) && sidecar.run_id === runId, "Restatement run mismatch");
  const outputs = obj(manifest.outputs);
  for (let i = 1; i < names.length; i++) assert(outputs[names[i]] === hash(bytes[i]), `Restatement hash mismatch: ${names[i]}`);
  assert(obj(JSON.parse(bytes[3].toString("utf8"))).run_id === runId, "Trade run mismatch");
  const legacyBytes = await fs.readFile(frozenLegacyPath);
  const source = obj(sidecar.source_manifest);
  assert(obj(source.input_sha256)["kpis.json"] === hash(legacyBytes), "Legacy input is not the frozen source: profile/lineage mismatch");
  assert(JSON.stringify(report.source_manifest) === JSON.stringify(sidecar.source_manifest) && JSON.stringify(manifest.source_manifest) === JSON.stringify(sidecar.source_manifest), "Source lineage mismatch");
  assert(JSON.stringify(report.row_manifest) === JSON.stringify(sidecar.row_manifest), "Row lineage mismatch");
  const profile = obj(report.profile);
  assert(profile.parent_cohort === "SHADOW_COHORT_20260802_ORIGINAL" && profile.initial_book_eur_per_sleeve === 20000 && profile.monthly_deposits_eur === 0 && report.canonical_comparison_eligible === false, "Unsupported capital/cohort profile");
  const cutoffPolicy = "explicit_observation_date_lte_as_of_aware_timestamps_utc";
  assert(report.mark_cutoff_policy === cutoffPolicy && sidecar.mark_cutoff_policy === cutoffPolicy &&
    sidecar.generation_timestamp_basis === "as_of_label_not_market_observation" &&
    /^[a-f0-9]{64}$/.test(String(report.marks_input_sha256)) && report.marks_input_sha256 === sidecar.marks_input_sha256,
    "Unsupported bounded mark contract: superseded original-fill bundle");
  const asOf = str(report, "as_of");
  assert(/^\d{4}-\d{2}-\d{2}$/.test(asOf) && sidecar.generated_at === `${asOf}T00:00:00`, "Restatement as-of mismatch");
  assert(Array.isArray(sidecar.equity_curve) && sidecar.equity_curve.length === 0, "Restatement must not claim daily NAV");
  const legacy = obj(JSON.parse(legacyBytes.toString("utf8")));
  const oldPer = obj(legacy.per_strategy);
  const newPer = obj(sidecar.per_strategy);
  const reportPer = obj(report.per_strategy);
  assert(Object.keys(newPer).sort().join() === [...STRATEGIES].sort().join() && Object.keys(oldPer).sort().join() === [...STRATEGIES].sort().join(), "Strategy lineage mismatch");
  const evidence: KpiEvidence = {
    basis: "original_fills_current_policy_diagnostic",
    input_as_of: asOf,
    input_generated_at: str(legacy, "generated_at"),
    freshness_status: "unknown",
    provenance_status: "frozen_input_hash_bound_profile_identity_unverified",
    risk_status: "unknown_no_dated_daily_marked_nav",
    daily_sharpe: null, daily_max_drawdown: null,
    dividend_paid_eur: null, dividend_payment_status: "unknown", dividend_cash_credit_eur: 0,
    dividend_entitlement_status: "unverified",
  };
  function runtime(b: Obj) {
    assert(b.shadow_start_date === null || typeof b.shadow_start_date === "string", "Invalid runtime start");
    return { shadow_start_date: b.shadow_start_date as string | null,
      shadow_day_count: requiredNum(b, "shadow_day_count"), target_days: requiredNum(b, "target_days"), target_progress: requiredNum(b, "target_progress") };
  }
  function financial(b: Obj) {
    const status = b.valuation_status;
    assert(status === "copied_marks_unverified_as_of_bounded" || status === "unknown", "Invalid bounded valuation status");
    const reasons = b.valuation_unknown_reasons;
    assert(Array.isArray(reasons) && reasons.every(v => typeof v === "string"), "Invalid valuation unknown reasons");
    assert((status === "unknown") === (reasons.length > 0), "Valuation status/reasons mismatch");
    if (status === "unknown") {
      for (const key of ["net_pnl_eur", "current_value_eur"]) assert(b[key] === null, `Unknown valuation must withhold ${key}`);
    }
    if (b.marks !== undefined) {
      assert(Array.isArray(b.marks) && b.marks.length === b.open_positions_count, "Invalid bounded marks lineage");
      for (const raw of b.marks) {
        const mark = obj(raw);
        assert(mark.observation_date_basis === "explicit_date_or_aware_timestamp_utc_not_feed_generation" && typeof mark.valuation_eligible === "boolean", "Invalid bounded mark semantics");
        if (mark.valuation_eligible) {
          const date = str(mark, "mark_observed_date");
          assert(/^\d{4}-\d{2}-\d{2}$/.test(date) && Number.isFinite(Date.parse(date)) && new Date(date).toISOString().slice(0, 10) === date && date <= asOf && mark.withheld_reason === null,
            "Unbounded eligible mark");
          const observations = [mark.observed_date_input, mark.market_timestamp].filter(v => v != null);
          assert(observations.length > 0 && observations.every(v => {
            if (typeof v !== "string") return false;
            const dateOnly = /^\d{4}-\d{2}-\d{2}$/.test(v);
            if (!dateOnly && !/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(?:\.\d{1,6})?(?:Z|[+-]\d{2}:\d{2})$/.test(v)) return false;
            const day = v.slice(0, 10);
            const parsed = Date.parse(v);
            return Number.isFinite(parsed) && Number.isFinite(Date.parse(day)) && new Date(day).toISOString().slice(0, 10) === day && new Date(parsed).toISOString().slice(0, 10) === date;
          }), "Eligible mark lacks bounded observation input");
          assert(requiredNum(mark, "current_price_eur") > 0, "Invalid eligible mark price");
        } else {
          assert(mark.current_price_eur === null && typeof mark.withheld_reason === "string" && reasons.includes(mark.withheld_reason), "Invalid withheld mark semantics");
          for (const key of ["invested_value_eur", "unrealized_eur", "net_pnl_eur", "current_value_eur"]) assert(b[key] === null, `Withheld marks must propagate: ${key}`);
        }
      }
    }
    return { fx_status: b.fx_status === undefined ? "unknown" : str(b, "fx_status"),
      fees_eur: b.fees_eur === undefined ? null : num(b, "fees_eur", true),
      spread_slippage_eur: b.spread_slippage_eur === undefined ? null : num(b, "spread_slippage_eur", true),
      tax_policy: b.tax_policy === undefined ? "unknown" : str(b, "tax_policy"),
      valuation_status: status as KpiEvidence["valuation_status"],
      valuation_unknown_reasons: reasons as string[],
      valuation_missing_reasons: reasons as string[],
      priced_positions_count: b.priced_positions_count === undefined ? null : num(b, "priced_positions_count", true),
      missing_marks_count: b.missing_marks_count === undefined ? null : num(b, "missing_marks_count", true),
      book_value_eur: num(b, "book_value_eur", true),
      realized_pnl_eur: num(b, "realized_pnl_eur", true), invested_cost_eur: num(b, "invested_cost_eur", true),
      invested_value_eur: num(b, "invested_value_eur", true), unrealized_eur: num(b, "unrealized_eur", true),
      net_pnl_eur: num(b, "net_pnl_eur", true), current_value_eur: num(b, "current_value_eur", true),
      cash_eur: num(b, "signed_cash_eur", true), signed_cash_eur: num(b, "signed_cash_eur", true),
      capital_idle_eur: num(b, "signed_cash_eur", true), capital_deployed_eur: num(b, "invested_cost_eur", true),
      tax_eur: num(b, "tax_reserve_eur", true), tax_reserve_eur: num(b, "tax_reserve_eur", true),
      yield_parked_eur: num(b, "yield_parked_eur", true) };
  }
  const per: Record<string, StrategyKpis> = {};
  for (const name of STRATEGIES) {
    const old = obj(oldPer[name]), b = obj(newPer[name]), original = obj(reportPer[name]);
    for (const key of Object.keys(original)) assert(JSON.stringify(original[key]) === JSON.stringify(b[key]), `Report/KPI mismatch: ${name}.${key}`);
    for (const key of ["book_value_eur", "open_positions_count", "closed_trades_count"]) assert(old[key] === b[key], `Legacy profile/count mismatch: ${name}.${key}`);
    assert(b.dividend_paid_eur === null && b.dividend_cash_credit_eur === 0 && b.sharpe === null && b.max_drawdown === null, "Unsafe dividend/risk semantics");
    const account = old.account_type;
    assert(account === (name === "borgpea" ? "PEA" : "CTO"), "Account lineage mismatch");
    assert(Array.isArray(b.marks), "Missing bounded marks lineage");
    per[name] = { ...evidence, ...financial(b), ...runtime(old),
      open_positions_count: requiredNum(b, "open_positions_count"), closed_trades_count: requiredNum(b, "closed_trades_count"),
      winning_trades_count: requiredNum(old, "winning_trades_count"), win_rate: requiredNum(old, "win_rate"),
      account_type: account as "PEA" | "CTO", sharpe: null, max_drawdown: null,
      dividend_earned_entitlement_estimate_eur: num(b, "dividend_earned_entitlement_estimate_eur", true),
      dividend_captured_eur: num(b, "dividend_earned_entitlement_estimate_eur", true),
      // No stale forward projection or slot valuation metadata is imported.
      dividend_projected_14d_eur: null };
  }
  const b = obj(sidecar.blended), oldBlended = obj(legacy.blended);
  assert(b.dividend_paid_eur === null && b.dividend_cash_credit_eur === 0, "Unsafe blended dividend semantics");
  assert(oldBlended.book_value_eur === b.book_value_eur, "Blended capital profile mismatch");
  // Do not accept a plausible blended value when any underlying sleeve is unpriced.
  for (const key of ["book_value_eur", "signed_cash_eur", "invested_cost_eur", "invested_value_eur", "realized_pnl_eur", "unrealized_eur", "net_pnl_eur", "current_value_eur", "tax_reserve_eur", "yield_parked_eur"]) {
    const values = STRATEGIES.map(name => num(obj(newPer[name]), key, true));
    if (values.some(v => v === null)) assert(b[key] === null, `Blended unknown must propagate: ${key}`);
    else assert(Math.abs(requiredNum(b, key) - values.reduce<number>((sum, v) => sum + v!, 0)) <= 0.025, `Blended/sleeve mismatch: ${key}`);
  }
  const pressure = obj(oldBlended.signal_pressure);
  const blended: BlendedKpis = { ...evidence, ...financial(b), ...runtime(oldBlended),
    // Sidecar does not publish a combined entitlement estimate. Unknown, not zero.
    dividend_captured_eur: null, dividend_earned_entitlement_estimate_eur: null,
    signal_pressure: { buy: requiredNum(pressure, "buy"), sell: requiredNum(pressure, "sell"), ratio: requiredNum(pressure, "ratio") } };
  return { ...evidence, protocol: PROTOCOL, run_id: runId, generated_at: str(sidecar, "generated_at"),
    canonical_comparison_eligible: false, blended, per_strategy: per, equity_curve: [],
    equity_curve_status: "unknown_no_daily_marked_nav", equity_curve_basis: "historical_restatement_no_daily_nav" };
}
