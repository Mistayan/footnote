/**
 * lib/feeds.ts — Phase-19 dashboard feed contracts + server-side loader.
 *
 * This is the interface layer: every Phase-19 feed has a precise TypeScript
 * type here so Wave 2/3 components build against contracts, not exploration.
 * Shapes match exactly what the Wave-0 Python writers emit
 * (simulator/Engine/dashboard_feeds/*). No `any`.
 *
 * `loadJson<T>` mirrors the null-guarded server-read pattern from app/page.tsx
 * (loadLive/loadShadow): read public/{name}, JSON.parse, try/catch -> null.
 */
import fs from "node:fs/promises";
import path from "node:path";
import { loadRestatementKpis } from "./restatementAdapter";

/** Re-exported so route shells import the shadow contract from one place. */
export type { ShadowPayload, ShadowPosition } from "@/components/LiveDashboard";

// ── price_history.json (DASH-V2-04, writer: price_history_feed.py) ───────────
export type PriceHistory = {
  generated_at: string;
  series: Record<string, { date: string; close: number }[]>;
};

// ── trades.json (DASH-V2-04, writer: trades_feed.py) ─────────────────────────
/** One buy/sell event the strategy chart renders as a marker. */
export type TradeEvent = {
  ticker: string;
  action: "BUY" | "SELL";
  date: string;
  price: number | null;
};

export type TradesFeed = {
  generated_at: string;
  by_strategy: Record<string, TradeEvent[]>;
};

import type { StrategyTrade } from "@/components/StrategyChart";

/**
 * Map a strategy's flat BUY/SELL event list (trades.json) into the
 * `StrategyTrade[]` shape `StrategyChart.buildChartRows` consumes: a BUY event
 * binds to `entry_date`/`entry_price_eur`, a SELL event to
 * `exit_date`/`exit_price_eur`. One event → one StrategyTrade so each marker is
 * placed independently on its own date (the chart only reads entry_date for BUY
 * and exit_date for SELL).
 */
export function toStrategyTrades(events: TradeEvent[] | undefined): StrategyTrade[] {
  if (!events) return [];
  return events.map((e) =>
    e.action === "BUY"
      ? { ticker: e.ticker, entry_date: e.date, entry_price_eur: e.price }
      : { ticker: e.ticker, entry_date: "", exit_date: e.date, exit_price_eur: e.price },
  );
}

// ── dividends.json (DASH-V2-05, writer: dividends_feed.py) ────────────────────
export type DividendFeed = {
  generated_at: string;
  upcoming: {
    ticker: string;
    ex_date: string;
    /** Dividend payment/payable date (ISO); can fall weeks after ex_date. May be null. */
    pay_date?: string | null;
    /** Gross dividend per share. */
    gross_dividend: number;
    currency: string;
  }[];
};

// ── borgdiv_forward_candidates.json (writer: forward_dividends_feed.py) ───────
// The GATE-PASSING forward dividend candidates (post quality-gate + net-edge,
// ranked by edge) — NOT the raw market-wide discovery calendar in dividends.json.
// Top `pick_limit` entries are flagged is_pick (the slots the strategy fills).
export type ForwardDividendFeed = {
  generated_at: string;
  pick_limit: number;
  candidates: {
    ticker: string;
    isin?: string | null;
    name?: string | null;
    ex_date: string;
    pay_date?: string | null;
    /** Home exchange + country — used to label the ex-div session region/timezone. */
    exchange?: string | null;
    country?: string | null;
    gross_dividend: number;
    currency: string;
    gross_yield_pct: number;
    net_yield_pct: number;
    expected_edge_bps: number;
    is_pick: boolean;
  }[];
};

// ── intents.json (writer: intents_feed.py) ───────────────────────────────────
export type SignalPressure = {
  buy: number;
  sell: number;
  ratio: number;
};

export type IntentFeed = {
  generated_at: string;
  window: string;
  intents: {
    date: string;
    ticker: string;
    action: string;
    score: number;
    price: number;
  }[];
  signal_pressure: SignalPressure;
};

// ── kpis.json (writer: kpis_feed.py) ─────────────────────────────────────────
/** Per-strategy KPI block. sharpe/max_drawdown are number|null (honest no-data). */
export type KpiEvidence = {
  fx_status?: string;
  fees_eur?: number | null;
  spread_slippage_eur?: number | null;
  tax_policy?: string;
  valuation_status?: "complete" | "incomplete" | "unknown" | "copied_marks_unverified_as_of_bounded";
  valuation_unknown_reasons?: string[];
  valuation_missing_reasons?: string[];
  priced_positions_count?: number | null;
  missing_marks_count?: number | null;
  basis?: string;
  input_as_of?: string;
  input_generated_at?: string;
  freshness_status?: string;
  provenance_status?: string;
  risk_status?: string;
  daily_sharpe?: number | null;
  daily_max_drawdown?: number | null;
  dividend_earned_entitlement_estimate_eur?: number | null;
  dividend_entitlement_status?: string;
  dividend_paid_eur?: number | null;
  dividend_payment_status?: string;
  dividend_cash_credit_eur?: number;
  tax_reserve_eur?: number | null;
  signed_cash_eur?: number | null;
};

export type StrategyKpis = KpiEvidence & {
  book_value_eur: number | null;
  unrealized_eur: number | null;
  realized_pnl_eur: number | null;
  net_pnl_eur: number | null;
  open_positions_count: number | null;
  closed_trades_count: number | null;
  winning_trades_count: number | null;
  win_rate: number | null;
  sharpe: number | null;
  max_drawdown: number | null;
  invested_cost_eur: number | null;
  invested_value_eur: number | null;
  cash_eur: number | null;
  yield_parked_eur: number | null;
  current_value_eur: number | null;
  capital_deployed_eur: number | null;
  capital_idle_eur: number | null;
  dividend_captured_eur: number | null;
  dividend_projected_14d_eur: number | null;
  account_type: "CTO" | "PEA";
  tax_eur: number | null;
  shadow_start_date: string | null;
  shadow_day_count: number;
  target_days: number;
  target_progress: number;
};

export type BlendedKpis = KpiEvidence & {
  book_value_eur: number | null;
  unrealized_eur: number | null;
  realized_pnl_eur: number | null;
  net_pnl_eur: number | null;
  invested_cost_eur: number | null;
  invested_value_eur: number | null;
  cash_eur: number | null;
  yield_parked_eur: number | null;
  dividend_captured_eur: number | null;
  tax_eur: number | null;
  current_value_eur: number | null;
  capital_deployed_eur: number | null;
  capital_idle_eur: number | null;
  signal_pressure: SignalPressure;
  shadow_start_date: string | null;
  shadow_day_count: number;
  target_days: number;
  target_progress: number;
};

export type KpiFeed = KpiEvidence & {
  schema_version?: string;
  protocol?: string;
  run_id?: string;
  canonical_comparison_eligible?: boolean;
  equity_curve_basis?: string;
  equity_curve_status?: string;
  generated_at: string;
  blended: BlendedKpis;
  /** Combined blended-equity series (REQ-2). Ordered, strictly ascending dates. */
  equity_curve: { date: string; equity: number | null }[];
  per_strategy: Record<string, StrategyKpis>;
};

export type EquityPanelKey = "pea" | "cto";
export type EquitySeriesMeta = {
  key: string;
  label: string;
  role: "benchmark" | "strategy";
};
export type EquityFeedRow = {
  date: string;
  deposited: number;
  pea: Record<string, number>;
  cto: Record<string, number>;
  pea_net: Record<string, number>;
  cto_net: Record<string, number>;
};
export type EquityFeed = {
  generated_at: string;
  basis: { initial: number; monthly: number; currency: string };
  tax: { pea_pct: number; cto_pct: number };
  panels: Record<EquityPanelKey, { title: string; tax_label: string; series: EquitySeriesMeta[] }>;
  rows: EquityFeedRow[];
};

// ── etf_allocation.json (set-and-forget research feed) ───────────────────────
export type EtfAllocationHolding = {
  bucket: string;
  ticker: string;
  isin: string;
  fund: string;
  pea_status: string;
  allocation_pct: number;
  monthly_eur: number;
  market_value_eur: number;
  weight_pct: number;
};

export type EtfAllocationFeed = {
  protocol: string;
  comparison_status: string;
  verdict: string;
  account_type: "CTO" | "PEA";
  generated_at: string;
  source_note: string;
  history_start: string;
  history_end: string;
  contribution_count: number;
  initial_capital_eur: number;
  monthly_budget_eur: number;
  total_contributed_eur: number;
  final_value_eur: number;
  net_value_after_tax_eur: number;
  costs_eur: number;
  tax_eur: number;
  gain_eur: number;
  return_pct: number;
  annualized_dca_return_pct: number;
  tax_model?: { tax_basis?: string; liquidation_at_report_end?: boolean; applied_tax_eur?: number };
  max_drawdown_pct: number;
  requested_window: { start: string; end: string };
  effective_common_window: { start: string; end: string };
  limitations: string[];
  assumptions: string[];
  performance: {
    fetch_seconds: number;
    simulation_seconds: number;
    total_seconds: number;
    price_rows_loaded: number;
    data_transport: string;
  };
  holdings: EtfAllocationHolding[];
  benchmark: {
    ticker: string;
    history_start: string;
    history_end: string;
    total_contributed_eur: number;
    final_value_eur: number;
    net_value_after_tax_eur: number;
    costs_eur: number;
    tax_eur: number;
    gain_eur: number;
    return_pct: number;
    max_drawdown_pct: number;
    relative_gain_eur: number;
    relative_return_pct: number;
    series: { date: string; equity: number; contributed: number }[];
  };
  series: { date: string; equity: number; contributed: number; benchmark?: number }[];
};

export type JournalFeedRow = {
  ticker: string;
  name?: string;
  action: string;
  qty: number | null;
  price: number | null;
  datetime: string;
  date: string;
  state: string;
  pnl?: number | null;
};

export type JournalFeed = {
  generated_at?: string;
  by_strategy?: Record<string, JournalFeedRow[]>;
};

// ── news.json (DASH-V2-07, writer: news_feed.py) ─────────────────────────────
export type NewsItem = {
  headline: string;
  summary: string;
  ts: string;
  url?: string | null;
};

export type NewsFeed = {
  generated_at: string;
  by_ticker: Record<string, NewsItem[]>;
  empty: boolean;
};

export type Sma150WatchlistFeed = {
  generated_at: string;
  mode: "research_watchlist";
  retention_days: number;
  candidates: {
    ticker: string;
    exchange_symbol: string;
    description: string;
    close: number;
    sma150: number;
    volume_ratio: number;
    market_cap: number;
    industry: string;
    setup: "recent_breakout" | "near_sma150";
    breakout_age: number | null;
    first_seen: string;
    last_seen: string;
    active: boolean;
    accepted_on: string | null;
    entry_status: "signal_day" | "accepted" | "following";
  }[];
};

/**
 * Read a JSON feed from the Next.js `public/` dir server-side.
 * Returns the parsed value typed as `T`, or `null` on any error
 * (missing/malformed file). Routes must render gracefully on null (T-19-09).
 */
export async function loadJson<T>(name: string): Promise<T | null> {
  try {
    // One evidence lane: unrelated public panels must not enter a frozen run.
    if (process.env.BORG_RESTATEMENT_DIR && name !== "kpis.json") return null;
    if (name === "kpis.json" && process.env.BORG_RESTATEMENT_DIR) {
      if (!process.env.BORG_RESTATEMENT_LEGACY_KPIS) throw new Error("Restatement requires exact frozen legacy input");
      return await loadRestatementKpis(process.env.BORG_RESTATEMENT_DIR, process.env.BORG_RESTATEMENT_LEGACY_KPIS) as T;
    }
    const file = path.join(process.cwd(), "public", name);
    const raw = await fs.readFile(file, "utf8");
    const parsed = JSON.parse(raw);
    // Sidecars are not drop-in feeds; never let a raw diagnostic reach consumers.
    if (name === "kpis.json" && parsed.protocol === "ORIGINAL_FILLS_RESTATEMENT_V1") throw new Error("Use verified restatement adapter");
    return parsed as T;
  } catch (error) {
    if (name === "kpis.json") console.error("KPI feed unavailable:", error instanceof Error ? error.message : "invalid input");
    return null;
  }
}
