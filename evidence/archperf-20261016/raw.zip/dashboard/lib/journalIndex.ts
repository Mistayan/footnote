import { journalRows, type JournalFeedRow, type JournalQuery, type JournalPageResult } from './journalQuery';

/** Process-local acceleration only. Canonical bytes remain the sole source. */
export interface JournalIndex {
  generatedAt?: string;
  total: number;
  orders: Record<'asc'|'desc', readonly JournalFeedRow[]>;
}
export function buildJournalIndex(feed: unknown): JournalIndex {
  const rows=journalRows(feed);
  // Sort both directions independently: reversing would reverse stable ties.
  return {generatedAt:(feed as {generated_at?:string}).generated_at,total:rows.length,
    orders:{asc:[...rows].sort((a,b)=>a.datetime.localeCompare(b.datetime)),desc:[...rows].sort((a,b)=>b.datetime.localeCompare(a.datetime))}};
}
export function queryJournalIndex(index:JournalIndex,query:JournalQuery):JournalPageResult {
  const q=query.q.toLocaleLowerCase();
  if(query.strategy==='all'&&!q&&!query.from&&!query.to) {
    const pages=Math.max(1,Math.ceil(index.total/query.size)),page=Math.min(query.page,pages),start=(page-1)*query.size;
    const rows=structuredClone(index.orders[query.sort].slice(start,start+query.size));
    return {status:'ready',query:{...query,page},rows,total:index.total,matching:index.total,omitted:index.total-rows.length,pages,generatedAt:index.generatedAt};
  }
  // Exact count requires a scan for arbitrary substring/date filters. Avoid a
  // matching-row allocation; keep only the bounded requested page plus last page.
  const start=(query.page-1)*query.size;let matching=0;
  const selected:JournalFeedRow[]=[];let tail:JournalFeedRow[]=[];
  for(const row of index.orders[query.sort]) {
    if(query.strategy!=='all'&&row.strategy!==query.strategy)continue;
    if(query.from&&row.date<query.from||query.to&&row.date>query.to)continue;
    if(q&&!`${row.ticker} ${row.name} ${row.action} ${row.state} ${row.datetime}`.toLocaleLowerCase().includes(q))continue;
    if(matching%query.size===0)tail=[];
    tail.push(row);
    if(matching>=start&&matching<start+query.size)selected.push(row);
    matching++;
  }
  const pages=Math.max(1,Math.ceil(matching/query.size)),page=Math.min(query.page,pages);
  const rows=page===query.page?selected:tail;
  // Callers cannot mutate the resident snapshot through returned objects.
  return {status:'ready',query:{...query,page},rows:structuredClone(rows),total:index.total,matching,omitted:matching-rows.length,pages,generatedAt:index.generatedAt};
}
