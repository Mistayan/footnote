/**
 * Canonical strategy order + labels — single source of truth shared across
 * journal/kpi/dashboard components. Order matches the Sidebar nav.
 * Keep this module free of React/client-only imports so both RSC and client
 * code can import it.
 */

// claudepea PRUNED 2026-06-17 — underperformed BorgPEA-LRT (€76k vs €187k net).
// claudealpha RETIRED 2026-06-20 (BorgInvestor-445) — 17.1% CAGR ≈ S&P, no edge.
export const STRATEGY_REGISTRY = [
  { key: "borgdiv", label: "BorgDiv", href: "/borgdiv", runtimeLedger: true },
  { key: "borgpea", label: "BorgPEA", href: "/borgpea", runtimeLedger: true },
  { key: "momentumb", label: "MomentumB", href: "/momentumb", runtimeLedger: true },
  { key: "claudemomentum", label: "Claude Momentum", href: "/claudemomentum", runtimeLedger: true },
  // Research contribution-path evidence, not a live/shadow ledger sleeve.
  { key: "etf-allocation", label: "ETF Allocation", href: "/etf-allocation", runtimeLedger: false },
] as const;

export const STRATEGY_ORDER: string[] = STRATEGY_REGISTRY.map((strategy) => strategy.key);
export const RUNTIME_STRATEGY_ORDER = STRATEGY_REGISTRY.filter((strategy) => strategy.runtimeLedger).map((strategy) => strategy.key);
export const STRAT_LABEL: Record<string, string> = Object.fromEntries(
  STRATEGY_REGISTRY.map((strategy) => [strategy.key, strategy.label]),
);

export function stratLabel(key: string): string {
  return STRAT_LABEL[key] ?? key;
}
