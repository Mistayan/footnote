import { buildBorgDivReturnAttribution, type ReturnAttribution } from './borgdivReturnAttribution';
export type AttributionCategory = 'pre-ex' | 'post-ex' | 'other' | 'unclassified' | 'open';
export type AttributionRow = { id: string; ticker: string; entryDate: string | null; exitDate: string | null; exDate: string | null; reason: string; category: AttributionCategory; priceProfit: number | null; sourceHash: string | null; included: boolean | null };
export type BorgDivAttributionModel = { returns: ReturnAttribution; version: string; rows: AttributionRow[]; totals: Record<'pre-ex' | 'post-ex' | 'other' | 'unclassified', number | null>; paidNetDividends: number | null; fees: number | null; slippage: number | null; tax: number | null; entitlement: number | null; projected: number | null; combinedNet: null; sourceHash: string | null; incomplete: boolean; status: 'available' | 'unavailable' | 'invalid' };
type Obj = Record<string, unknown>;
const object = (v: unknown): Obj => v !== null && typeof v === 'object' && !Array.isArray(v) ? v as Obj : {};
const number = (v: unknown): number | null => typeof v === 'number' && Number.isFinite(v) ? v : null;
const text = (v: unknown): string | null => typeof v === 'string' && v.length > 0 ? v : null;
const date = (v: unknown): string | null => typeof v === 'string' && /^\d{4}-\d{2}-\d{2}$/.test(v) && Number.isFinite(Date.parse(v)) && new Date(v).toISOString().slice(0,10) === v ? v : null;

/** Original records only. A ticker or an exit-reason name is never ex-event evidence.
 * Known signed gross price differences are diagnostic, not net earnings or FX certification. */
export function adaptBorgDivAttribution(input: unknown, sourceHash: string | null = null): BorgDivAttributionModel {
  const report = object(input);
  const kpi = object(object(report.per_strategy).borgdiv);
  const raw = Array.isArray(report.original_rows) ? report.original_rows : [];
  const attribution = object(report.performance_attribution);
  const backendRows = attribution.protocol === 'ORIGINAL_PRICE_PNL_ATTRIBUTION_V1' && Array.isArray(attribution.closed_trades) ? attribution.closed_trades.map(object) : [];
  const categories: Record<string, AttributionCategory> = { pre_ex_runup_price_pnl_eur:'pre-ex', post_ex_recovery_price_pnl_eur:'post-ex', risk_timeout_other_price_pnl_eur:'other', unclassified_price_pnl_eur:'unclassified' };
  const rows = raw.map(object).filter(r => r.strategy === 'borgdiv').map((r): AttributionRow => {
    const b = backendRows.find(b=>b.trade_id===r.trade_id && b.strategy==='borgdiv');
    const entryDate = date(r.entry_date), exitDate = date(r.exit_date), exDate = date(b ? b.target_ex_date_used : r.target_ex_date);
    const entry = number(r.entry_price_eur), exit = number(r.exit_price_eur), qty = number(r.shares);
    const priceProfit = b ? number(b.realized_price_pnl_eur) : exitDate && entry !== null && exit !== null && qty !== null && qty > 0 ? (exit-entry)*qty : null;
    const category: AttributionCategory = !exitDate ? 'open' : b ? categories[String(b.category)] ?? 'unclassified' : 'unclassified';
    return { id: text(r.trade_id) ?? 'unknown', ticker: text(r.ticker) ?? 'Unknown listing', entryDate, exitDate, exDate, reason: text(b?.exit_reason ?? r.exit_reason) ?? 'Unknown exit reason', category, priceProfit, sourceHash: text(b?.original_row_sha256 ?? r.original_row_sha256), included: typeof b?.included_in_active_totals === 'boolean' ? b.included_in_active_totals : null };
  });
  const totals = Object.fromEntries((['pre-ex','post-ex','other','unclassified'] as const).map(category => {
    const subset = rows.filter(r=>r.category===category);
    return [category, !rows.length || subset.some(r=>r.priceProfit===null) ? null : subset.reduce((sum,r)=>sum+r.priceProfit!,0)];
  })) as BorgDivAttributionModel['totals'];
  return { returns: buildBorgDivReturnAttribution(input, sourceHash), version: rows.some(r=>text(object(raw.find(v=>object(v).trade_id===r.id)).regime)?.includes('QuantPreExRunup')) ? 'Historical Q · original fills' : 'Original fills · strategy version unverified', rows, totals,
    // The existing dividend_paid_eur field has no verified NET-payment contract.
    paidNetDividends: number(object(object(attribution.by_strategy).borgdiv).net_paid_dividend_eur), fees: number(kpi.fees_eur), slippage: number(kpi.spread_slippage_eur), tax: number(kpi.tax_reserve_eur), entitlement: number(kpi.dividend_earned_entitlement_estimate_eur), projected: number(kpi.dividend_projected_14d_eur), combinedNet: null, sourceHash, incomplete: true, status: input === null ? 'unavailable' : 'available' };
}

/** Pair legacy events exclusively by stable trade_id, never by ticker/date proximity. */
export function attributionFromEvents(input: unknown, kpi: unknown, sourceHash: string): BorgDivAttributionModel {
  const events = object(object(input).by_strategy).borgdiv;
  const groups = new Map<string, Obj[]>();
  for (const raw of Array.isArray(events) ? events : []) {
    const e = object(raw), id = text(e.trade_id);
    if (id) groups.set(id,[...(groups.get(id) ?? []), e]);
  }
  const original_rows = [...groups.entries()].map(([id, events])=>{
    const buys = events.filter(e=>e.action==='BUY'), sells=events.filter(e=>e.action==='SELL');
    const buy=buys.length===1 ? buys[0] : {}, sell=sells.length===1 ? sells[0] : {};
    const compatible = buys.length===1 && sells.length===1 && buy.quantity===sell.quantity && buy.original_row_sha256===sell.original_row_sha256 && buy.ticker===sell.ticker;
    return { strategy:'borgdiv', trade_id:id, ticker:buy.ticker ?? sell.ticker, entry_date:buy.date, exit_date:sell.date, shares:compatible ? buy.quantity : null, entry_price_eur:compatible ? buy.price : null, exit_price_eur:compatible ? sell.price : null, original_row_sha256:buy.original_row_sha256, target_ex_date:sell.target_ex_date ?? buy.target_ex_date, target_event_id:sell.target_event_id ?? buy.target_event_id, exit_reason:sell.exit_reason ?? sell.reason, strategy_version:sell.strategy_version ?? buy.strategy_version, regime:sell.regime ?? buy.regime };
  });
  const unidentified = (Array.isArray(events) ? events.map(object) : []).filter(e => !text(e.trade_id));
  return adaptBorgDivAttribution({original_rows:[...original_rows, ...unidentified.map(e => ({strategy:'borgdiv', trade_id:null, ticker:e.ticker, entry_date:e.action==='BUY'?e.date:null, exit_date:e.action==='SELL'?e.date:null, status:e.action==='SELL'?'closed':'open', exit_reason:e.exit_reason??e.reason, shares:null, entry_price_eur:null, exit_price_eur:null}))],per_strategy:{borgdiv:kpi}},sourceHash);
}
