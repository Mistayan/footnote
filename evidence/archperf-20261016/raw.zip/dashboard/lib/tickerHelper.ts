export const getTickerName = (ticker: string, name?: string): string => {
  if (name && name !== ticker && !name.startsWith("IE00") && !name.startsWith("DE00") && !name.startsWith("XS33")) {
    return name;
  }
  const cleanTicker = ticker.toUpperCase().split(".")[0];
  const map: Record<string, string> = {
    "CSCO": "Cisco Systems Inc.",
    "O": "Realty Income Corp.",
    "HST": "Host Hotels & Resorts",
    "SGOV": "iShares 0-3 Month Treasury Bond ETF",
    "IE00B7KMNP07": "UBS ETF Solactive Global Pure Gold Miners",
    "IE00B7XD2195": "WisdomTree Silver 3x Daily Leveraged",
    "DE000SY1W6T6": "SG Best Turbo auf SOFI Technologies",
    "DE000SX8WRJ2": "SG Mini Future auf GE Vernova Inc.",
    "XS3306516876": "WisdomTree Silver 3x Daily Leveraged",
    "CA2449161025": "DeFi Technologies Inc.",
    "CA2449": "DeFi Technologies Inc.",
    "DEFI": "DeFi Technologies Inc.",
    "IE00B7": "UBS ETF Gold Miners",
    "DE000S": "SG Turbo Warrants",
    "XS3306": "WisdomTree Silver 3x Daily Leveraged",
    "AAPL": "Apple Inc.",
    "MSTR": "MicroStrategy Inc.",
  };
  return map[cleanTicker] || map[ticker.toUpperCase()] || ticker;
};
