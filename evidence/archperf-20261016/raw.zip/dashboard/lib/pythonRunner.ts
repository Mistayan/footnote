import { execFile } from "node:child_process";
import fs from "node:fs";
import path from "node:path";
import { promisify } from "node:util";

const execFilePromise = promisify(execFile);

export function getPythonExecutable(repoRoot: string): string {
  const candidates = process.platform === "win32"
    ? [path.join(repoRoot, ".venv", "Scripts", "python.exe"), path.join(repoRoot, ".venv", "Scripts", "python")]
    : [path.join(repoRoot, ".venv", "bin", "python")];
  return candidates.find((candidate) => fs.existsSync(candidate)) ?? process.env.BORGINVESTOR_PYTHON ?? "python";
}

export async function runPythonHelper<T>(command: string, args: string[] = []): Promise<T> {
  const repoRoot = path.resolve(process.cwd(), "..");
  const pythonPath = getPythonExecutable(repoRoot);
  const pythonEnv = { ...process.env };
  delete pythonEnv.PYTHONPATH;

  try {
    const { stdout, stderr } = await execFilePromise(
      pythonPath,
      ["-m", "simulator.dashboard_helper", command, ...args],
      { cwd: repoRoot, env: pythonEnv },
    );
    if (stderr && stderr.trim().length > 0) {
      console.warn("Python helper stderr:", stderr);
    }
    return JSON.parse(stdout) as T;
  } catch (err: any) {
    console.error("Failed to run python helper:", err);
    throw new Error(err.stderr || err.message || "Execution failed");
  }
}
